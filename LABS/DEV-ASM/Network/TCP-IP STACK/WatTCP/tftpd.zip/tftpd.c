/*
 *   tftpd - a server for TFTP on the 386ex
 *
 *   Kelly Hall  3/23/1999
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <tcp.h>

#undef DEBUG

word timelimit = 60;         // number of seconds to run before exiting
word  tftpport = 69;         // port number for tftp
word  altport  = 10000;      // the port the server specifies for transfer
word time_limit = 5;         // number of seconds before a timeout

udp_Socket lowsock, highsock;
char bigbuff[8192], newbuff[8192];
byte rspare[1500];
byte sspare[1500];
char scratch[100];
char db[1000];
int  bigbufflen = 8192, newbufflen = 8192;
int  rsparelen  = 1500;
int  ssparelen  = 1500;
int  scratchlen = 100;
byte *fname, *mode, *errstring;
int errcode, blockno, datalen;


void debug(char *foo) {
	printf("%s",foo);
	fflush(stdout);
}


// a local version of puts() without the trailing newline
void putsl(const char *s) {
	while( *s ) {
		putch(*s);
		s++;
	}
}


// parse the WATTCP.CFG file
static void (*other_init)(char*, char*);
static void my_init(char *name, char *value) {
	if( !strcmp(name, "TFTPD_LIMIT") ) {
		timelimit = atoi(value);
	} else if(other_init) {
		(*other_init)(name,value);
	}
}


void setup_trans_sock(word myport, longword hisip, word hisport) {
#ifdef DEBUG
	sprintf(db, "   setup_trans_sock: %u %lX %u", myport, hisip, hisport);
	debug(db);
#endif
	if( !udp_open(&highsock, myport, hisip, hisport, NULL) ) {
		puts("\nCould not open socket for transmit");
		exit(3);
	}
#ifdef DEBUG
	sprintf(db, " done!\n");
	sprintf(db, "  enable large buffer");
	debug(db);
#endif
	if( sock_recv_init( &highsock, newbuff, newbufflen )) {
		puts("\nCould not enable large buffer");
		exit(3);
	}
#ifdef DEBUG
	sprintf(db, " done!\n");
	debug(db);
#endif
}


longword getfilesize(FILE *f) {
	longword len;
	fseek(f, 0, SEEK_END); // go to end of file
	len = (longword)ftell(f);
	fseek(f, 0, SEEK_SET); // go to beginning of file
	return len;
}


int parse( byte * buff, int size ) {
	// handle received packet
	if( (buff[0] != 0) || (buff[1] < 1) || (buff[1] > 5) ) {
		return -1;
	}

	// parse packet
	switch(buff[1]) {
		case 1: // read request
			fname = buff + 2;
			mode  = buff + 2 + strlen((char*)fname) + 1;
#ifdef DEBUG
			sprintf(db, "Read Request file\n");
			debug(db);
			sprintf(db, "  File = '%s'\n  Mode = '%s'\n", fname, mode);
			debug(db);
#endif
			return 0;
		case 2: // write request
			fname = buff + 2;
			mode  = buff + 2 + strlen((char*)fname) + 1;
#ifdef DEBUG
			sprintf(db, "Write Request file\n");
			debug(db);
			sprintf(db, "  File = '%s'\n  Mode = '%s'\n", fname, mode);
			debug(db);
#endif
			return 0;
		case 3: // data
			blockno = (buff[2]<<8) + buff[3];
			datalen = size - 4;
#ifdef DEBUG
			sprintf(db, "Data Packet\n");
			debug(db);
			sprintf(db, "  Block # = %u\n  Size = %u\n", blockno, size);
			debug(db);
#endif
			return 0;
		case 4: // ack
			blockno = (buff[2]<<8) + buff[3];
#ifdef DEBUG
			sprintf(db, "Ack packet\n");
			debug(db);
			sprintf(db, "  Block # = %u\n", blockno);
			debug(db);
#endif
			return 0;
		case 5: // error
			errcode = (buff[2]<<8) + buff[3];
			errstring = buff + 4;
#ifdef DEBUG
			sprintf(db, "Error packet\n");
			debug(db);
			sprintf(db, "  Error # = %u\n  Message = '%s'\n", errcode, errstring);
			debug(db);
#endif
			return 0;
	} // end parse packet
	return 0;
}


int main(int argc, char *argv[]) {
	longword endprog, timeout;
	int  templen, ttt, binmode, lastnullpack, resend;
	long hisip, cip;
	word hisport, cport, blocknum, tempword;
	FILE *myfile;
	longword mysize, sentsofar, tosend;
	char savefn[255];

	puts("JKmicro TFPTD version 1.03");

	// start up the TCP stack and parse the config file
	other_init = usr_init;
	usr_init = my_init;
	sock_init();

	// command line args
	for( ttt = 1; ttt < argc; ttt++ ) {
		if( strcmp(argv[ttt], "-h") == 0) {         // check for -h
			puts("   Options:");
			puts("   -h    prints this help");
			puts("   <num> sets run time for TFTP");
			exit(0);
		} else {                                    // check for a numeral
			templen = sscanf(argv[ttt],"%d", &binmode);
			if( templen >=1 ) {                       // yes, it's a numeral
				timelimit = binmode;
			} else {
				printf("unknown option: %s (ignored)\n", argv[ttt]);
			}
		}
	}

	// command line arg will override the config file
	printf("  Server will run for %d seconds\n", timelimit);
	endprog = set_timeout( timelimit );

#ifdef DEBUG
	sprintf(db, "Starting main loop:");
	debug(db);
	sprintf(db, "  It will run for %u seconds\n", timelimit);
	debug(db);
#endif

	ttt = 0; // shut up the compiler

	do {
		tcp_tick(NULL);
#ifdef DEBUG
		sprintf(db, ".\n");
		debug(db);
#endif

		// set up lowsock on the main tftp port
		if( !udp_open(&lowsock, tftpport, 0, 0, NULL) ) {
			puts("\nCould not open socket for receive");
			exit(3);
		}
		if( sock_recv_init( &lowsock, bigbuff, bigbufflen )) {
			puts("\nCould not enable large buffer");
			exit(3);
		}

		// wait for a UDP packet or timeout waiting for one
		timeout = set_timeout( time_limit );
		templen = sock_recv_from(&lowsock, &hisip, &hisport, (char *)rspare, rsparelen, ttt);
		while( (!templen) && (!chk_timeout(timeout)) ) {
			tcp_tick(NULL);
			templen = sock_recv_from(&lowsock, &hisip, &hisport, (char *)rspare, rsparelen, ttt);
		}

		// handle timeout
		if( templen == 0) {
#ifdef DEBUG
			sprintf(db, "no client so far\n");
			debug(db);
#endif
			continue;  // break out of this while loop
		} else if( templen < 0 ) {
			sprintf(db, "error in the stack: %d\n", templen);
			debug(db);
			continue;
		}

		// parse the received packet
		if( parse(rspare, templen) ) {
			// error parsing packet
			sprintf(db, "error parsing packet\n");
			puts(db);
			continue;
		}

		// now handle the packet
		if( (rspare[1] != 1) && (rspare[1] != 2) ) {
			// not a RRQ or WRQ packet
			sprintf(db, "exepected packet type: %d\n", rspare[1]);
			puts(db);
			continue;
		} else if( rspare[1] == 1 ) {
		///////////////////////////////////////////////////////////////////////////
		//
		//           RRQ Request (client wants a file from us)
		//
		///////////////////////////////////////////////////////////////////////////

			// setup the new listening socket
			cip = ntohl(hisip);
			cport = ntohs(hisport);
			setup_trans_sock(altport, cip, cport);

			// setup to read from file
			if((mode[0] == 'o') || (mode[0] == 'O')) { // "octet" means binary mode
				binmode = 1;
			} else { // text mode
				binmode = 0;
			}
#ifdef DEBUG
			sprintf(db, "opening file %s for %s transfer\n", fname, binmode?"octet":"netascii");
			debug(db);
#endif
			myfile = fopen((const char*)fname, "rb");
			strcpy(savefn, (const char *)fname);
			if( myfile == NULL ) {
				//send error packet, reset, stay idle
				sspare[0] = 0;  // error packet
				sspare[1] = 5;
				sspare[2] = 0;  // file not found
				sspare[3] = 1;
				ttt = sprintf((char *)&sspare[4], "file %s not found", fname);
				sock_fastwrite(&highsock, sspare, ttt+5);
				sprintf(db, "can't open %s for reading", fname);
				puts(db);
				sock_close(&highsock);
				continue;
			}
#ifdef DEBUG
			sprintf(db, "--opened\n");
			debug(db);
#endif
			mysize = getfilesize(myfile);
#ifdef DEBUG
			sprintf(db, "file is %d bytes\n", mysize);
			debug(db);
#endif
			sentsofar = 0;
			blocknum = 1;
			lastnullpack = ((mysize % 512) == 0);

			while( (sentsofar < mysize) || lastnullpack ) {

				tosend = ((mysize-sentsofar) > 512) ? 512 : (mysize-sentsofar);
				if( tosend == 0 ) { // last packet is empty
					ttt = 0;
					lastnullpack = 0;
				} else {
					ttt = fread((void*)&sspare[4], sizeof(char), (size_t)tosend, myfile);
					if( ttt != tosend ) {
						//send error packet, reset, stay idle
						sspare[0] = 0;  // error packet
						sspare[1] = 5;
						sspare[2] = 0;  // undefined error
						sspare[3] = 0;
						ttt = sprintf((char *)&sspare[4], "read error (size mismatch)");
						sock_fastwrite(&highsock, sspare, ttt+5);
						sprintf(db, "tried to read %d byte(s) and got %d\n", tosend, ttt);
						puts(db);
						fclose(myfile);
						sock_close(&highsock);
						break;
					}
				}
				sspare[0] = 0;               // DATA packet
				sspare[1] = 3;
				tempword = htons(blocknum);  // block number
				sspare[2] = tempword % 256;
				sspare[3] = tempword / 256;
#ifdef DEBUG
				sprintf(db, "attempting to write %d byte(s) of data...\n", ttt+4);
				debug(db);
#endif
				sock_fastwrite(&highsock, sspare, ttt+4);
#ifdef DEBUG
				sprintf(db, "--done!\n");
				debug(db);
#endif
				blocknum++;
				sentsofar += ttt;

				// now wait for an ACK
				timeout = set_timeout( time_limit );
				templen = sock_recv_from(&highsock, &hisip, &hisport, (char *)rspare, rsparelen, ttt);
				while( !(templen>0) && (!chk_timeout(timeout)) ) {
					tcp_tick(NULL);
					templen = sock_recv_from(&highsock, &hisip, &hisport, (char *)rspare, rsparelen, ttt);
				}
				if( !(templen>0) ) {
#ifdef DEBUG
					sprintf(db, "timeout for ACK\n");
					debug(db);
#endif
					resend = 1;
				}
				parse(rspare, templen);
				if(rspare[1] != 4) {
#ifdef DEBUG
					sprintf(db, "wanted ACK, got %d\n", rspare[1]);
					debug(db);
#endif
					resend = 1;
				}
				if((blocknum-1) != blockno) {
#ifdef DEBUG
					sprintf(db, "wanted ACK (%d), got ACK (%d)\n", blocknum-1, blockno);
					debug(db);
#endif
					resend = 1;
				}
#ifdef DEBUG
				sprintf(db, "block %d sent successfully\n", blockno);
				debug(db);
#endif
				if( resend==1  ) {
					resend = 0;
					blocknum--;
					sentsofar -= templen;
					fseek(myfile, -templen, SEEK_CUR);
				}

			}

#ifdef DEBUG
			sprintf(db, "Sent file\n");
			debug(db);
#endif
			putsl("  sent file ");
			puts((const char *)savefn);
			fclose(myfile);
			sock_close(&highsock);

		} else if( rspare[1] == 2 ) {
		///////////////////////////////////////////////////////////////////////////
		//
		//           WRQ Request (client wants to send a file to us)
		//
		///////////////////////////////////////////////////////////////////////////

			// setup port on 10000
			cip = ntohl(hisip);
			cport = ntohs(hisport);
			setup_trans_sock(altport, cip, cport);

			// setup to write to a file
			if((mode[0] == 'o') || (mode[0] == 'O')) { // "octet" means binary mode
				binmode = 1;
			} else { // text mode
				binmode = 0;
			}
#ifdef DEBUG
			sprintf(db, "opening file %s for %s transfer\n", fname, binmode?"octet":"netascii");
			debug(db);
#endif
			myfile = fopen((const char*)fname, "wb");
			strcpy(savefn, (const char*)fname);
			if( myfile == NULL ) {
				// send error packet, reset, stay idle
				sprintf(db, "can't open %s for writing", fname);
				puts(db);
				sspare[0] = 0;  // error packet
				sspare[1] = 5;
				sspare[2] = 0;  // access violation
				sspare[3] = 4;
				ttt = sprintf((char *)&sspare[4], "can't open file %s for writing", fname);
				sock_fastwrite(&highsock, sspare, ttt+5);
				sock_close(&highsock);
				continue;
			}
#ifdef DEBUG
			sprintf(db, "--opened\n");
			debug(db);
#endif

			// send the first ACK
			blocknum = 0;
			sspare[0] = 0;               // ACK packet
			sspare[1] = 4;
			sspare[2] = blocknum / 256;  // block 0
			sspare[3] = blocknum % 256;
#ifdef DeBUG
			sprintf(db, "attempting to ACK block %d", blocknum);
			debug(db);
#endif
			sock_fastwrite(&highsock, sspare, 4);
#ifdef DEBUG
			sprintf(db, "--done!\n");
			debug(db);
#endif

			do {
				blocknum++;
				resend = 0;

				//    wait for DATA packet
				timeout = set_timeout( time_limit );
				templen = sock_recv_from(&highsock, &hisip, &hisport, (char *)rspare, rsparelen, ttt);
				while( !(templen>0) && (!chk_timeout(timeout)) ) {
					tcp_tick(NULL);
					templen = sock_recv_from(&highsock, &hisip, &hisport, (char *)rspare, rsparelen, ttt);
				}
				if( !(templen>0) ) {
#ifdef DEBUG
					sprintf(db, "timeout for DATA\n");
					debug(db);
#endif
					continue; // go ahead anyway
				}

				parse(rspare, templen);

				if(rspare[1] != 3) {
#ifdef DEBUG
					sprintf(db, "wanted DATA, got %d\n", rspare[1]);
					debug(db);
#endif
					resend = 1;
				}
				if(blocknum != blockno) {
#ifdef DEBUG
					sprintf(db, "wanted DATA (%d), got DATA (%d)\n", blocknum, blockno);
					debug(db);
#endif
					resend = 1;
				}
#ifdef DEBUG
				sprintf(db, "block %d received successfully\n", blockno);
				debug(db);
#endif

				if( resend == 1 ) {
					blocknum--;
					sspare[0] = 0;               // ACK packet
					sspare[1] = 4;
					sspare[2] = blocknum / 256;  // block #
					sspare[3] = blocknum % 256;
					sock_fastwrite(&highsock, sspare, 4);
					continue;
				}

				ttt = fwrite(&rspare[4], sizeof(char), (size_t)(templen-4), myfile);
				if( ttt != (templen-4) ) {
					sprintf(db, "tried to read %d byte(s) and got %d\n", tosend, ttt);
					puts(db);
					fclose(myfile);
					sock_close(&highsock);
					continue;
				}

				//    send ACK
				sspare[0] = 0;               // ACK packet
				sspare[1] = 4;
				sspare[2] = blocknum / 256;  // block #
				sspare[3] = blocknum % 256;
#ifdef DEBUG
				sprintf(db, "attempting to ACK block %d", blocknum);
				debug(db);
#endif
				sock_fastwrite(&highsock, sspare, 4);
#ifdef DEBUG
				sprintf(db, "--done!\n");
				debug(db);
#endif
			} while( ((templen-4) == 512) || (resend == 1) );   // any data packet < 512 bytes is the last one

#ifdef DEBUG
			sprintf(db, "file received successfully!");
			debug(db);
#endif
			putsl("  received file ");
			puts((const char *)savefn);

			// close file
			fclose(myfile);

			// close socket
			sock_close(&highsock);

		} else {
			// something seriously weird is going on
			sprintf(db, "I see a bad moon rising\n");
			puts(db);
		}

		sock_close(&lowsock);

	} while( ! chk_timeout(endprog) && !kbhit() );

	getch();

	return 0;
}
