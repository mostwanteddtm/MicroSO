/*	return true if input character is a digit
*/

isdigit(c)
unsigned char c;
{

  return ('0'<=c && c<='9');
}
