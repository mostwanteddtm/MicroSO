/*	return true if input character is a a control character
*/

iscntrl(c)
unsigned char c;
{

  return (0177==c || c<=037);
}
