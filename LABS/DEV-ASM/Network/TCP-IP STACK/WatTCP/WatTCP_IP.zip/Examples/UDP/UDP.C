#include <stdio.h>
#include <stdlib.h>
#include <tcp.h>
#include <conio.h>
//#include <newstruct.h>

#define SAMPLE 17


udp_Socket data;
char bigbuf[ 8192 ];

main(int argc, char *argv[])
{
	word templen;
	char spare[ 1500 ];

	sock_init();
	if ( !udp_open( &data, SAMPLE, 0xffffffff, SAMPLE, NULL) ) {
		puts("Could not open broadcast socket");
		exit( 3 );
	}

	/* set large buffer mode */
	if ( sock_recv_init( &data, bigbuf, sizeof( bigbuf ))) {
		puts("Could not enable large buffers");
		exit( 3 );
	}

	sock_mode( &data, UDP_MODE_NOCHK );	/* turn off checksums */

	while ( !kbhit() ) {
		tcp_tick( NULL );

		if ( templen = sock_recv( &data, spare, sizeof( spare ), NULL) ) {
		/* something received */
			printf("Got %u byte packet\n", templen );
		}
	}
	return 0;
}

