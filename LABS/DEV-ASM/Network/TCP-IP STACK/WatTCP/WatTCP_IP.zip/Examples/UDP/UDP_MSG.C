 #include <stdio.h>
#include <stdlib.h>
#include <tcp.h>
#include <string.h>
#include <conio.h>
//#include <newstruct.h>

#define SAMPLE 17


udp_Socket data;
char bigbuf[ 8192 ];

main(int argc, char *argv[])
{

	longword host;


	if (!(host = resolve( argv[1] ))) {
		printf("Unable to resolve '%s'\n", argv[1] );
		exit( 3 );
	}

	printf("Sending UDP message to [%s]",inet_ntoa(bigbuf, host));

	sock_init();
	if ( !udp_open( &data, SAMPLE, host, SAMPLE, NULL) ) {
		puts("Could not open socket");
		exit( 3 );
	}

	sock_mode( &data, UDP_MODE_NOCHK );	/* turn off checksums */


	tcp_tick( NULL );
	sock_write( &data, argv[2], strlen(argv[2]) );

	sock_close( &data );
	return 0;
}
