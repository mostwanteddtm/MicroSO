/*
	SERVER.CPP
	JK microsystems, Aug 2000
	Ed Wethrell

	Example of a WATTCP server that can handle multiple connections.

	Server listens on port 23, common to TELNET.
	After a connection is established, the commands 'start' and 'stop'
	instruct the server to begin (or end) sending data to the clinet.
	The data stream is the current system time.
	Sockets are processed in a round-robin manner.  The process_socket()
	function should execute as fast as possible to avoid clunky behavior.
	The program output the current state of each socket.

	Although this example is written in C, the borland C++ compiler is
	used to illustrate using it with the WATTCP library.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <time.h>

extern "C" {							// wattcp is a C library, we're using the C++ compiler
#include <tcp.h>
}

#define TALK_PORT 23

#define TRUE 1
#define FALSE (!TRUE)

const static max_sockets = 3;  			// maximum connections to the server

static tcp_Socket s[max_sockets];		// declare a socket structure for each server connection
unsigned char s_connected[max_sockets];	// is there a connection to socket[?] ?
int isStopped[max_sockets];      		// is stopped
char rbuffer[80];						// buffer for rx data
char tbuffer[80];						// buffer for tx data
time_t secs_now;						// to hold current time in seconds

void process_socket( int j ) {
	if( tcp_tick( &s[j] ) ) {
		if (sock_dataready( &s[j] )) {				// if there is data
			sock_gets( &s[j], (unsigned char *)rbuffer, sizeof( rbuffer ));

			if(!strcmp(rbuffer, "start")) {			// client starts data stream
				isStopped[j] = FALSE;
			}
			if(!strcmp(rbuffer, "stop")) {			// client stops data stream
				isStopped[j] = TRUE;
			}
		}

		// if client has requested data _AND_ the socket is open
		if( !isStopped[j] && sock_established( &s[j]) ) {
			time(&secs_now);							// get current time (in seconds)
			strncpy(tbuffer,ctime(&secs_now),24);		// put time into string w/o '/n'
			sock_puts(&s[j], (unsigned char *)tbuffer);	// send string
			tcp_tick( &s[j] );                       	// give stack some time
		}
	}
	else {   					// if client closed the connection
		isStopped[j] = TRUE;
		s_connected[j] = FALSE;
		sock_close( &s[j] );	// close socket
	}

	return;
}

#pragma argsused
int main( int argc, char *argv[] )
{
	int j;

	sock_init();		// start WATTCP

	// initialize the connection/status table and sockets
	for( j =0; j < max_sockets; j++ ) {
		s_connected[j] = FALSE;  						// no connection
		isStopped[j] = TRUE;       						// data transmit stopped
		tcp_listen( &s[j], TALK_PORT, 0, 0, NULL, 0 );	// open sockets for listen
		sock_mode( &s[j], TCP_MODE_ASCII );				// socket mode is ascii
		printf("%14d|",j);
	}
	puts(""); // new line

	// process incomming connections and
	// call process_socket to receive and send data

	j=0;
	while( !kbhit() ) {					 	// loop until keypress
		printf("%8.8s,%5.5s|",sockstate( &s[j] ), (isStopped[j] ? "Stop" : "Start") );

		if ( !tcp_tick( &s[j] ) ) {
			if( !s_connected[j] ) {					// only required when connection is closed by client
				tcp_listen(&s[j], TALK_PORT, 0, 0, NULL, 0 );		// recycle the socket
				sock_mode(&s[j], TCP_MODE_ASCII );
			}
			s_connected[j] = FALSE;			// update connection table
			isStopped[j] = TRUE; 			// reset sending data flag
		}
		if(sock_established( &s[j] ) ) {	// socket connection valid, update the connection table
			s_connected[j] = TRUE; 			// update the connection table
			process_socket( j );			// go check for incomming / outgoing messages
		}

		if ( ++j >= max_sockets ) j=0;		// back to the beginning
		if ( j==0 ) {
			time(&secs_now);							// get current time (in seconds)
//			strncpy(tbuffer,ctime(&secs_now),24);		// put time into string w/o '/n'
			printf(" %.13s\r", ctime(&secs_now)+11);			// CR to keep output pretty
		}

	}

	getch();							// gobble keypress
	puts("\n");


	return (0);

	sock_err:
		puts("Socket Error - program exiting...");

		exit(-1);			// bail out
		return (-1);		// not reached
}



