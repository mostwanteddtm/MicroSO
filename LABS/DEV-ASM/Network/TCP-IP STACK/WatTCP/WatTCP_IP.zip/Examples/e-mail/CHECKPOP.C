#include <tcp.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
//#include <bios.h>

#define MAIL_PORT 110
#define WAIT 5
#define RETRY_WAIT 10
#define TRUE 1
#define FALSE !TRUE

int sock_getline(void *sock, char *buffer, int len)
{
	int		i;
	unsigned char	ch;

	for (i = 0, --len; i <= len && sock_read(sock, &ch, 1) > 0; )	{
		if (ch == '\n')
			break;
		else if (ch != '\r') {
			*buffer++ = ch;
			++i;
		}
	}
	*buffer = '\0';
	return (i);
}

char aa[6000];
int i, j, msgs=0, current_msgs, check_wait;
char ch;
char R[6000];
static tcp_Socket s;
char host[50], user[20], paswd[20];
longword remoteip;
int status;
FILE *fp;
char blink=FALSE;
long ticks;

time_t t;


int main(int argc, char *argv[])
{
	sock_init();
	if (argc < 5) {
		puts("Missing arguments");
		puts("Useage: checkpop <user> <host> <passwd> <delay between checks (seconds)>");
		puts("");
		exit (1);
	}

	strcpy( user, argv[1] );
	strcpy( host, argv[2] );
	strcpy( paswd, argv[3] );
	check_wait = atoi( argv[4] );

	if (!( remoteip = resolve( host ))) {
		printf("\n\rUnable to resolve '%s'\n\r", host );
		exit( 2 );
	}

	if ( !tcp_open( &s, WAIT, remoteip, MAIL_PORT, NULL )) {
		puts("Unable to open connection.");
		exit( 3 );
	}

	sock_mode( &s, TCP_MODE_BINARY );
	sock_wait_established( &s, WAIT, NULL, &status);
	tcp_tick( &s );

	while ( ch != 'q' ) {

		if ( kbhit() ) {
			ch = getch();
		}
		if (ch == 'r') {
			blink = FALSE;
			outportb(0x3fc, inportb(0x3fc) & 0xFE);
			ch='\0';
		}
		else if (ch == '\0' || ch=='c') {
			ch='\0';
			if ( !tcp_open( &s, WAIT, remoteip, MAIL_PORT, NULL )) {
				puts("Unable to open connection.");
				exit( 3 );
			}
			sock_wait_established( &s, WAIT, NULL, &status);
			tcp_tick( &s );

			printf("Connect %s.. ", host);

			sock_wait_input( &s, WAIT, NULL, &status );
			i=sock_getline( &s, R, sizeof( R ));

			sprintf(R,"USER %s\r\n", user);
			sock_puts(&s, (unsigned char *)R);					// user name
			R[0]='\0';
			sock_wait_input( &s, WAIT, NULL, &status );
			i=sock_getline( &s, R, sizeof( R ));

			sprintf(R,"PASS %s\r\n", paswd);
			sock_puts(&s,(unsigned char *)R);					// password
			R[0]='\0';
			sock_wait_input( &s, WAIT, NULL, &status );
			i=sock_getline( &s, R, sizeof( R ));
			if (R[0] == '-') {
				sock_puts( &s, (unsigned char *)"QUIT\r\n" );	// logout
				sock_wait_input( &s, WAIT, NULL, &status );
				i=sock_getline( &s, R, sizeof( R ));
				printf("S: %3d %s\n",i,R);
				sock_wait_closed(&s, sock_delay, NULL, &status);
			}

			sock_puts(&s,(unsigned char *)"STAT\r\n");					// get box status
			printf("logged in, ");
			R[0]='\0';
			sock_wait_input( &s, WAIT, NULL, &status );
			i=sock_getline( &s, R, sizeof( R ));

			if ( (current_msgs=atoi(R+3)) > msgs && (msgs > 0)) {
				printf(" MAIL %d, ", current_msgs - msgs);
				blink=TRUE;
				msgs = current_msgs;
			}
			else
				msgs = current_msgs;

			if (current_msgs < msgs)
				msgs = current_msgs;

			if ( blink ) {
				outportb(0x3fc, inportb(0x3fc) | 0x1);
			}

			sock_puts( &s, (unsigned char *)"QUIT\r\n" );	// logout

			t = time(NULL);
			printf("logout. %s", ctime(&t)+4 );

			R[0]='\0';
			sock_wait_input( &s, WAIT, NULL, &status );
			i=sock_getline( &s, R, sizeof( R ));
			sock_wait_closed(&s, sock_delay, NULL, &status);
		}
sock_err:
		if (ch=='q') break;
		switch ( status ) {
			case 1 :
//				puts("Connection closed");
				ticks = set_timeout(check_wait);
				while (!kbhit() && !chk_timeout(ticks) ) {
					;
				}
			break;
			case -1:
				puts("REMOTE HOST CLOSED CONNECTION");
				ticks = set_timeout(RETRY_WAIT);
				while (!kbhit() && !chk_timeout(ticks) ) {
					;
				}
			break;
		}


  }
  if ( kbhit() )
	getch();
  return 0;
}
