smtp <host> <file>

where <host> is the smtp mail host in either name (mail.foo.com)
or IP form and the file is the name of a file that contains an RFC821
format mail message. the program automatically inserts the FROM and TO
headers so the first 2 lines just contain the senders e-mail address
and the recipients e-mail address.  if a subject or other information
is required, the appropriate headings need to be in the file.  

for example:

        smtp mail.foo.com test.txt

where test.txt contains:
        test@foo.com
        edw@jkmicro.com
        subject: test
        another test

sends an email from test@foo.com to edw@jkmicro.com
with a subject of 'test' and a message text of 'another test'.