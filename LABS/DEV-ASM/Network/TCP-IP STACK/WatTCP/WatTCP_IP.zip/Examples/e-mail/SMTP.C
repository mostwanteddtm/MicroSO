#include <tcp.h>
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>

#define SMTP_PORT 25
#define WAIT 5
#define RETRY_WAIT 10
#define TRUE 1
#define FALSE !TRUE

int sock_getline(void *sock, char *buffer, int len)
{
	int		i;
	unsigned char	ch;

	for (i = 0, --len; i <= len && sock_read(sock, &ch, 1) > 0; )	{
		if (ch == '\n')
			break;
		else if (ch != '\r') {
			*buffer++ = ch;
			++i;
		}
	}
	*buffer = '\0';
	return (i);
}


static tcp_Socket s;

int main(int argc, char *argv[])
{
	char aa[1000], R[1000];
	FILE *fp;
	int ok=TRUE;
	char host[50];
	longword remoteip;
	int status;
	int i;

	sock_init();
	if (argc < 3) {
		puts("Missing arguments");
		puts("Useage: smtp <host> <file>");
		puts("");
		exit (1);
	}

	strcpy( host, argv[1] );
	if ( !(fp= fopen(argv[2],"r") ) ) {
		printf("Unable to open message file %s\n",argv[2]);
		puts("");
		exit (1);
	}

	printf("Sending %s to %s mail server\n", argv[2], host);

	if (!( remoteip = resolve( host ))) {
		printf("\n\rUnable to resolve '%s'\n\r", host );
		exit( 2 );
	}

	if ( !tcp_open( &s, WAIT, remoteip, SMTP_PORT, NULL )) {
		puts("Unable to open connection.");
		exit( 3 );
	}

	sock_mode( &s, TCP_MODE_BINARY );
	sock_wait_established( &s, WAIT, NULL, &status);
	tcp_tick( &s );

	printf("Connect %s.. \n", host);

	sock_wait_input( &s, WAIT, NULL, &status );
	i=sock_getline( &s, R, sizeof( R ));

	ok=TRUE;

	while (ok) {
		sprintf(R,"HELO %s\r\n", inet_ntoa( aa, gethostid()));
//		printf("%s",R);
		sock_puts(&s, (unsigned char *)R);					// log in
		R[0]='\0';
		sock_wait_input( &s, WAIT, NULL, &status );
		i=sock_getline( &s, R, sizeof( R ));
//		printf("%s\n",R);
		if (atoi(R) != 250) {			// was login valid?
			ok=FALSE;
			break;
		}

		fgets(aa, 256, fp);
		aa[strlen(aa)-1] ='\0';								// eat new line
		sprintf(R,"MAIL FROM:<%s>\r\n", aa);
//		printf("%s",R);
		sock_puts(&s,(unsigned char *)R);					// message from
		R[0]='\0';
		sock_wait_input( &s, WAIT, NULL, &status );
		i=sock_getline( &s, R, sizeof( R ));

		if (atoi(R) != 250) {			// was FROM line valid?
			ok=FALSE;
			break;
		}
//		printf("%s\n",R);

		fgets(aa, 256, fp);
		aa[strlen(aa)-1] ='\0';								// eat new line
		sprintf(R,"RCPT TO:<%s>\r\n", aa);
		printf("%s",R);
		sock_puts(&s,(unsigned char *)R);					// message to
		R[0]='\0';
		sock_wait_input( &s, WAIT, NULL, &status );
		i=sock_getline( &s, R, sizeof( R ));

		if (atoi(R) != 250) {			// was TO line valid?
			ok=FALSE;
			break;
		}
//		printf("%s\n",R);

		sprintf(R,"DATA\r\n" );
		sock_puts(&s,(unsigned char *)R);					// start message body
		R[0]='\0';
		sock_wait_input( &s, WAIT, NULL, &status );
		i=sock_getline( &s, R, sizeof( R ));
//		printf("%s\n",R);

		while ( fgets(R,256,fp)  ) {
//			printf("%s",R);
			sock_puts(&s,(unsigned char *)R);					// message body
			tcp_tick(&s);
		}

		sprintf(R,"\r\n.\r\n" );
		sock_puts(&s,(unsigned char *)R);					// end message body
		R[0]='\0';
		sock_wait_input( &s, WAIT, NULL, &status );
		i=sock_getline( &s, R, sizeof( R ));
//		printf("%s\n",R);

		sock_puts( &s, (unsigned char *)"QUIT\r\n" );	// logout
		R[0]='\0';
		sock_wait_input( &s, WAIT, NULL, &status );
		i=sock_getline( &s, R, sizeof( R ));
		sock_wait_closed(&s, sock_delay, NULL, &status);
//		printf("%s\n",R);

sock_err:
		switch ( status ) {
			case 1 :
				puts("Connection closed");
				break;
			case -1:
				puts("REMOTE HOST CLOSED CONNECTION");
				break;
		}

		ok=FALSE;
		R[0]='\0';

	}

	if (!ok)
		printf("%s",R);

	fclose( fp );

	if ( kbhit() )
		getch();

	return 0;
}

