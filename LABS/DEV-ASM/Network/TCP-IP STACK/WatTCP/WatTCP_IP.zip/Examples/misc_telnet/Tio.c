#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <tcp.h>
#include <bios.h>

#define TALK_PORT 23
#define FALSE 0
#define TRUE (!FALSE)


int sock_getline(void *sock, char *buffer, int len)
{
	int		i;
	unsigned char	ch;

	for (i = 0, --len; i <= len && sock_read(sock, &ch, 1) > 0; )	{
		if (ch == '\n')
			break;
		else if (ch != '\r') {
			*buffer++ = ch;
			++i;
		}
	}
	*buffer = '\0';
	return (i);
}

int main( void )
{
	static tcp_Socket s;

	char buffer[ 80 ], rbuffer[80];
	int status;
	int i,j, mask;

	sock_init();

	puts("\nTelnet IO\n");

	printf("My address is: [%s]\n\r", inet_ntoa( buffer, gethostid()));

	outportb(0xF874, inportb(0xF874) & 0xF8 );		// set port 3, 0-2 as output
	outportb(0xF872, inportb(0xF870) & 0xF8 );		// clear the bits we're using

	puts("Waiting for an incomming request...");
	while ( !kbhit() ) {
		tcp_listen( &s, TALK_PORT, 0, 0, NULL, 0 );
		sock_mode( &s, TCP_MODE_ASCII );
		sock_wait_established( &s, 1, NULL, &status);
		tcp_tick( &s );

		puts("Connection established");

		sock_puts( &s, (unsigned char *)"Connected to the uFlash" );
		sock_puts( &s, (unsigned char *)"Enter the number of the bit (0-2) you want" );
		tcp_tick( &s );
		sock_puts( &s, (unsigned char *)"to toggle followed by a CR" );
		sock_puts( &s, (unsigned char *)"press Q followed by a CR to close the connection" );

		while ( !kbhit()  && (_chk_socket(&s) == 2) ) {
			tcp_tick( &s );
			if (sock_rbused( &s ) > 2 )	{
				i=sock_getline( &s, rbuffer, sizeof( rbuffer ));
//				puts(rbuffer);			// print receive buffer

				if ( rbuffer[0] == 'q' || kbhit() ) {
					sock_close( &s );
					sock_wait_closed(&s, NULL, NULL, &status);		// shut it down
					break;
				}

				if ( (j=atoi(rbuffer)) >=0 && j < 3 ) {
					mask = 1 << j;								// create bit mask (shift left j times)
					outportb(0xF872, inportb(0xF870) ^ mask);		// toggle the port bit (port xor mask)
				}

			}
		}
		if (!kbhit() )
			puts("\nWaiting for an incomming request...");

sock_err:
		switch ( status ) {
			case 1 : puts("Connection closed");
						if ( kbhit() ) {
							getch();
							return(0);
						}
						else
							puts("\nWaiting for an incomming request...");
				break;
			case -1:
				break;
		}
	}

	if ( kbhit() )
		getch();

	exit (0);
	return(0);		// never reached

}


