#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <dos.h>
#include "include\wattcp.h"
#include "include\elib.h"
#include "include\tcp.h"

#define TALK_PORT 23


void init( void )
{
        printf("%c[40BChannel open:\n\n\n\n",27);
}

void add_msg( char *source, char *msg )
{
        printf("%c%c[2A%s: %s\n\n",13,27,source,msg);
	printf("%60c\n",32);
}

int main(int argc, char *argv[])
{
    longword remoteip;
    char *host;
    char dummyuser[ 80 ], dummyruser[80], dummyhost[80];

    char buffer[ 80 ], rbuffer[80], ch;
    word position;
    word sendit, who_closed = 0;
    int status;

    static tcp_Socket s;    /*, s2;*/
    char *user, *remoteuser;

    sock_init();

    clrscr();
    puts("TCPTALK : (experimental version)\n\n\r");

    user = "me";	/* default */

    if (argc < 2) {
        puts("TCPTALK  [remote_user_id@]remote_host  [my_user_id]");
        puts("\n\r\nWaiting for an incomming call\n\r\n");
        printf("(My address is [%s]\n\r", inet_ntoa( buffer, gethostid()));

	tcp_listen( &s, TALK_PORT, 0, 0, NULL, 0 );
	sock_mode( &s, TCP_MODE_ASCII );
	sock_wait_established( &s, 0, NULL, &status);

        printf("Connection established\r");

	sock_wait_input( &s, sock_delay, NULL, &status );
	sock_gets( &s, dummyhost, sizeof( dummyhost ));
	sock_wait_input( &s, sock_delay, NULL, &status );
	sock_gets( &s, remoteuser = dummyruser, sizeof( dummyruser ));
	sock_puts( &s, "ok" );

        puts("\n\rPress any to go to TALK session.\n\r");
        while( !kbhit() ) {;}
	getch();

	sock_puts( &s, "<answerring your call>" );

        init();
    }
    else {
	remoteuser = "other";
	if ( (host = strchr( argv[1], '@')) != NULL ) {
	    *host++ = 0;
	    remoteuser = argv[1];
	} else
	    host = argv[1];

	if (!( remoteip = resolve( host ))) {
            printf("\n\rUnable to resolve '%s'\n\r", host );
	    exit( 3 );
	}

	if ( argc < 3 ) {
            puts("Userid to assume:");
	    user = gets( dummyuser );
	    puts("\n\r");
	} else
            printf("Using '%s' as local userid\n\r", user);

	if ( !tcp_open( &s, 0, remoteip, TALK_PORT, NULL )) {
            puts("Unable to open connection.");
	    exit( 1 );
	}
	sock_mode( &s, TCP_MODE_ASCII );
	sock_wait_established( &s, sock_delay,NULL, &status);
	sock_puts( &s, inet_ntoa(buffer,gethostid()));
	sock_puts( &s, user );
	sock_wait_input( &s, sock_delay, NULL, &status );

	sock_gets( &s, buffer, sizeof( buffer ));
	if ( stricmp( buffer, "ok" )) {
	    sock_close( &s );
            puts("Remote side did not wish to connect");
            printf("MSG: %s\n", buffer);
	    sock_wait_closed( &s, sock_delay, NULL, &status );
	    exit( 1 );
	}
	init();
	add_msg( remoteuser, "< remote user has not answerred yet, waiting...>");
	sock_wait_input( &s, 0, NULL, &status );
    }

    /* we are connected */

    add_msg( remoteuser, "connected");
    *buffer = position = sendit = 0;

    while ( tcp_tick( &s ) ) {
	if (kbhit()) {
	    if ((ch = getch()) == 27) {
		sock_close( &s );
		who_closed = 1;
		break;
	    }
	    switch (ch) {
	       case '\r' : sendit = 1;
			   break;
	       case '\b' : buffer[ --position ] = 0;
                           printf("%c %c",8,8);
			   break;
	       case '\t' : ch = ' ';
	       default   : buffer[ position++ ] = ch;
			   buffer[ position ] = 0;
                           putchar( ch );
	    }
	    if (sendit) {
		sock_puts( &s, buffer );
		add_msg( user , buffer);
		delline();
		sendit = 0;
		position = *buffer = 0;
	    }
	}

	if (sock_dataready( &s )) {
	    sock_gets( &s, rbuffer, sizeof( rbuffer ));
	    add_msg( remoteuser, rbuffer );
	}
    }


    if ( who_closed == 1 ) {
        puts(" *** YOU CLOSED CONNECTION *** ");
	sock_wait_closed(&s, sock_delay, NULL, &status);
    } else
        puts(" *** OTHER PERSON CLOSED CONNECTION *** ");

    sleep( 1 );
    while (kbhit()) getch();
    getch();

    exit( 0 );

sock_err:
    switch ( status ) {
       case 1 : puts("Connection closed");
		break;
       case -1: puts("REMOTE HOST CLOSED CONNECTION");
		break;
    }
    exit( 0 );
    return (0);  /* not reached */
}


