#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <dos.h>
#include <tcp.h>
#include <bios.h>

#define TALK_PORT 23
#define FALSE 0
#define TRUE (!FALSE)

#define DATA	base
#define IER		base+1
#define IIR		base+2
#define LCR		base+3
#define MCR		base+4
#define LSR		base+5
#define MSR		base+6

#define COMBUF_SIZE 2048
#define FULL_FLAG 10

#define SERIAL_TIMEOUT 5

static int base=0x3F8;		/* com 1  */

//static char rxchar;
static char isr=FALSE;
static int chars;
static char combuf[COMBUF_SIZE+1];
static char *head, *tail, buf_full;

void interrupt (*oldirq)();

/* ISR for UART interrupt */
void interrupt comint() {
	disable();

	if ( ++head >= combuf+COMBUF_SIZE)
		head = combuf;
	if (tail == NULL)
		tail = combuf;
	if ( chars < COMBUF_SIZE ) {
		buf_full=FALSE;
		chars++;
	}
	else {
		buf_full=TRUE;
		if (++tail >= combuf+COMBUF_SIZE)
			tail=combuf;
	}
	if ( chars > COMBUF_SIZE-FULL_FLAG )
		buf_full=TRUE;

	*head = inportb(DATA);

	isr=TRUE;

	outportb(0x20,0x20);	/* reset PIC */
	enable();
}



void init( void )
{
		printf("Channel open:\n\n",27);
}

void init_com( int irq )
{
	int irqmask;
	irqmask = 1 << irq;

	/* set up port 9600,8,n,1 */
	outportb(LCR,0x80);	/* divisor latch access */
	outportb(DATA,0x02);	/* baud rate divisor low */    // 0x0C for 9600 , 0x60 for 1200, 0x02=56.7k
	outportb(IER,0x00);	/* baud rate divisor hi */
	outportb(LCR,0x03);	/* 8,1,n */

	outportb(IER,0x1);           /* enable RX interrupts */

/* calculate irq mask bit for PIC */
	disable();					/* disable interrupts */

	oldirq=getvect(irq+8);          /* get old IRQ vector */
	setvect(irq+8,comint);
	outportb(0x21,inportb(0x21)&~irqmask);

	enable();

	printf("old vector:%Fp new vector:%Fp ISR:%Fp\n",oldirq,getvect(irq+8),comint);
	printf("Port: %X IRQ: %d Mask: %X\n",DATA,irq,irqmask);

/* end interrupt enable */
}

void kill_com( int irq )
{
	int irqmask;
	irqmask = 1 << irq;

	/* turn off interrupt stuff */
	disable();
	outportb(IER,0);
	setvect(irq+8,oldirq);
	outportb(0x21,inportb(0x21) | irqmask );

	printf("\nreset vector to:%Fp\n",getvect(irq+8) );
	printf("PIC: %X ",(int)inp(0x21));
	enable();
}

int move_buf(char *out)
{
	int i;
	i=chars;
	while ( chars > 0 ) {
//		putch(*tail);
		*(out++) = *(tail++);
		chars--;

		if (tail >= combuf+COMBUF_SIZE)
			tail=combuf;
	}

	buf_full = FALSE;
	*out = '\0';
	return (i);
}

int main( void )
{
	char dummyhost[80];
	char rbuffer[80];

//	word sendit=FALSE, who_closed = 0;
	word who_closed = 0;
	int status;

	static tcp_Socket s;

	long len;
	long ticks;
//	int j;
	int i, t_len;
	char *ptr;
	char tbuff[1024];
//	char c;

	int irq=4;

	chars = 0;
	head=combuf+COMBUF_SIZE;
	tail=NULL;
	combuf[1+COMBUF_SIZE]='\0';

	printf("%p %p %p %d %p %p %p %p %d\n",combuf,head,tail,chars, &(combuf[0]),
			&(combuf[COMBUF_SIZE]),&head, &tail, COMBUF_SIZE);
	sock_init();

	puts("\nWaiting for an incomming call");
	printf("(My IP= %s)\n\n", inet_ntoa( dummyhost, gethostid()));

	tcp_listen( &s, TALK_PORT, 0, 0, NULL, 0 );
	sock_mode( &s, TCP_MODE_ASCII );
	sock_wait_established( &s, 0, NULL, &status);

	printf("Connection established\n");

	sock_wait_input( &s, sock_delay, NULL, &status );
	sock_gets( &s, (unsigned char *)dummyhost, sizeof( dummyhost ));
	sock_wait_input( &s, sock_delay, NULL, &status );
	sock_puts( &s, (unsigned char *)"ok" );
	sock_puts( &s, (unsigned char *)"<answering your call>" );

	init();

	init_com ( irq );

	/* we are connected */

	puts( "connected" );
//	sendit = 0;

	while ( tcp_tick( &s ) ) {
		if (kbhit()) {
			if (getch() == 27) {
				sock_close( &s );
				who_closed = 1;
				break;
			}
		}
		if (sock_dataready( &s )) {
			sock_gets( &s, (unsigned char *)rbuffer, sizeof( rbuffer ));
//			c=(char)atoi(rbuffer);
			puts( rbuffer );
//			sendit=TRUE;
		}

		if ( buf_full || (!isr && chk_timeout(ticks)) && (chars > 0))  {
			len = move_buf(tbuff);
			ptr = tbuff;
//			printf("%s %d\n",ptr,len);

			while ( len > 0L ) {
				t_len = (len < (long)(i=sock_tbleft( &s )) ) ? (int)len : i;

				if ( !t_len ) { 		// if no space available, dont try to send anything
					tcp_tick( &s );
					kbhit();
				}

				if ( sock_fastwrite( &s, (byte *)ptr, t_len ) != t_len ) {
					printf( "ERROR: sock_write\n");
					sock_abort( &s );
					break;
				}
				ptr+= t_len;

				len -= (long)t_len;		// len = length left to send
				tcp_tick( &s );
			}
		}
		if (isr) {
			ticks=set_timeout(SERIAL_TIMEOUT);			// set timeout
			isr=FALSE;
//			puts(combuf);
//			printf("%p %p %p %d %c\n",combuf,head,tail,chars, *(head));
		}
	}

	if ( who_closed == 1 ) {
		puts(" *** CONNECTION CLOSED *** ");
		sock_wait_closed(&s, sock_delay, NULL, &status);
	} else
		puts(" *** CONNECTION BROKEN *** ");

	while ( kbhit() )
		getch();

	kill_com(irq);
	exit( 0 );


sock_err:
	switch ( status ) {
	   case 1 : puts("Connection closed");
		break;
	   case -1: puts("REMOTE HOST CLOSED CONNECTION");
		break;
	}
	exit( 0 );
	return (0);  /* not reached */
}


