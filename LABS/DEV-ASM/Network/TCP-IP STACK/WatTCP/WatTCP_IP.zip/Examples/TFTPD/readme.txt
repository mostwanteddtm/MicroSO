A TFTP client can be obtained from 
http://www.weird-solutions.com