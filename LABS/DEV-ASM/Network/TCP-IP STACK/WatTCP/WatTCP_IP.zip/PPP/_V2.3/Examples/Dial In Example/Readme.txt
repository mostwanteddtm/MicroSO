Intoduction:
	Note that while this example will work you don't need to run it.
It is more meant for you to read the files in this directory so that you
may later create and edit your own.

Parts:
	To use this example you need:
	1 JK Microsystems Boards (with free serial port)
	1 Modem cable (see the PPP manual for help)
	1 Modem
	A computer to call the board

Instructions:
	Connect the modem to COM1 of the board with the cable
Load "open.ppp" "close.ppp" "Goppp.bat" and "Noppp.bat" files onto the
board.
	Make sure the NE2000 packet driver for ethernet is not loading.
This only applies if the board is a uFlashTCP, FlashTCP, Logicflex or
Ether6.  Essentially it applies to any board with ethernet built in.
	You may either edit startup.bat to comment out the line that
loads NE2000, or you may unload it after the fact.
	Once you have the board and modem connected and powered and
NE2000 is not loaded, type "goppp" to load ppp and start the connection.
After you have done this, the modem will answer on the first ring and
will try to connect with PPP, you will need another computer (anything
with PPP will work) to dial into this board's modem and connect.
	In this configuration the board is acting like an ISP.  It will
use the IP address 10.1.1.1 and the dialing in computer will use the
address 10.1.1.2.  The username and password are "Username" and "Password",
the authentication protocol is PAP.  After you type goppp the board will
wait 10min for a connection and then fail.
	To close the link, type noppp.