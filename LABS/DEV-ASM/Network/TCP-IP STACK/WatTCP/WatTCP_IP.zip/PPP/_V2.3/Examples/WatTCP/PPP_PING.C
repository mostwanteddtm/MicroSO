#include <stdio.h>
#include <dos.h>
#include <conio.h>

#include "ppplib.h"

#include "wattcp.h"
#include "tcp.h"

#include <stdlib.h>
#include <string.h>

char open_ppp[]="open.ppp\0";
char close_ppp[]=
"@F\r\n\
@w18\r\n\
@O+++\r\n\
@w18\r\n\
@OATH\\n\\r\r\n\
@w18\r\n\
@F\r\n\0";

longword sent = 0L;
longword received = 0L;
longword tot_delays = 0L;
longword last_rcvd = 0L;
char *name;

void stats(void)
{
	longword temp;

	puts("\nPing Statistics");
	printf("Sent        : %lu \n", sent );
	printf("Received    : %lu \n", received );
	if (sent)
		printf("Success     : %lu \%\n", (100L*received)/sent);
	if (!received)
		printf("There was no response from %s\n", name );
	else {
		temp = ( tot_delays * 2813L)/(512L*received + 1);
		printf("Average RTT : %lu.%02lu seconds\n", temp / 100L, temp % 100L);
	}

	PPPClose();
	exit( received ? 0 : 1 );
}

void help(void)
{
	puts("PPP [-s|/s] hostname [number]");
	exit( 3 );
}


int main(int argc, char **argv)
{
	longword host, timer, new_rcvd;
	longword tot_timeout = 0L, itts = 0L, send_timeout = 0L;
	word i;
	word sequence_mode = 0, is_new_line = 1;
	unsigned char tempbuffer[255];

	unsigned long tmp;
	char buffer[24], buffer2[128];

#ifdef _DEBUG
	char *ptr;
	unsigned int open_debug_level=1;

	if ( (ptr=getenv("DEBUG")) != NULL)  {
		open_debug_level = atoi(ptr);
		printf("open_debug_level set to %d (from environment).\n", open_debug_level);
	}
#endif

	if ( argc < 2 )
		help();

	if ( PPPInit( 0x61 ) ) {
		printf("ppp driver not found, exiting..\n");
		return;
	}

	if ( !PPPISOPEN( PPPStatus() )  ) {		// try and open the connection
		printf("ppp not connected, opening...\n");
#ifdef _DEBUG
		PPPSetRespLevel( open_debug_level );
		printf("open script: %d close script: %d\n",strlen(open_ppp), strlen(close_ppp) );
#endif

		if ( PPPOpen( open_ppp, close_ppp, TRUE ) ) {
			printf("connect failed, exiting...\n");
			return;
		}

#ifdef _DEBUG
		PPPSetRespLevel( 1 );
#endif
	}

	puts("");
	tmp=PPPLocalIP();
	sprintf( buffer,"%d.%d.%d.%d", (int)(tmp >> 24), (int)((tmp >> 16) & 0xFF), (int)((tmp >> 8) & 0xFF),
										(int)(tmp & 0xFF) );
	printf("My IP: %s\n", buffer);

	tmp=PPPRemoteIP();
	printf("Remote IP: %d.%d.%d.%d\n", (int)(tmp >> 24), (int)((tmp >> 16) & 0xFF), (int)((tmp >> 8) & 0xFF),
											(int)(tmp & 0xFF) );

	sock_init();
	printf("\nWATTCP.CFG address is: [%s]\n", inet_ntoa( buffer2, gethostid()));

	my_ip_addr = resolve( buffer );		// change IP address to what PPP gave us
	_arp_add_gateway( buffer, 0L);		// change gateway

	printf("new address is: [%s]\n\n", inet_ntoa( buffer2, gethostid()));


	name = NULL;
	for ( i = 1; i < argc ; ++i ) {
		if ( !stricmp( argv[i], "-s") || !stricmp( argv[i],"/s"))
			sequence_mode = 1;
		else if ( !name )
			name = argv[i];
		else {
			sequence_mode = 1;
			itts = atol( argv[i] );
		}
	}
	if (!name)
		help();

	if (!(host = resolve( name ))) {
		printf("Unable to resolve '%s'\n", name );
		exit( 3 );
	}
	if ( isaddr( name ))
		printf("Pinging [%s]",inet_ntoa((char *)tempbuffer, host));
	else
		printf("Pinging '%s' [%s]",name, inet_ntoa((char*)tempbuffer, host));

	if (itts)
		printf(" %u times", itts);
	else
		itts = sequence_mode ? 0xffffffffL : 1;

	if (sequence_mode)
		printf(" once per_second");

	printf("\n");

	if (itts+10 > 10)
		tot_timeout = set_timeout( (unsigned)itts + 10 );

	_arp_resolve( host, (eth_address *)tempbuffer, 0 );   // resolve it before timer starts

	do {
		/* once per second - do all this */
		if ( chk_timeout( send_timeout ) || !send_timeout ) {
			send_timeout = set_timeout( 1 );
			if ( chk_timeout( tot_timeout ) && tot_timeout )
				stats();
			if ( sent < itts ) {
				sent++;
				if (_ping( host, sent ))
					stats();
				if (!is_new_line)
					printf("\n");
				printf("sent PING # %lu ", sent );
				is_new_line = 0;
			}
		}

		if ( kbhit() ) {
			getch();		// trash the character
			stats();		// print the results and exit
		}

		tcp_tick(NULL);
		if ((timer = _chk_ping( host , &new_rcvd)) != 0xffffffffL) {
			tot_delays += timer;
			++received;
			if ( new_rcvd != last_rcvd + 1 ) {
				if (!is_new_line) printf("\n");
					puts("PING receipt received out of order!");
				is_new_line = 1;
			}
			last_rcvd = new_rcvd;
			if (!is_new_line)
				printf(", ");
			printf("PING receipt # %lu : response time %lu.%02lu seconds\n",
					received, timer / 18L, ((timer %18L)*55)/10 );
			is_new_line = 1;
			if ( received == itts )
				stats();			// print the results and exit
		}
	} while (1);

}
