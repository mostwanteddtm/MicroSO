/*
	SERVER.C
	JK microsystems, March 2002
	Ed Wethrell

	Example of a server w/ PPP dial in that can handle multiple socket connections.

	Server listens on port 23, common to TELNET.
	After a connection is established, the commands 'start' and 'stop'
	instruct the server to begin (or end) sending data to the clinet.
	The data stream is the current system time.
	Sockets are processed in a round-robin manner.  The process_socket()
	function should execute as fast as possible to avoid clunky behavior.
	The program outputs the current state of each socket.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <time.h>

#include <tcp.h>

#include "ppplib.h"

#define TALK_PORT 23

#define TRUE 1
#define FALSE (!TRUE)

#define END_CHAR 0x27

char open_ppp[]="open.ppp\0";
char close_ppp[]="close.ppp\0";

#define max_sockets 3  			// maximum connections to the server

static tcp_Socket s[max_sockets];		// declare a socket structure for each server connection
unsigned char s_connected[max_sockets];	// is there a connection to socket[?] ?
int isStopped[max_sockets];      		// is stopped
char rbuffer[80];						// buffer for rx data
char tbuffer[80];						// buffer for tx data
time_t secs_now;						// to hold current time in seconds

void process_socket( int j ) {
	if( tcp_tick( &s[j] ) ) {
		if (sock_dataready( &s[j] )) {				// if there is data
			sock_gets( &s[j], (unsigned char *)rbuffer, sizeof( rbuffer ));

			if(!strcmp(rbuffer, "start")) {			// client starts data stream
				isStopped[j] = FALSE;
			}
			if(!strcmp(rbuffer, "stop")) {			// client stops data stream
				isStopped[j] = TRUE;
			}
		}

		// if client has requested data _AND_ the socket is open
		if( !isStopped[j] && sock_established( &s[j]) ) {
			time(&secs_now);							// get current time (in seconds)
			strncpy(tbuffer,ctime(&secs_now),24);		// put time into string w/o '/n'
			sock_puts(&s[j], (unsigned char *)tbuffer);	// send string
			tcp_tick( &s[j] );                       	// give stack some time
		}
	}
	else {   					// if client closed the connection
		isStopped[j] = TRUE;
		s_connected[j] = FALSE;
		sock_close( &s[j] );	// close socket
	}

	return;
}

#pragma argsused
int main( int argc, char *argv[] )
{
	int j;
	char c=0;
	unsigned long tmp;
	char buffer[128];

#ifdef _DEBUG
	char *ptr;
	unsigned int open_debug_level=1;
	unsigned int debug_level=1;
#endif

	puts("PPP Server example");
	puts("Press 'ESC' to end.\n");

#ifdef _DEBUG
	if ( (ptr=getenv("DEBUG")) != NULL)  {
		debug_level = atoi(ptr);
		printf("Debug level set to %d (from environment).\n", debug_level);
	}
	if ( (ptr=getenv("O_DEBUG")) != NULL)  {
		open_debug_level = atoi(ptr);
		printf("Open debug level set to %d (from environment).\n", open_debug_level);
	}
#endif

	if ( PPPInit( 0x61 ) ) {
		printf("PPP driver not found, exiting..\n");
		return -1;
	}

	sock_init();		// start WATTCP

	printf("\nMy address is: [%s]\n", inet_ntoa( buffer, gethostid()));

	while (c != END_CHAR) {		// big loop

		while ( !PPPISOPEN( PPPStatus() )  ) {		// if there isnt a connection, try and get one
			printf("PPP not connected, opening...\n");

#ifdef _DEBUG
			PPPSetRespLevel( open_debug_level );
			printf("open script: %d close script: %d\n",strlen(open_ppp), strlen(close_ppp) );
#endif
			printf("Waiting for incomming PPP call...");
			if ( PPPOpen( open_ppp, close_ppp, FALSE ) ) {
				printf("\nPPPOpen() failed, exiting...\n");
				return(-1);
			}

			while ( PPPISSCRIPT( PPPStatus() ) ) {	// wait for open script to complete
				if ( kbhit() )
					c=getch();
				if ( c == END_CHAR ) {
					puts("Terminated by user.");
					puts("PPP Closing");
					PPPClose();
					return 0;
				}
			}

			while ( !PPPISOPEN ( PPPStatus() ) && !PPPISCLOSED( PPPStatus() ) ){	// wait for PPP to negotiate
				if ( kbhit() )
					c=getch();
				if ( c == END_CHAR ) {
					puts("Terminated by user.");
					puts("PPP Closing");
					PPPClose();
					return 0;
				}
			}
			if (! PPPISOPEN( PPPStatus() ) ) {
				puts("no connection, keep trying");
				continue;
			}

			tmp=PPPRemoteIP();
			printf("Connection established from %d.%d.%d.%d\n", (int)(tmp >> 24),
					(int)((tmp >> 16) & 0xFF), (int)((tmp >> 8) & 0xFF), (int)(tmp & 0xFF) );
#ifdef _DEBUG
			PPPSetRespLevel( debug_level );
#endif

		}		// end if PPPISOPEN()

		// initialize the connection/status table and sockets
		for( j =0; j < max_sockets; j++ ) {
			s_connected[j] = FALSE;  						// no connection
			isStopped[j] = TRUE;       						// data transmit stopped
			tcp_listen( &s[j], TALK_PORT, 0, 0, NULL, 0 );	// open sockets for listen
			sock_mode( &s[j], TCP_MODE_ASCII );				// socket mode is ascii
			printf("%14d|",j);
		}
		puts(""); // new line

		// process incomming connections and
		// call process_socket to receive and send data

		j=0;
		while( !kbhit() && PPPISOPEN(PPPStatus()) ) {		// loop until keypress or PPP link dies
			printf("%8.8s,%5.5s|",sockstate( &s[j] ), (isStopped[j] ? "Stop" : "Start") );

			if ( !tcp_tick( &s[j] ) ) {
				if( !s_connected[j] ) {					// only required when connection is closed by client
					tcp_listen(&s[j], TALK_PORT, 0, 0, NULL, 0 );		// recycle the socket
					sock_mode(&s[j], TCP_MODE_ASCII );
				}
				s_connected[j] = FALSE;			// update connection table
				isStopped[j] = TRUE; 			// reset sending data flag
			}
			if(sock_established( &s[j] ) ) {	// socket connection valid, update the connection table
				s_connected[j] = TRUE; 			// update the connection table
				process_socket( j );			// go check for incomming / outgoing messages
			}

			if ( ++j >= max_sockets ) j=0;		// back to the beginning
			if ( j==0 ) {
				time(&secs_now);							// get current time (in seconds)
//				strncpy(tbuffer,ctime(&secs_now),24);		// put time into string w/o '/n'
				printf(" %.13s\r", ctime(&secs_now)+11);	// CR to keep output pretty
			}

		}

		if ( kbhit() ) 							// if keypress, eat it
			c=getch();

		puts("\nresetting PPP link\n");
		PPPClose();
		continue;

		sock_err:
			puts("Socket Error - resetting PPP...");
			PPPClose();
			continue;
	}
	return (0);
}



