Intoduction:
	Note that while this example will work you don't need to run it.
It is more meant for you to read the files in this directory so that you
may later create and edit your own.

Parts:
	To use this example you need:
	1 JK Microsystems Boards (with free serial port)
	1 Modem cable (see the PPP manual for help)
	1 Modem
	A computer for the board to call

Instructions:
	Connect the modem to COM1 of the board with the cable
Load "open.ppp" "close.ppp" "Goppp.bat" and "Noppp.bat" files onto the
board.
	Make sure the NE2000 packet driver for ethernet is not loading.
This only applies if the board is a uFlashTCP, FlashTCP, Logicflex or
Ether6.  Essentially it applies to any board with ethernet built in.
	You may either edit startup.bat to comment out the line that
loads NE2000, or you may unload it after the fact.
	Once you have the board and modem connected and powered and
NE2000 is not loaded, type "goppp" to load ppp and start the connection.
After you have done this, the modem will dial 111-1111 and will try to
connect with PPP.  Note that 111-1111 is not a valid phone number.
	In this configuration the board is acting like a user computer
connecting to an ISP.  It will use the IP address that the remote computer
assigns it.  To authenticate itself with the ISP it will use PAP with the
username "Username" and password "Password".
	To close the link, type noppp.