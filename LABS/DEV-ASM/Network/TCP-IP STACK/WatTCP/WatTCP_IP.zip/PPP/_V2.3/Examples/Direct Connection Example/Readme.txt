Intoduction:
	Note that while this example will work you don't need to run it.
It is more meant for you to read the files in this directory so that you
may later create and edit your own.

Parts:
	To use this example you need:
	2 JK Microsystems Boards (with free serial port)
	1 Null modem cable (see note below)

Instructions:
	Connect the null modem cable from to COM1 on both boards.
Load "close.ppp" "Goppp.bat" and "Noppp.bat" files onto both boards.
Then you must load an "open.ppp" onto each board.  Note that there
are two versions of that file in this directory, one is for one board,
the other for the other board.  You must rename them both to "open.ppp"
once you load them to the board.
	Make sure the NE2000 packet driver for ethernet is not loading
on either board.  This only applies if the boards are uFlashTCPs,
FlashTCPs, Logicflexs or Ether6.  Essentially it applies to any board
with ethernet built in.
	You may either edit startup.bat to comment out the line that
loads NE2000, or you may unload it after the fact.
	Once you have both boards powered up and connected (without
NE2000) you may type "goppp" into both boards.  So long as you type
this into both boards within 100 seconds of each other the link should
come up and you will be able to communicate between the boards.
	Board #1's IP is 10.1.1.1
	Board #2's IP is 10.1.1.2
	To shut down the PPP link, type "noppp"

NOTE:
	The null modem cable must provide somehow for both of the DCD
(Data Carrier Detect) lines to be held high.  PPP depends on the DCD
line as a signal from the modem as to whether the modem is connected.
If the DCD line ever drops PPP will reset, because the modem has been
disconnected.