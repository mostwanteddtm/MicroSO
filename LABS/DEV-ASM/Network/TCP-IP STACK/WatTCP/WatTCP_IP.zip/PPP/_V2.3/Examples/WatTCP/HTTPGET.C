#include <stdio.h>
#include <dos.h>
#include <conio.h>
#include <time.h>
#include <alloc.h>

#include "ppplib.h"

#include "wattcp.h"
#include "tcp.h"
//#include "wattcp.h"

#include <stdlib.h>
#include <string.h>


char open_ppp[]="open.ppp\0";
char close_ppp[]=
"@F\r\n\
@w18\r\n\
@O+++\r\n\
@w18\r\n\
@OATH\\n\\r\r\n\
@w18\r\n\
@F\r\n\0";

#define	BUFFERSIZE	2048

#define	HTTPVER		"HTTP/1.[01]"
#define	HTTPVER10	"HTTP/1.0"
#define	HTTPVER11	"HTTP/1.1"

#define	strn(s)		s, sizeof(s)-1


#define DEBUG

int			verbose = 1;
int			ifmodifiedsince = 0;
char		*outputfile = 0;
FILE		*output=stdout;
char		*password = 0;
char		basis_64[] = {"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"};
char		buffer[BUFFERSIZE];
struct tm	*mtime;
char		*dayname[] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
char		*monthname[] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun",
			"Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
tcp_Socket	sock;

void base64encode(char *in, char *out)
{
	int		c1, c2, c3;

	while (*in != '\0') {
		c1 = *in++;
		if (*in == '\0')
			c2 = c3 = 0;
		else {
			c2 = *in++;
			if (*in == '\0')
				c3 = 0;
			else
				c3 = *in++;
		}

		*out++ = basis_64[c1>>2];
		*out++ = basis_64[((c1 & 0x3) << 4) | ((c2 & 0xF0) >> 4)];

		if (c2 == 0 && c3 == 0) {
			*out++ = '=';
			*out++ = '=';
		}
		else if (c3 == 0) {
			*out++ = basis_64[((c2 & 0xF) << 2) | ((c3 & 0xC0) >> 6)];
			*out++ = '=';
		}
		else {
			*out++ = basis_64[((c2 & 0xF) << 2) | ((c3 & 0xC0) >> 6)];
			*out++ = basis_64[c3 & 0x3F];
		}
	}
	*out = '\0';
}

/* WATTCP's sock_gets doesn't do the right thing */
int sock_getline(void *sock, char *buffer, int len)
{
	int		i;
	char		ch;

	for (i = 0, --len; i <= len && sock_read(sock, &((unsigned char)ch), 1) > 0; ) {
		if (ch == '\n')
			break;
		else if (ch != '\r') {
			*buffer++ = ch;
			++i;
		}
	}
	*buffer = '\0';
	return (i);
}

long header(char *path)
{
	int		i, len, response;
	long		contentlength;
	char		*s;

	contentlength = 0x7fffffffL;	/* largest int, in case no CL header */
	if ((len = sock_getline(&sock, buffer, sizeof(buffer))) <= 0) {
		fprintf(stderr, "EOF from server\n");
		return (-1L);
	}
	if (strncmp(s = buffer, strn(HTTPVER10)) != 0 &&
		strncmp(s, strn(HTTPVER11)) != 0) {	/* no HTTP/1.[01]? */
		fprintf(stderr, "Not " HTTPVER " server\n");
		return (-1L);
	}
	s += sizeof(HTTPVER10)-1;		/* either 10 or 11 will do */
	if ((i = strspn(s, " \t")) <= 0) {	/* no whitespace? */
		fprintf(stderr, "Malformed " HTTPVER " line\n");
		return (-1L);
	}
	s += i;
	response = 500;
	sscanf(s, "%3d", &response);
	if (response == 401) {
		fprintf(stderr, "%s: authorisation required, use -p ident:password\n", path);
		return (-1L);
	}
	else if (response != 200 && response != 301 && response != 302
		&& response != 304) {
		fprintf(stderr, "%s: %s\n", path, s);
		contentlength = -1L;
	}
	/* eat up the other header lines here */
	while ((len = sock_getline(&sock, buffer, sizeof(buffer))) > 0) {
		if (strnicmp(s = buffer, strn("Content-Length:")) == 0) {
			s += sizeof("Content-Length:")-1;
			contentlength = atol(s);
		}
		else if (strnicmp(buffer, strn("Location:")) == 0) {
			if (response == 301 || response == 302)
				fprintf(stderr, "At %s\n", buffer);
		}
		else if (strchr(" \t", buffer[0]) != 0)
			fprintf(stderr, "Warning: continuation line encountered\n");
	}
	return (response == 304 ? 0L : contentlength);
}

int htget(char *host, int port, char *path)
{
	longword	hostaddr;
	int		status = 0;
	int		connected = 0;
	int		completed = 0;
	int		i;
	long	length, contentlength;

#ifdef	DEBUG
	fprintf(stderr,"%s:%d%s\n", host, port, path);
#endif
	if (verbose)
		fprintf(stderr, "Getting IP address for %s\n", host);
	if (!(hostaddr = resolve(host))) {
		fprintf(stderr, "Cannot get address for %s\n", host);
		return (1);
	}
	if (verbose)
		fprintf(stderr, "Contacting %s\n", host);
	if (!tcp_open(&sock, 0, hostaddr, port, NULL)) {
		fprintf(stderr, "Cannot connect to %s\n", host);
		return (1);
	}
	sock_wait_established(&sock, sock_delay, NULL, &status);
	connected = 1;
	completed = 1;
	sock_tick(&sock, &status);	/* in case they sent reset */
	if (verbose)
		fprintf(stderr, "Sending HTTP GET request\n");
	sock_printf(&sock, "GET %s " HTTPVER10 "\r\nUser-Agent: HTGET \r\n", path);
	if (password != 0) {
		base64encode(password, buffer);
#ifdef	DEBUG
		fprintf(stderr, "%s => %s\n", password, buffer);
#endif
		sock_printf(&sock, "Authorization: Basic %s\r\n", buffer);
	}
	if (ifmodifiedsince != 0) {
		sock_printf(&sock, "If-Modified-Since: %s, %02d %s %04d %02d:%02d:%02d GMT\r\n",
			dayname[mtime->tm_wday], mtime->tm_mday,
			monthname[mtime->tm_mon], mtime->tm_year + 1900,
			mtime->tm_hour, mtime->tm_min, mtime->tm_sec);
#ifdef	DEBUG
		(void)fprintf(stderr, "If-Modified-Since: %s, %02d %s %04d %02d:%02d:%02d GMT\n",
			dayname[mtime->tm_wday], mtime->tm_mday,
			monthname[mtime->tm_mon], mtime->tm_year + 1900,
			mtime->tm_hour, mtime->tm_min, mtime->tm_sec);
#endif
	}
	sock_printf(&sock, "\r\n");
	printf("-------\n");
	if ((contentlength = header(path)) > 0L ) {
		length = 0L;
		while ((i = sock_read(&sock, (unsigned char *)buffer, sizeof(buffer))) > 0) {
			fprintf(output, buffer);
			length += i;
			if (verbose && contentlength != 0x7fffffffL)
				fprintf(stderr, "--------\nReceived %ld/%ld\r",
					length, contentlength);
		}
		if (verbose)
			fprintf(stderr, "\n");
		if (contentlength != 0x7fffffffL && length != contentlength)
			fprintf(stderr, "--------\nWarning, actual length = %ld, content length = %ld\n",
				length, contentlength);
	}
close_up:
	sock_close(&sock);
	sock_wait_closed(&sock, sock_delay, NULL, &status);
sock_err:
	if (status == -1)
		(void)fprintf(stderr, "%s reset connection\n", host);
	if (!connected)
		(void)fprintf(stderr, "Could not get connected\n");
	/* 0 if nothing went wrong */
	return(!completed || contentlength < 0L);
}

void help(void)
{
	puts("HTTPGET hostname[:port][/file]");
	puts("HTTPGET http://www.jkmicro.com");
	puts("HTTPGET http://10.10.10.10:8000/index.html");
	exit( 3 );
}

int main(int argc, char **argv)
{
	unsigned long tmp;
	char 	buffer[24], buffer2[128];
	char	*host, *path, *s;
	int		port = 80;
	int		status;

#ifdef _DEBUG
	char *ptr;
	unsigned int open_debug_level=1;

	if ( (ptr=getenv("DEBUG")) != NULL)  {
		open_debug_level = atoi(ptr);
		printf("open_debug_level set to %d (from environment).\n", open_debug_level);
	}
#endif

	if ( argc < 2 )
		help();

	if ( PPPInit( 0x61 ) ) {
		printf("ppp driver not found, exiting..\n");
		return 2;
	}

	if ( !PPPISOPEN( PPPStatus() )  ) {		// try and open the connection
		printf("ppp not connected, opening...\n");
#ifdef _DEBUG
		PPPSetRespLevel( open_debug_level );
		printf("open script: %d close script: %d\n",strlen(open_ppp), strlen(close_ppp) );
#endif

		if ( PPPOpen( open_ppp, close_ppp, TRUE ) ) {
			printf("connect failed, exiting...\n");
			return 2;
		}

#ifdef _DEBUG
		PPPSetRespLevel( 1 );
#endif
	}

	puts("");
	tmp=PPPLocalIP();
	sprintf( buffer,"%d.%d.%d.%d", (int)(tmp >> 24), (int)((tmp >> 16) & 0xFF), (int)((tmp >> 8) & 0xFF),
										(int)(tmp & 0xFF) );
	printf("My IP: %s\n", buffer);

	tmp=PPPRemoteIP();
	printf("Remote IP: %d.%d.%d.%d\n", (int)(tmp >> 24), (int)((tmp >> 16) & 0xFF), (int)((tmp >> 8) & 0xFF),
											(int)(tmp & 0xFF) );


	sock_init();
	printf("\nWATTCP.CFG address is: [%s]\n", inet_ntoa( buffer2, gethostid()));

	my_ip_addr = resolve( buffer );		// change IP address to what PPP gave us
	_arp_add_gateway( buffer, 0L);		// change gateway

	printf("new address is: [%s]\n\n", inet_ntoa( buffer2, gethostid()));


	if (strnicmp(argv[1], strn("http://")) == 0)
		argv[1] += sizeof("http://")-1;
	/* separate out the path component */
	if ((path = strchr(argv[1], '/')) == NULL) {
		host = argv[1];
		path = "/";	     /* top directory */
	}
	else {
		if ((host = malloc((int)(path - argv[1]) + 1)) == NULL) {
			fprintf(stderr, "Out of memory\n");
			return 4;
		}
		host[0] = '\0';
		strncat(host, argv[1],(int)(path - argv[1]) );
	}

	/* do we have a port number? */
	if ((s = strchr(host, ':')) != NULL) {
		*s++ = '\0';
		port = atoi(s);
	}

	status = htget(host, port, path);

	printf("Closing PPP connection...");
	PPPClose();									// close PPP connection

	return (status);

}