PPP Packet Driver v2.3 - By Greg Gibeling - Copyright 2001/02 JK microsystems
Editing and testing by Ed Wetherell

Instructions:
	Please extract these files to a directory for PPP.  You will want
to preserve the path information as the two examples provided occupy
different sub-directories.

	After that the first thing to do is read the manual and all other
documentation.  It is recommended that you look at the "direct connection"
example before trying to use PPP. Its very simple and will give you some
insight.

Contact Us:
	www.jkmicro.com
	-or-
	support@jkmicro.com

	(ggibeling@jkmicro.com)

Revision Log
	1/9/02	First release v2.1
		Minor bug fixes to pppopen, some of the printed messages and
		the script examples.
		Added revision log
	2/12	Second release, fixes to help and copyrights, etc.
		Gap in log file... (Sorry)
	3/10	Added file load capability to PPPLib
	3/17	Added debug information to PPPLib
		Added response level get and set to PPPLib
	3/20	Fixed PPPOpen.exe error checking
		Added error checking on PPPOpen() script loads
		Fixed minor bugs in PPPLib
		Converted helper apps to .COM files
	3/21	Version 2.3
		Return codes fixed and documented in PPPLib.h
		Error checking in various functions rewritten for efficiency