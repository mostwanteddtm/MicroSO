PPP Packet Driver v2.6 - By Greg Gibeling - Copyright 2001-2003 JK microsystems
Editing and testing by Ed Wetherell

Instructions:
	Please extract these files to a directory for PPP.  You will want
to preserve the path information as the two examples provided occupy
different sub-directories.

	After that the first thing to do is read the manual and all other
documentation.  It is recommended that you look at the "direct connection"
example before trying to use PPP. Its very simple and will give you some
insight.

Contact Us:
	www.jkmicro.com
	-or-
	support@jkmicro.com

	(ggibeling@jkmicro.com)

Revision Log
	1/9/02	First release v2.1
		Minor bug fixes to pppopen, some of the printed messages and
		the script examples.
		Added revision log
	2/12/02	Second release, fixes to help and copyrights, etc.
		Gap in log file... (Sorry)
	3/10/02	Added file load capability to PPPLib
	3/17/02	Added debug information to PPPLib
		Added response level get and set to PPPLib
	3/20/02	Fixed PPPOpen.exe error checking
		Added error checking on PPPOpen() script loads
		Fixed minor bugs in PPPLib
		Converted helper apps to .COM files
	3/21/02	Version 2.3
		Return codes fixed and documented in PPPLib.h
		Error checking in various functions rewritten for efficiency
	4/16/02	Version 2.4
		Added DNS support.  Including new PPPLib functions PPPRemotePDNS()
		PPPRemoteSDNS() and new script commands @DNSRP, @DNSRS, @DNSLP,
		@DNSLS for setting the DNS Local/Remote Primary/Secondary
		servers.
	5/9/02	Version 2.42
		Finished getting the timeout mess to work right.  Tested
		dial in with MS Windows 2000 Professional.  Got all that to work.
		Suspicious delays on high traffic connections still exist, probable
		cause is simply processing time on the 386Ex.
	6/4/02	Version 2.5
		Added the R8822 version of PPP, including changing the interrupt
		handling code to work on with the non-8259A system.
		Fixed a few bugs in the timer callback routine so that it wouldn't
		destroy the contents of DS.
		Made IPCP more robust in terms of avoiding configuration loops.
		Added more debug levels and code to debug the option lines in
		scripts and also TSR problems.
		PPP (both the 386Ex and R8822 versions) work and have been tested
		with both Windows 2000 Professional and Linux.
	9/15/02	Added minor documentation the timeout command line argument.
		Created linked library of for the 386Ex version, including additions
		to PPPLib to deal with initialization.
	2/23/03	Finished Bin-CSPD
		Works on the Flashlite186 board with the CSPD serial port library
		Not heavily tested!
	3/03/03	Version 2.6
		Added Quiet flags to command line
		I feel like it should say "3/3/3 Version 3" but its not v3 yet
	3/06/03	Fixed Timer ISR to hook into interrupt 0x08 when PPP is loaded not when
		a link is opened