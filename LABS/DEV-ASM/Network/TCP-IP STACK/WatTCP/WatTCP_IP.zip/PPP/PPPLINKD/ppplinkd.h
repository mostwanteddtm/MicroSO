// This ensures that this file will compile and link correctly under both C AND C++
#ifdef __cplusplus
extern "C"
{
#endif

//------------------------------------------------------------------------------
// PPP Packet Driver v2.5 - By Greg Gibeling - Copyright 2001/02 JK Microsysems
// Edited and tested by Ed Wetherell
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// NOTE!!
// This header file may change and grow in revisions yet to come, you should
// use the version distributed with the version of PPP given to you.
// IF THIS FILE IS OLDER THAN THE VERSION OF PPP BEING USED IT WILL STILL WORK!!
// IF THIS FILE IS NEWER THAN THE VERSION OF PPP BEING USED IT MAY NOT WORK!!
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// _DEBUG must be defined to include the debug functions and output.
// Uncomment the following line to enable debugging of PPPLib.
// Note that you must call PPPSetRespLev() to enable debug messages from PPP and
// that such messages are only availible from the debug version of PPP
//------------------------------------------------------------------------------
//#define _DEBUG

//------------------------------------------------------------------------------
// Use these to test the return code from PPPStatus
// These macros may change.  They may also some day be functions.
// Code compiled on previous versions will continue to operate correctly.
// You should make no assumptions about the value returned from PPPStatus()
// other than what these macros tells you.  The return value contains extra
// debug type information not of use to normal applications.
//------------------------------------------------------------------------------
#define PPPISOPEN(Status) ((((Status) >> 10) & 0x1F) == 3)
#define PPPISCLOSED(Status) ((((Status) >> 10) & 0x1F) == 6)
#define PPPISSCRIPT(Status) (((Status) & 0x1F) == 3)

//------------------------------------------------------------------------------
//	Function declarations
// Look at the PPP manual for more information on these functions
//------------------------------------------------------------------------------
// Arguments are very similar to the command line arguments for PPP.exe
// except the first one, which this routine will use to check if the PPPTSR is
// already loaded...
unsigned int PPPLoad(unsigned int Interrupt, unsigned char PacketInterrupt, unsigned char HookInterrupt, unsigned int COMBase, unsigned char COMInt, unsigned long Baud, unsigned char WordSize, unsigned char StopBits, unsigned char Parity, unsigned char FIFO, unsigned int NumBuffers, unsigned int ScriptSize, unsigned int Quiet, unsigned int Timeout, unsigned int ResponseLevel);
// Unload PPP and prepare for exit...
void         PPPUnload(void);

unsigned int PPPOpen(char* OpenScript, char* CloseScript, int WaitForConnect);
unsigned int PPPClose(void);
unsigned int PPPStatus(void);
unsigned long PPPLocalIP(void);
unsigned long PPPRemoteIP(void);
unsigned long PPPRemotePDNS(void);
unsigned long PPPRemoteSDNS(void);

unsigned long PPPTimeoutTicks(void);
unsigned long PPPTimeout(void);


#if defined(RESP_LEVS) || defined(_DEBUG)
// These functions are only availible in the debug version of PPP
unsigned int PPPGetRespLevel(void);
unsigned int PPPSetRespLevel(unsigned int ResponseLevel);
#endif

//------------------------------------------------------------------------------
//RETURN CODES:
//PPPInit()
//    0: Success; Found or loaded a valid instance of PPP
//		2: PacketInterrupt parameter was invalid while loading internal PPP
//		3: HookInterrupt parameter was invalid while loading internal PPP
//		4: Unable to reserve storage for the OpenScript while loading internal PPP
//		5: Unable to reserve storage for the CloseScript while loading internal PPP
//		6: Failed to initialize the serial port/modem while loading internal PPP
//		7: Failed to initialize the LCP protocol while loading internal PPP
//		8: Failed to initialize the IPCP protocol while loading internal PPP
//
//PPPOpen()
//    0x8FFD: Failure in PPPLib; PPPInit() must be called before PPPOpen()
//    0x8FFF: Failure in PPPLib; Failed to load the open script file from disk
//    0x8FFE: Failure in PPPLib; Failed to load the close script file from disk
//    0x8FFC: Failure in PPPLib; Connection failed while in negotiation phase
//    0x8001: Failure in PPP; The current PPP connection must be closed before
//						another can be opened
//    0x8003: Failure in PPP; Failed to load one of the scripts
//						(Possibly the scripts are too large)
//    0x8002: Failure in PPP; Failed to initiate the connect sequence
//    0: Success; Connect sequence initiated
//
//PPPClose()
//    0x8FFD: Failure in PPPLib; PPPInit() must be called before PPPClose()
//    0x8001: Failure in PPP; The current PPP connection must be opened before
//						it can be closed
//    0: Success; PPP connection closed
//
//PPPLocalIP()
//PPPRemoteIP()
//PPPRemotePDNS()
//PPPRemoteSDNS()
//    0.0.0.0: PPP does not have a valid negotiated connection
//    255.255.255.255: PPPInit() must be called first
//    (Basically just check if it's a valid address)
//
//PPPSetRespLevel()
//    0x8FFD: Failure in PPPLib; PPPInit() must be called before PPPSetRespLevel
//    0x8001: Failed in PPP; This is not the debug version of PPP
//	 0: Success
//------------------------------------------------------------------------------

#ifdef __cplusplus
}
#endif