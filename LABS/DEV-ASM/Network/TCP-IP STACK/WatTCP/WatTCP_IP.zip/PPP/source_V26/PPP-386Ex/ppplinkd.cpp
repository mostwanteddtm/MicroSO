#include <dos.h>
#include <bios.h>
#include <stdio.h>
#include <stdlib.h>
#include "ppp.h"
#include "frame.h"
#include "modem.h"
#include "script.h"
#include "lcp.h"
#include "ipcp.h"
#include "pdrv.h"
#include "timer.h"
#include "int.h"

#include "ppplinkd.h"

WORD							PPPInterrupt = 0;
WORD							PPPLoaded = 0;
char							PPPSignature[] = "PPP DRVR\0";

Script						*pOpenScript, *pCloseScript;
#ifdef RESP_LEVS
WORD							ResponseLevel = 0;
#endif
WORD							Quiet = 0;

extern DWORD				Timeout;
extern WORD					ScriptSize;

// These are internal use only functions
char*							PPPLoadScript(char* FileName);
void							PPPFreeScript(char* Script);

void _loadds				PPPUnload(void)
{
	if (PPPLoaded != 0)
	{
		PPPClose();

		UninstallPacketISR();
		UninstallPPPISR();
      UninstallTimerISR;

		IPCP_Destroy();
		LCP_Destroy();
		Modem_Destroy();
		pCloseScript->Destroy();
		pOpenScript->Destroy();

      PPPLoaded = 0;
	}
}

unsigned int _loadds		PPPLoad(unsigned int Interrupt, unsigned char _PacketInterrupt, unsigned char _HookInterrupt, unsigned int _COMBase, unsigned char _COMInt, unsigned long _Baud, unsigned char _WordSize, unsigned char _StopBits, unsigned char _Parity, unsigned char _FIFO, unsigned int _NumBuffers, unsigned int _ScriptSize, unsigned int _Quiet, unsigned int _Timeout, unsigned int _RespLev)
{
	Quiet = _Quiet;
	if ((PPPInterrupt != 0) || (PPPLoaded != 0))
	{
		RESPONSE2(printf("PPPLINKD: PPPLoad() -- Cannot load PPP twice, call PPPUnload first or unload the TSR!\n"));
		return 0xFFFF;
	}

	if (Interrupt != 0)
	{
		unsigned int Seg, Off, i, j, sig = 0;
		Off = *(unsigned int far*)(MK_FP(0,Interrupt * 4));
		Seg = *(unsigned int far*)(MK_FP(0,(Interrupt * 4) + 2));

		RESPONSE2(printf("PPPLINKD: PPPLoad() -- Initializing PPP Interrupt Vector 0x%X (Address %04X:%04X)\n", Interrupt, Seg, Off));

		i = 0;
		while ((sig == 0) && (i < 5))
		{
			j = 0;
			sig = 1;
			while ((sig == 1) && (j < 9))
			{
				if (((char far*)(MK_FP(Seg, (Off + i))))[j] != PPPSignature[j]) sig = 0;
				j++;
			}
			i++;
		}

		if (sig)
		{
#ifdef RESP_LEVS
			if (!Quiet) printf("PPPLINKD: PPPLoad() -- Initialized PPP Interrupt Vector 0x%X\n", Interrupt);
#endif

			// Save the interrupt
			PPPInterrupt = Interrupt;

#ifdef RESP_LEVS
			ResponseLevel = PPPGetRespLevel();
			if (!Quiet) printf("PPPLINKD: PPPLoad() -- Matching PPP debug response level %d\n", ResponseLevel);
#endif

			// Return success
			return 0;
		}
	}

#ifdef RESP_LEVS
	ResponseLevel = _RespLev;
	if (!Quiet) printf("PPPLINKD: PPPLoad() -- Set response level %u\n", ResponseLevel);
#endif

	RESPONSE2(printf("PPPLINKD: PPPLoad() -- No PPP TSR found or (Interrupt == 0), loading internal PPP...\n"));
	PPPInterrupt = 0;

	Timeout = _Timeout;
	RESPONSE2(printf("PPPLINKD: PPPLoad() -- Set timeout %u\n", Timeout));

	if ((_PacketInterrupt > 0x80) || (_PacketInterrupt < 0x60))
	{
		RESPONSE2(printf("PPPLINKD: PPPLoad() -- Not a valid packet driver interrupt!\n"));
		return 2;
	}
	if (_HookInterrupt < 0x20)
	{
		RESPONSE2(printf("PPPLINKD: PPPLoad() -- Invalid hook interrupt!\n"));
		return 3;
	}

	if (Script::Create(ScriptSize = _ScriptSize, NULLPOINTER, &pOpenScript) != 0)  return 4;
	if (Script::Create(ScriptSize, NULLPOINTER, &pCloseScript) != 0)
	{
		pOpenScript->Destroy();
		return 5;
	}

	// PacketInterrupt, HookInterrupt, COMBase, COMInt, Baud, WordSize, StopBits, Parity, FIFO, NumBuffers, ScriptSize, Timeout, RespLev
	if (Modem_Create(_COMBase, _COMInt, _Baud, _WordSize, _StopBits, _Parity, _FIFO, 1, _NumBuffers) != 0)
	{
		pCloseScript->Destroy();
		pOpenScript->Destroy();
		return 6;
	}
	SetMRU(2000);

   if (LCP_Create() != 0)
	{
		Modem_Destroy();
		pCloseScript->Destroy();
		pOpenScript->Destroy();
		return 7;
	}

	if (IPCP_Create() != 0)
	{
		LCP_Destroy();
		Modem_Destroy();
		pCloseScript->Destroy();
		pOpenScript->Destroy();
		return 8;
	}

	InstallTimerISR();
	InstallPPPISR(PPPLoaded = _HookInterrupt);
	InstallPacketISR(_PacketInterrupt);

	atexit(PPPUnload);

	return 0;
}

//------------------------------------------------------------------------------
//	PPPLoadScript()
//	THIS IS A FUNCTION FOR USE IN PPPLINKD ONLY
// It loads a script file from disk and returns a pointer to the buffer it
// allocates to hold the file
//------------------------------------------------------------------------------
char*							PPPLoadScript(char* FileName)
{
	struct REGPACK Regs;
	FILE *File;
	char *Script, *rp;

	RESPONSE2(printf("PPPLINKD: PPPLoadScript() -- Attempting to load script \'%s\'\n", FileName));

	// Make sure someone called PPPInit first with a valid interrupt
	if ((PPPInterrupt == 0) && (PPPLoaded == 0))
	{
		RESPONSE1(printf("PPPLINKD: PPPLoadScript() -- PPPLINKD was not initialized\n"));
		return NULL;
	}

	// We need to determine the maximum script size PPP will accept
	// so that we can allocate memory approriately
	if (PPPInterrupt != 0)
	{
		Regs.r_ax = 4;
		intr(PPPInterrupt, &Regs);
	}
	else Regs.r_ax = ScriptSize;

	RESPONSE3(printf("PPPLINKD: PPPLoadScript() -- Maximum script size: %d\n", Regs.r_ax));
	rp = Script = new char[Regs.r_ax];

	if (Script == NULL)
	{
		RESPONSE1(printf("PPPLINKD: PPPLoadScript() -- Memory allocation failed\n"));
		return NULL;
	}

	// Open the requested script file
	if ((File = fopen(FileName, "rt")) == NULL)
	{
		RESPONSE1(printf("PPPLINKD: PPPLoadScript() -- Failed to open the script file\n"));

		// The call the fopen() failed so we need to free the allocated memory
		PPPFreeScript(Script);
		// and return failure
		return NULL;
	}

#ifdef RESP_LEVS
	if ((ResponseLevel >= 4) && (!Quiet))
	{
		printf("PPPLINKD: PPPLoadScript() -- Loading script from file:\n");
		printf("-------------------------------------\n");

   	// Simple loop to read the contents of the file into the allocated memory
		while ((!feof(File)) && ((rp - Script) < (Regs.r_ax - 1)))
		{
			// Dump the script to the screen while reading it
			putchar((*(rp++)) = fgetc(File));
		}

		printf("-------------------------------------\n");
	}
	else
	{
#endif
		// Simple loop to read the contents of the file into the allocated memory
		while ((!feof(File)) && ((rp - Script) < (Regs.r_ax - 1)))
			(*(rp++)) = fgetc(File);
#ifdef RESP_LEVS
	}
#endif

	// Terminate the memory buffer will a null character
	(*rp) = 0;

	// Close the file, since we are done with it
	fclose(File);

	// Return the allocated block of memory with the script loaded into it
	return Script;
}

//------------------------------------------------------------------------------
//	PPPFreeScript()
//	THIS IS A FUNCTION FOR USE IN PPPLINKD ONLY
// This will free memory allocated by PPPLoadScript
//------------------------------------------------------------------------------
void							PPPFreeScript(char* Script)
{
	// All we have to do is free the memory, but we need to use the right method
	// to correspond to how it was allocated
	delete Script;
}

//------------------------------------------------------------------------------
//	PPPOpen()
//	This function will open the PPP link using the scripts it is passed.  See
// the PPP manual for more information.
//------------------------------------------------------------------------------
unsigned int _loadds		PPPOpen(char* OpenScript, char* CloseScript, int WaitForConnect)
{
	struct REGPACK Regs;
	int LOpen = 0, LClose = 0;

	// Make sure someone called PPPInit first with a valid interrupt
	if ((PPPInterrupt == 0) && (PPPLoaded == 0))
	{
		RESPONSE1(printf("PPPLINKD: PPPOpen() -- PPPLINKD was not initialized\n"));
		return 0x8FFD;
	}

	// If we were passed a string that did not begin with @ then it's a file name
	if (OpenScript && (OpenScript[0] != '@'))
	{
		RESPONSE2(printf("PPPLINKD: PPPOpen() -- OpenScript[0] != \'@\' Assuming script file name\n"));

		// Load the open script using the file name we were given
		OpenScript = PPPLoadScript(OpenScript);
		// If we failed to load the script then return an error
		if (!OpenScript)
		{
			RESPONSE1(printf("PPPLINKD: PPPOpen() -- Failed to load OpenScript from disk\n"));
			return 0x8FFF;
		}
		// Flag the fact that we loaded a script (to free the memory later)
		LOpen = 1;
	}

	// If we were passed a string that did not begin with @ then it's a file name
	if (CloseScript && (CloseScript[0] != '@'))
	{
		RESPONSE2(printf("PPPLINKD: PPPOpen() -- CloseScript[0] != \'@\' Assuming script file name\n"));

		// Load the close script using the file name we were given
		CloseScript = PPPLoadScript(CloseScript);
      // If we failed to load the script then return an error
		if (!CloseScript)
		{
			RESPONSE1(printf("PPPLINKD: PPPOpen() -- Failed to load CloseScript from disk\n"));
			// Free the open script if we loaded it
			if (LOpen) PPPFreeScript(OpenScript);
			return 0x8FFE;
		}
		// Flag the fact that we loaded a script (to free the memory later)
		LClose = 1;
	}

	// AX contains the function code
	// The function code for 'open' is 1
	Regs.r_ax = 1;

	// Convert the pointers to the scripts to far pointers and load them into the
	// appropriate registers for the ISR
	if (OpenScript != 0)
	{
		Regs.r_ds = FP_SEG((char far*)OpenScript);
		Regs.r_si = FP_OFF((char far*)OpenScript);

		RESPONSE3(printf("PPPLINKD: PPPOpen() -- OpenScript = Address %04X:%04X\n", Regs.r_ds, Regs.r_si));
	}
	else Regs.r_ds = Regs.r_si = 0;
	if (CloseScript != 0)
	{
		Regs.r_es = FP_SEG((char far*)CloseScript);
		Regs.r_di = FP_OFF((char far*)CloseScript);

		RESPONSE3(printf("PPPLINKD: PPPOpen() -- CloseScript = Address %04X:%04X\n", Regs.r_es, Regs.r_di));
	}
	else Regs.r_es = Regs.r_di = 0;

	// Call the ISR with the register structure set up above
	intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);

	// Free the scripts that we loaded from disk (to prevent memory leaks)
	if (LClose) PPPFreeScript(CloseScript);
	if (LOpen) PPPFreeScript(OpenScript);

	// If the call was successful and we are supposed to wait for a complete
	// connection
	if ((Regs.r_ax == 0) && WaitForConnect)
	{
		RESPONSE2(printf("PPPLINKD: PPPOpen() -- Waiting for connection success or failure\n"));
		// While PPP is neither fully open nor closed, just loop
		while(!PPPISOPEN(PPPStatus()) && !PPPISCLOSED(PPPStatus())) { }
		// If the connection failed after some time then return an error
		if (PPPISCLOSED(PPPStatus()))
		{
			RESPONSE1(printf("PPPLINKD: PPPOpen() -- Connection failed while waiting\n"));
			return 0x8FFC;
		}
	}

#ifdef RESP_LEVS
	if ((ResponseLevel >= 1) && (Regs.r_ax != 0) && (!Quiet))
		printf("PPPLINKD: PPPOpen() -- Connection failed immediately\n");
#endif

	// The ISR returns a status code in AX
	// 0 means success, anything else means failure
	return Regs.r_ax;
}

//------------------------------------------------------------------------------
//	PPPClose()
//	This function will close the PPP link using the close script specified when
// the link was opened.  See the PPP manual for more information.
//------------------------------------------------------------------------------
unsigned int _loadds		PPPClose(void)
{
	struct REGPACK Regs;

	// Make sure someone called PPPInit first with a valid interrupt
	if ((PPPInterrupt == 0) && (PPPLoaded == 0))
	{
		RESPONSE1(printf("PPPLINKD: PPPClose() -- PPPLINKD was not initialized\n"));
		return 0x8FFD;
	}

	// AX contains the function code
	// The function code for 'close' is 2
	Regs.r_ax = 2;
	intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);

#ifdef RESP_LEVS
	if ((ResponseLevel >= 1) && (Regs.r_ax != 0) && (!Quiet))
		printf("PPPLINKD: PPPClose() -- Connection could not be closed (PPP is reset)\n");
#endif

	// The ISR returns a status code in AX
	// 0 means success, anything else means failure
	return Regs.r_ax;
}

//------------------------------------------------------------------------------
//	PPPStatus()
//	This function will return the status of the PPP link.  Please use the macros
// in PPPLib.H to decode this functions return values.
//	See the PPP manual for more information.
//	You should make no assumptions about the value returned from PPPStatus()
// other than what the macros tells you!!!!
//------------------------------------------------------------------------------
unsigned int _loadds		PPPStatus(void)
{
	struct REGPACK Regs;

	// Make sure someone called PPPInit first with a valid interrupt
	if ((PPPInterrupt == 0) && (PPPLoaded == 0))
	{
		RESPONSE1(printf("PPPLINKD: PPPStatus() -- PPPLINKD was not initialized\n"));
		return 0xFF;
	}

	// AX contains the function code
	// The function code for 'status' is 3

	Regs.r_ax = 3;
	intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);

	return Regs.r_ax;
}

//------------------------------------------------------------------------------
//	PPPLocalIP()
//	This function will return the local IP address that PPP is using.  See
// the PPP manual for more information.
//------------------------------------------------------------------------------
unsigned long _loadds	PPPLocalIP(void)
{
	struct REGPACK Regs;

	// Make sure someone called PPPInit first with a valid interrupt
	if ((PPPInterrupt == 0) && (PPPLoaded == 0))
	{
		RESPONSE1(printf("PPPLINKD: PPPLocalIP() -- PPPLINKD was not initialized\n"));
		return 0xFFFFFFFFl;
	}

	// AX contains the function code
	// The function code for 'LocalIP' is 6
	Regs.r_ax = 6;

	// Call the ISR with the register structure set up above
	intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);

	// The ISR returns the localIP in AX:BX
	return ((unsigned long)(Regs.r_ax) << 16) | (unsigned long)(Regs.r_bx);
}

//------------------------------------------------------------------------------
//	PPPRemoteIP()
//	This function will return the IP address of the system that PPP is connected
// to.  See the PPP manual for more information.
//------------------------------------------------------------------------------
unsigned long _loadds	PPPRemoteIP(void)
{
	struct REGPACK Regs;

	// Make sure someone called PPPInit first with a valid interrupt
	if ((PPPInterrupt == 0) && (PPPLoaded == 0))
	{
		RESPONSE1(printf("PPPLINKD: PPPRemoteIP() -- PPPLINKD was not initialized\n"));
		return 0xFFFFFFFFl;
	}

	// AX contains the function code
	// The function code for 'RemoteIP' is 7
	Regs.r_ax = 7;

	// Call the ISR with the register structure set up above
	intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);

	// The ISR returns the RemoteIP in AX:BX
	return ((unsigned long)(Regs.r_ax) << 16) | (unsigned long)(Regs.r_bx);
}

//------------------------------------------------------------------------------
//	PPPRemotePDNS()
//	This function will return the IP address of the primary DNS server on the
// remote end of the PPP link.  See the PPP manual for more information.
//------------------------------------------------------------------------------
unsigned long _loadds	PPPRemotePDNS(void)
{
	struct REGPACK Regs;

	// Make sure someone called PPPInit first with a valid interrupt
	if ((PPPInterrupt == 0) && (PPPLoaded == 0))
	{
		RESPONSE1(printf("PPPLINKD: PPPRemotePDNS() -- PPPLINKD was not initialized\n"));
		return 0xFFFFFFFFl;
	}

	// AX contains the function code
	// The function code for 'RemotePDNS' is 9
	Regs.r_ax = 9;

	// Call the ISR with the register structure set up above
	intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);

	// The ISR returns the RemotePDNS in AX:BX
	return ((unsigned long)(Regs.r_ax) << 16) | (unsigned long)(Regs.r_bx);
}

//------------------------------------------------------------------------------
//	PPPRemoteSDNS()
//	This function will return the IP address of the secondary DNS server on the
// remote end of the PPP link.  See the PPP manual for more information.
//------------------------------------------------------------------------------
unsigned long _loadds	PPPRemoteSDNS(void)
{
	struct REGPACK Regs;

	// Make sure someone called PPPInit first with a valid interrupt
	if ((PPPInterrupt == 0) && (PPPLoaded == 0))
	{
		RESPONSE1(printf("PPPLINKD: PPPRemoteSDNS() -- PPPLINKD was not initialized\n"));
		return 0xFFFFFFFFl;
	}

	// AX contains the function code
	// The function code for 'RemoteSDNS' is 10
	Regs.r_ax = 10;

	// Call the ISR with the register structure set up above
	intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);

	// The ISR returns the RemoteSDNS in AX:BX
	return ((unsigned long)(Regs.r_ax) << 16) | (unsigned long)(Regs.r_bx);
}

//------------------------------------------------------------------------------
//	PPPTimeoutTicks()
//	This function will return the number of processor ticks until the PPP
// link times out
//------------------------------------------------------------------------------
unsigned long _loadds	PPPTimeoutTicks(void)
{
	struct REGPACK Regs;
	unsigned long RetVal;

	// Make sure someone called PPPInit first with a valid interrupt
	if ((PPPInterrupt == 0) && (PPPLoaded == 0))
	{
		RESPONSE1(printf("PPPLINKD: PPPTimeoutTicks() -- PPPLINKD was not initialized\n"));
		return 0;
	}

	// AX contains the function code
	// The function code for 'Timeout' is 13
	Regs.r_ax = 13;

	// Call the ISR with the register structure set up above
	intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);

	RetVal = ((unsigned long)(Regs.r_bx) << 16) | (unsigned long)(Regs.r_ax);
	RetVal -= ((unsigned long)(Regs.r_dx) << 16) | (unsigned long)(Regs.r_ax);

	return RetVal;
}

//------------------------------------------------------------------------------
//	PPPTimeoutTicks()
//	This function will return the number of seconds until the PPP link times out
//------------------------------------------------------------------------------
unsigned long _loadds	PPPTimeout(void)
{
	struct REGPACK Regs;
	unsigned long RetVal;

	// Make sure someone called PPPInit first with a valid interrupt
	if ((PPPInterrupt == 0) && (PPPLoaded == 0))
	{
		RESPONSE1(printf("PPPLINKD: PPPTimeoutTicks() -- PPPLINKD was not initialized\n"));
		return 0;
	}

	// AX contains the function code
	// The function code for 'Timeout' is 13
	Regs.r_ax = 13;

	// Call the ISR with the register structure set up above
	intr((PPPInterrupt ? PPPInterrupt : PPPLoaded), &Regs);

	RetVal = ((unsigned long)(Regs.r_bx) << 16) | (unsigned long)(Regs.r_ax);
	RetVal -= ((unsigned long)(Regs.r_dx) << 16) | (unsigned long)(Regs.r_ax);

	return (RetVal * 10) / 182;
}

#ifdef RESP_LEVS
//------------------------------------------------------------------------------
//	PPPGetRespLevel()
//	This function will return the response level being used by PPP
//------------------------------------------------------------------------------
unsigned int _loadds		PPPGetRespLevel(void)
{
	struct REGPACK Regs;

	if ((PPPInterrupt == 0) && (PPPLoaded == 0))
	{
		RESPONSE1(printf("PPPLINKD: PPPGetRespLevel() -- PPPLINKD was not initialized\n"));
		return 0xFFFF;
	}

	if (PPPInterrupt != 0)
	{
		// AX contains the function code
		// The function code for 'SetRespLev' is 5
		Regs.r_ax = 8;

		// Call the ISR with the register structure set up above
		intr(PPPInterrupt, &Regs);

		if (Regs.r_ax == 0)
		{
			ResponseLevel = Regs.r_bx;
			if (!Quiet) printf("PPPLINKD: PPPGetRespLevel() -- Getting and matching PPP response level %d\n", ResponseLevel);

			// The ISR returns the 0 on success, error when PPP is the non-debug version
			return ResponseLevel;
		}

		if (!Quiet) printf("PPPLINKD: PPPGetRespLevel() -- Matching PPP response level 0\n");

		return (ResponseLevel = 0);
	}

	return ResponseLevel;;
}

//------------------------------------------------------------------------------
//	PPPSetRespLevel()
//	This function will set the response level being used by PPP
//------------------------------------------------------------------------------
unsigned int _loadds		PPPSetRespLevel(unsigned int ResponseLevel)
{
	struct REGPACK Regs;

	// Make sure someone called PPPInit first with a valid interrupt
	if ((PPPInterrupt == 0) && (PPPLoaded == 0))
	{
		RESPONSE1(printf("PPPLINKD: PPPSetRespLevel() -- PPPLINKD was not initialized\n"));
		return 0x8FFD;
	}

	if (PPPInterrupt != 0)
	{
		// AX contains the function code
		// The function code for 'SetRespLev' is 5
		Regs.r_ax = 5;

		// BX contains the desired response level
		Regs.r_bx = ResponseLevel;

		// Call the ISR with the register structure set up above
		intr(PPPInterrupt, &Regs);

		::ResponseLevel = ResponseLevel;

		if (!Quiet) printf("PPPLINKD: PPPSetRespLevel() -- Setting and matching PPP response level %d\n", ResponseLevel);

		// The ISR returns the 0 on success, error when PPP is the non-debug version
		return Regs.r_ax;
	}

	::ResponseLevel = ResponseLevel;
	return 0;
}
#endif
