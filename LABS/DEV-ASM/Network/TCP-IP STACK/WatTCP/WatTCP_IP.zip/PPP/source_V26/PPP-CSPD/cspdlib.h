//==============================================================================
//	Complex Serial Port Driver Library v1.2 - By Greg Gibeling
// Copyright 2003 JK microsystems
// Portions adapted from Jim Stewart
//
// Please read the readme file that came along with this or the Flashlite186
// users manual for more information
//==============================================================================

//------------------------------------------------------------------------------
//	Section:	Conditional Include
//	Desc:		Ensure that this header is included only once
//------------------------------------------------------------------------------
#ifndef _CSPDLib_H
#define _CSPDLib_H

//------------------------------------------------------------------------------
//	Section:	Extern C
//	Desc:		Ensure that C++ programs can access these functions by declaring
//				them to be extern "C" functions
//------------------------------------------------------------------------------
#ifdef __cplusplus
extern "C" {
#endif

//------------------------------------------------------------------------------
//	Section:	Constants
//	Desc:		These give names to the values used for the handshaking protocols
//------------------------------------------------------------------------------
// By default bother serial ports use no handshaking for either transmitting or
// receiving
#define CSPD_HS_None			0
// Setting transmit handshaking to CSPD_HS_Software will cause the serial port
// driver to listen for XON and XOFF on the receiver of that serial port and
// enable and disable transmission accordingly.  Setting receive handshaking to
// CSPD_HS_Software will cause the serial port to send XON and XOFF as needed to
// prevent its own buffers from overflowing
#define CSPD_HS_Software	1
// Hardware handshaking is currently only supported on serial port 0 for the
// Flashlite186.  Setting either transmit or receive handshaking to
// CSPD_HS_Hardware will cause BOTH to be set to hardware.  Under hardware
// handshaking the Flashlite186 will act like an RS232 DTE and will check the
// CTS signal from the DCE on the other end and disable its own transmission
// the the DCE deasserts CTS.  Note that because of hardware limitations on the
// Flashlite186 there will be a 0-18.2 millisecond delay after CTS is asserted
// before transmission will resume.
#define CSPD_HS_Hardware	2
// Because RS485 is half duplex RS485 handshaking mode is need to tell the
// serial port that it needs to enable the RS485 transmitter when sending
// characters.  Because the driver does not filter the incoming characters
// all characters sent while in RS485 mode will be received as well.
#define CSPD_HS_RS485		3

//------------------------------------------------------------------------------
//	Section:	Datatypes
//	Desc:		These make the following function definitions a bit more readable
//------------------------------------------------------------------------------
typedef unsigned int			WORD; // A word is an unsigned 16-bit integer
typedef unsigned char		BYTE; // A byte is an unsigned 8-bit integer

//------------------------------------------------------------------------------
//	Section:	Receive functions
//	Desc:		These functions have to do with the receiving half of the serial
//				ports
//------------------------------------------------------------------------------
// This will read a character from the given serial port.
// Returns the character on success and 0xFFFF if no characters are availible
WORD						CSPD_GetChar(WORD Port);
// This will return the number of buffered characters that need to be read
// or 0xFFFF if there has been a buffer overrun error (see CSPD_RxClearBuffer)
WORD						CSPD_RxGetBufferedChars(WORD Port);
// This will clear the receive buffer for the given serial port removing error
// conditions and any buffered data that hasn't been read out yet
// this will return 0 on success 0xFFFF on error
WORD						CSPD_RxClearBuffer(WORD Port);
// This allows you to set the handshaking to be used on the receive side of the
// given serial port, see the above handshaking constants for more information
// this will return 0 on success 0xFFFF on error
WORD						CSPD_RxSetHandshaking(WORD Port, BYTE Handshake);
// Instead of calling CSPD_GetChar() repeatedly a program can use CSPD_GetBlock
// to read up to BlockSize characters into the memory at pBlock
// This will return 0xFFFF on error, and the number of characters actually read
// on success (It will return 0xFFFF if no characters were waiting in the
// buffer)
WORD						CSPD_GetBlock(WORD Port, char* pBlock, WORD BlockSize);

//------------------------------------------------------------------------------
//	Section:	Transmit functions
//	Desc:		These functions have to do with the sending half of the serial ports
//------------------------------------------------------------------------------
// This will cause the given character to be sent over the given serial port
// In the case that the serial port is busy up to 256 characters can be buffered
// at a time, it will return 0 on success and 0xFFFF on error
WORD						CSPD_PutChar(WORD Port, char Character);
// This will return the amount of free space left in the serial ports transmit
// buffer or 0xFFFF if there has been a buffer error.
WORD						CSPD_TxGetBufferedChars(WORD Port);
// This will clear any buffer errors as well as immediately clearing out the
// transmit buffer by simply dropping any remaining characters from it
WORD						CSPD_TxClearBuffer(WORD Port);
// This allows you to set the handshaking to be used on the transmit side of the
// given serial port, see the above handshaking constants for more information
// this will return 0 on success 0xFFFF on error
WORD						CSPD_TxSetHandshaking(WORD Port, BYTE Handshake);
// Instead of calling CSPD_PutChar() repeatedly a program can use CSPD_PutBlock
// to write up to BlockSize characters to the serial port
// This will return 0xFFFF on error, and the number of characters actually
// written into the transmit buffer on success (It will return 0xFFFF if there
// was no space for new characters in the transmit buffer)
WORD						CSPD_PutBlock(WORD Port, char* pBlock, WORD BlockSize);

//------------------------------------------------------------------------------
//	Section:	General Functions
//	Desc:		These functions control the serial transmission protocol used on
//				the serial ports.
//------------------------------------------------------------------------------
// This will set the baud rate for the given serial port returning 0 on success
// and 0xFFFF on failure, valid baud rates and 300, 600, 1200, 2400, 4800, 9600
// 192 (19200), 384 (38400), 576 (57600) and 1152 (115200)
WORD						CSPD_SetBaud(WORD Port, WORD BaudCode);
// This will set the number of data bits and parity being used by the given
// serial port returning 0 on success and 0xFFFF on failure.  Valid
// BitsAndParityCodes are:
//	Code	Bits	Parity
//	0		8		None
//	1		7		Odd
//	2		7		Even
WORD						CSPD_SetBitsAndParity(WORD Port, BYTE BitsAndParityCode);
// This will check to make sure that the CSPD TSR is loaded into memory properly
// it will return 0 if CSPD is NOT loaded and 1 if CSPD IS loaded.
WORD						CSPD_IsLoaded(void);
// This will return the size in bytes of the transmit and receive buffers used
// by CSPD
WORD						CSPD_BufferSize(void);
// This will return 1 if the DCD line for the given port is high and 0 if it
// is low.  Only serial port 0 is configured as a DTE port and thus only port 0
// supports reading the DCD line.  This function will ALWAYS return 1 for any
// serial port other than 0
WORD						CSPD_DCDCheck(WORD Port);

//------------------------------------------------------------------------------
//	Section:	Extern C
//	Desc:		Ensure that C++ programs can access these functions by declaring
//				them to be extern "C" functions
//------------------------------------------------------------------------------
#ifdef __cplusplus
} // We opened these breaces earlier in this file and now we need to close them
#endif

//------------------------------------------------------------------------------
//	Section:	Conditional Include
//	Desc:		Ensure that this header is included only once
//------------------------------------------------------------------------------
#endif

