#include <dos.h>
#include <stdio.h>
#ifndef _cplusplus
#include <alloc.h>
#endif

#include "ppplib.h"

//------------------------------------------------------------------------------
// PPP Packet Driver v2.5 - By Greg Gibeling - Copyright 2001/02 JK Microsysems
// Edited and tested by Ed Wetherell
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// NOTE!!
// This file may change and grow in revisions yet to come, you should
// use the version distributed with the version of PPP given to you.
// IF THIS FILE IS OLDER THAN THE VERSION OF PPP BEING USED IT WILL STILL WORK!!
// IF THIS FILE IS NEWER THAN THE VERSION OF PPP BEING USED IT MAY NOT WORK!!
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// You may freely modify this code or port it to other languages it's only
// purpose is to provide an example of how to interface to PPP that can be used
// in most code.
//------------------------------------------------------------------------------

// This is where we save the interrupt number given to PPPInit()
unsigned int PPPInterrupt = 0;

// This is where we save the PPP response level for our debug use
#ifdef _DEBUG
unsigned int ResponseLevel = 0;
#endif

// DO NOT MODIFY THIS CONSTANT!!
char PPPSignature[] = "PPP DRVR\0";

// These are internal use only functions
char* PPPLoadScript(char* FileName);
void PPPFreeScript(char* Script);

//------------------------------------------------------------------------------
//	PPPInit()
//	This function initializes the libraries connection to PPP.  Essentially it
// just makes sure PPP is really loaded at the given interrupt and saves the
// interrupt number for use by later functions.
// It checks if PPP is loaded by looking for "PPP DRVR" starting within the
// first 5 bytes of the ISR.
//------------------------------------------------------------------------------
unsigned int PPPInit(unsigned int Interrupt)
{
	unsigned int Seg, Off, i, j, sig = 0;
	// Read the segment and the offset of the ISR
	Off = *(unsigned int far*)(MK_FP(0,Interrupt * 4));
	Seg = *(unsigned int far*)(MK_FP(0,(Interrupt * 4) + 2));

#ifdef _DEBUG
	printf("PPPLIB: PPPInit() -- Initializing PPP Interrupt Vector 0x%X (Address %04X:%04X)\n",
		Interrupt, Seg, Off);
#endif

	i = 0;
	// While we haven't found the signature and we still have bytes left to try
	// Note: i is used to denote the start of the signature.  We search for it
	// so that it can start in any of the first five bytes of the ISR.
	while ((sig == 0) && (i < 5))
	{
		j = 0;
		// Assume we will find the signature at this starting location (i)
		sig = 1;
		// While we still think we have found the signature and we still haven't
		// checked the whole signature
		while ((sig == 1) && (j < 9))
		{
			// If this byte doesn't match then we know we didn't find it at this i
			// Setting sig=0; will break out of the inner while and cause the outer
			// one to loop again
			if (((char far*)(MK_FP(Seg, (Off + i))))[j] != PPPSignature[j])
				sig = 0;
			// Increment j so that we can check the next character of the signature
			j++;
		}

		// Increment i so that we can check the next possible start location of
		// the signature
		i++;
	}

	// Once we get here either we ran out of chars in the signature (j) without
	// finding one that didn't match (so sig==1).  Or we ran out of starting
	// locations for the signature without finding it (sig==0)

	// If we found the signature
	if (sig)
	{
#ifdef _DEBUG
		printf("PPPLIB: PPPInit() -- Initialized PPP Interrupt Vector 0x%X\n", Interrupt);
#endif

		// Save the interrupt
		PPPInterrupt = Interrupt;

		// If we're in debug mode then retrieve the PPP response level
#ifdef _DEBUG
		ResponseLevel = PPPGetRespLevel();
		printf("PPPLIB: PPPInit() -- Matching PPP debug response level %d\n", ResponseLevel);
#endif

		// Return success
		return 0;
	}

#ifdef _DEBUG
	printf("PPPLIB: PPPInit() -- Initialization of PPP Interrupt Vector 0x%X failed\n", Interrupt);
	printf("PPPLIB: PPPInit() -- PPP Not loaded or Signature (\"PPP DRVR\") not found\n");
#endif

	// Return failure
	return 1;
}

//------------------------------------------------------------------------------
//	PPPLoadScript()
//	THIS IS A FUNCTION FOR USE IN PPPLIB ONLY
// It loads a script file from disk and returns a pointer to the buffer it
// allocates to hold the file
//------------------------------------------------------------------------------
char* PPPLoadScript(char* FileName)
{
	struct REGPACK Regs;
	FILE *File;
	char *Script, *rp;

#ifdef _DEBUG
	if (ResponseLevel >= 2)
	{
		printf("PPPLIB: PPPLoadScript() -- Attempting to load script \'%s\'\n",
			FileName);
	}
#endif

	// Make sure someone called PPPInit first with a valid interrupt
	if (PPPInterrupt == 0)
	{
#ifdef _DEBUG
		if (ResponseLevel >= 1)
			printf("PPPLIB: PPPLoadScript() -- PPPLIB was not initialized\n");
#endif
		return NULL;
	}

	// We need to determine the maximum script size PPP will accept
	// so that we can allocate memory approriately
	Regs.r_ax = 4;
	intr(PPPInterrupt, &Regs);

#ifdef _DEBUG
	if (ResponseLevel >= 3)
		printf("PPPLIB: PPPLoadScript() -- Maximum script size: %d\n", Regs.r_ax);
#endif

	// Allocate memory according to the language we are compiling under
#ifdef _cplusplus
	rp = Script = new char[Regs.r_ax];
#else
	rp = Script = (char *)malloc(Regs.r_ax);
#endif

	// Make sure that our memory allocation succeeded
	if (Script == NULL)
	{
#ifdef _DEBUG
		if (ResponseLevel >= 1)
			printf("PPPLIB: PPPLoadScript() -- Memory allocation failed\n");
#endif
		return NULL;
	}

	// Open the requested script file
	if ((File = fopen(FileName, "rt")) == NULL)
	{
#ifdef _DEBUG
		if (ResponseLevel >= 1)
			printf("PPPLIB: PPPLoadScript() -- Failed to open the script file\n");
#endif

		// The call the fopen() failed so we need to free the allocated memory
		PPPFreeScript(Script);
		// and return failure
		return NULL;
	}

#ifdef _DEBUG
	if (ResponseLevel >= 4)
	{
		printf("PPPLIB: PPPLoadScript() -- Loading script from file:\n");
		printf("-------------------------------------\n");

   	// Simple loop to read the contents of the file into the allocated memory
		while ((!feof(File)) && ((rp - Script) < (Regs.r_ax - 1)))
		{
			// Dump the script to the screen while reading it
			putchar((*(rp++)) = fgetc(File));
		}

		printf("-------------------------------------\n");
	}
	else
	{
#endif
		// Simple loop to read the contents of the file into the allocated memory
		while ((!feof(File)) && ((rp - Script) < (Regs.r_ax - 1)))
			(*(rp++)) = fgetc(File);
#ifdef _DEBUG
	}
#endif

	// Terminate the memory buffer will a null character
	(*rp) = 0;

	// Close the file, since we are done with it
	fclose(File);

	// Return the allocated block of memory with the script loaded into it
	return Script;
}

//------------------------------------------------------------------------------
//	PPPFreeScript()
//	THIS IS A FUNCTION FOR USE IN PPPLIB ONLY
// This will free memory allocated by PPPLoadScript
//------------------------------------------------------------------------------
void PPPFreeScript(char* Script)
{
	// All we have to do is free the memory, but we need to use the right method
	// to correspond to how it was allocated
#ifdef _cplusplus
	delete Script;
#else
	free(Script);
#endif
}

//------------------------------------------------------------------------------
//	PPPOpen()
//	This function will open the PPP link using the scripts it is passed.  See
// the PPP manual for more information.
//------------------------------------------------------------------------------
unsigned int PPPOpen(char* OpenScript, char* CloseScript, int WaitForConnect)
{
	struct REGPACK Regs;
	int LOpen = 0, LClose = 0;

	// Make sure someone called PPPInit first with a valid interrupt
	if (PPPInterrupt == 0)
	{
#ifdef _DEBUG
		if (ResponseLevel >= 1)
			printf("PPPLIB: PPPOpen() -- PPPLIB was not initialized\n");
#endif
		return 0x8FFD;
	}

	// If we were passed a string that did not begin with @ then it's a file name
	if (OpenScript && (OpenScript[0] != '@'))
	{
#ifdef _DEBUG
		if (ResponseLevel >= 2)
			printf("PPPLIB: PPPOpen() -- OpenScript[0] != \'@\' Assuming script file name\n");
#endif

		// Load the open script using the file name we were given
		OpenScript = PPPLoadScript(OpenScript);
		// If we failed to load the script then return an error
		if (!OpenScript)
		{
#ifdef _DEBUG
			if (ResponseLevel >= 1)
			printf("PPPLIB: PPPOpen() -- Failed to load OpenScript from disk\n");
#endif
			return 0x8FFF;
		}
		// Flag the fact that we loaded a script (to free the memory later)
		LOpen = 1;
	}

	// If we were passed a string that did not begin with @ then it's a file name
	if (CloseScript && (CloseScript[0] != '@'))
	{
#ifdef _DEBUG
		if (ResponseLevel >= 2)
			printf("PPPLIB: PPPOpen() -- CloseScript[0] != \'@\' Assuming script file name\n");
#endif

		// Load the close script using the file name we were given
		CloseScript = PPPLoadScript(CloseScript);
      // If we failed to load the script then return an error
		if (!CloseScript)
		{
#ifdef _DEBUG
			if (ResponseLevel >= 1)
			printf("PPPLIB: PPPOpen() -- Failed to load CloseScript from disk\n");
#endif
			// Free the open script if we loaded it
			if (LOpen) PPPFreeScript(OpenScript);
			return 0x8FFE;
		}
		// Flag the fact that we loaded a script (to free the memory later)
		LClose = 1;
	}

	// AX contains the function code
	// The function code for 'open' is 1
	Regs.r_ax = 1;

	// Convert the pointers to the scripts to far pointers and load them into the
	// appropriate registers for the ISR
	if (OpenScript != 0)
	{
		Regs.r_ds = FP_SEG((char far*)OpenScript);
		Regs.r_si = FP_OFF((char far*)OpenScript);

#ifdef _DEBUG
	if (ResponseLevel >= 3)
		printf("PPPLIB: PPPOpen() -- OpenScript = Address %04X:%04X\n",
			Regs.r_ds, Regs.r_si);
#endif
	}
	else Regs.r_ds = Regs.r_si = 0;
	if (CloseScript != 0)
	{
		Regs.r_es = FP_SEG((char far*)CloseScript);
		Regs.r_di = FP_OFF((char far*)CloseScript);

#ifdef _DEBUG
	if (ResponseLevel >= 3)
		printf("PPPLIB: PPPOpen() -- CloseScript = Address %04X:%04X\n",
			Regs.r_ds, Regs.r_si);
#endif
	}
	else Regs.r_es = Regs.r_di = 0;

	// Call the ISR with the register structure set up above
	intr(PPPInterrupt, &Regs);

	// Free the scripts that we loaded from disk (to prevent memory leaks)
	if (LClose) PPPFreeScript(CloseScript);
	if (LOpen) PPPFreeScript(OpenScript);

	// If the call was successful and we are supposed to wait for a complete
	// connection
	if ((Regs.r_ax == 0) && WaitForConnect)
	{
#ifdef _DEBUG
		if (ResponseLevel >= 2)
			printf("PPPLIB: PPPOpen() -- Waiting for connection success or failure\n");
#endif
		// While PPP is neither fully open nor closed, just loop
		while(!PPPISOPEN(PPPStatus()) && !PPPISCLOSED(PPPStatus())) { }
		// If the connection failed after some time then return an error
		if (PPPISCLOSED(PPPStatus()))
		{
#ifdef _DEBUG
			if (ResponseLevel >= 1)
				printf("PPPLIB: PPPOpen() -- Connection failed while waiting\n");
#endif
			return 0x8FFC;
		}
	}

#ifdef _DEBUG
	if ((ResponseLevel >= 1) && (Regs.r_ax != 0))
		printf("PPPLIB: PPPOpen() -- Connection failed immediately\n");
#endif

	// The ISR returns a status code in AX
	// 0 means success, anything else means failure
	return Regs.r_ax;
}

//------------------------------------------------------------------------------
//	PPPClose()
//	This function will close the PPP link using the close script specified when
// the link was opened.  See the PPP manual for more information.
//------------------------------------------------------------------------------
unsigned int PPPClose(void)
{
	struct REGPACK Regs;

	// Make sure someone called PPPInit first with a valid interrupt
	if (PPPInterrupt == 0)
	{
#ifdef _DEBUG
		if (ResponseLevel >= 1)
			printf("PPPLIB: PPPClose() -- PPPLIB was not initialized\n");
#endif
		return 0x8FFD;
	}

	// AX contains the function code
	// The function code for 'close' is 2
	Regs.r_ax = 2;
	intr(PPPInterrupt, &Regs);

#ifdef _DEBUG
	if ((ResponseLevel >= 1) && (Regs.r_ax != 0))
		printf("PPPLIB: PPPClose() -- Connection could not be closed (PPP is reset)\n");
#endif

	// The ISR returns a status code in AX
	// 0 means success, anything else means failure
	return Regs.r_ax;
}

//------------------------------------------------------------------------------
//	PPPStatus()
//	This function will return the status of the PPP link.  Please use the macros
// in PPPLib.H to decode this functions return values.
//	See the PPP manual for more information.
//	You should make no assumptions about the value returned from PPPStatus()
// other than what the macros tells you!!!!
//------------------------------------------------------------------------------
unsigned int PPPStatus(void)
{
	struct REGPACK Regs;

	// Make sure someone called PPPInit first with a valid interrupt
	if (PPPInterrupt == 0)
	{
#ifdef _DEBUG
		if (ResponseLevel >= 1)
			printf("PPPLIB: PPPStatus() -- PPPLIB was not initialized\n");
#endif
		return 0xFF;
	}

	// AX contains the function code
	// The function code for 'status' is 3

	Regs.r_ax = 3;
	intr(PPPInterrupt, &Regs);

	return Regs.r_ax;
}

//------------------------------------------------------------------------------
//	PPPLocalIP()
//	This function will return the local IP address that PPP is using.  See
// the PPP manual for more information.
//------------------------------------------------------------------------------
unsigned long PPPLocalIP(void)
{
	struct REGPACK Regs;

	// Make sure someone called PPPInit first with a valid interrupt
	if (PPPInterrupt == 0)
	{
#ifdef _DEBUG
		if (ResponseLevel >= 1)
			printf("PPPLIB: PPPLocalIP() -- PPPLIB was not initialized\n");
#endif
		return 0xFFFFFFFFl;
	}

	// AX contains the function code
	// The function code for 'LocalIP' is 6
	Regs.r_ax = 6;

	// Call the ISR with the register structure set up above
	intr(PPPInterrupt, &Regs);

	// The ISR returns the localIP in AX:BX
	return ((unsigned long)(Regs.r_ax) << 16) | (unsigned long)(Regs.r_bx);
}

//------------------------------------------------------------------------------
//	PPPRemoteIP()
//	This function will return the IP address of the system that PPP is connected
// to.  See the PPP manual for more information.
//------------------------------------------------------------------------------
unsigned long PPPRemoteIP(void)
{
	struct REGPACK Regs;

	// Make sure someone called PPPInit first with a valid interrupt
	if (PPPInterrupt == 0)
	{
#ifdef _DEBUG
		if (ResponseLevel >= 1)
			printf("PPPLIB: PPPRemoteIP() -- PPPLIB was not initialized\n");
#endif
		return 0xFFFFFFFFl;
	}

	// AX contains the function code
	// The function code for 'RemoteIP' is 7
	Regs.r_ax = 7;

	// Call the ISR with the register structure set up above
	intr(PPPInterrupt, &Regs);

	// The ISR returns the RemoteIP in AX:BX
	return ((unsigned long)(Regs.r_ax) << 16) | (unsigned long)(Regs.r_bx);
}

//------------------------------------------------------------------------------
//	PPPRemotePDNS()
//	This function will return the IP address of the primary DNS server on the
// remote end of the PPP link.  See the PPP manual for more information.
//------------------------------------------------------------------------------
unsigned long PPPRemotePDNS(void)
{
	struct REGPACK Regs;

	// Make sure someone called PPPInit first with a valid interrupt
	if (PPPInterrupt == 0)
	{
#ifdef _DEBUG
		if (ResponseLevel >= 1)
			printf("PPPLIB: PPPRemotePDNS() -- PPPLIB was not initialized\n");
#endif
		return 0xFFFFFFFFl;
	}

	// AX contains the function code
	// The function code for 'RemotePDNS' is 9
	Regs.r_ax = 9;

	// Call the ISR with the register structure set up above
	intr(PPPInterrupt, &Regs);

	// The ISR returns the RemotePDNS in AX:BX
	return ((unsigned long)(Regs.r_ax) << 16) | (unsigned long)(Regs.r_bx);
}

//------------------------------------------------------------------------------
//	PPPRemoteSDNS()
//	This function will return the IP address of the secondary DNS server on the
// remote end of the PPP link.  See the PPP manual for more information.
//------------------------------------------------------------------------------
unsigned long PPPRemoteSDNS(void)
{
	struct REGPACK Regs;

	// Make sure someone called PPPInit first with a valid interrupt
	if (PPPInterrupt == 0)
	{
#ifdef _DEBUG
		if (ResponseLevel >= 1)
			printf("PPPLIB: PPPRemoteSDNS() -- PPPLIB was not initialized\n");
#endif
		return 0xFFFFFFFFl;
	}

	// AX contains the function code
	// The function code for 'RemoteSDNS' is 10
	Regs.r_ax = 10;

	// Call the ISR with the register structure set up above
	intr(PPPInterrupt, &Regs);

	// The ISR returns the RemoteSDNS in AX:BX
	return ((unsigned long)(Regs.r_ax) << 16) | (unsigned long)(Regs.r_bx);
}

//------------------------------------------------------------------------------
//	PPPTimeoutTicks()
//	This function will return the number of processor ticks until the PPP
// link times out
//------------------------------------------------------------------------------
unsigned long PPPTimeoutTicks(void)
{
	struct REGPACK Regs;
	unsigned long RetVal;

	// Make sure someone called PPPInit first with a valid interrupt
	if (PPPInterrupt == 0)
	{
#ifdef _DEBUG
		if (ResponseLevel >= 1)
			printf("PPPLIB: PPPTimeoutTicks() -- PPPLIB was not initialized\n");
#endif
		return 0;
	}

	// AX contains the function code
	// The function code for 'Timeout' is 13
	Regs.r_ax = 13;

	// Call the ISR with the register structure set up above
	intr(PPPInterrupt, &Regs);

	RetVal = ((unsigned long)(Regs.r_bx) << 16) | (unsigned long)(Regs.r_ax);
	RetVal -= ((unsigned long)(Regs.r_dx) << 16) | (unsigned long)(Regs.r_ax);

	return RetVal;
}

//------------------------------------------------------------------------------
//	PPPTimeoutTicks()
//	This function will return the number of seconds until the PPP link times out
//------------------------------------------------------------------------------
unsigned long PPPTimeout(void)
{
	struct REGPACK Regs;
	unsigned long RetVal;

	// Make sure someone called PPPInit first with a valid interrupt
	if (PPPInterrupt == 0)
	{
#ifdef _DEBUG
		if (ResponseLevel >= 1)
			printf("PPPLIB: PPPTimeoutTicks() -- PPPLIB was not initialized\n");
#endif
		return 0;
	}

	// AX contains the function code
	// The function code for 'Timeout' is 13
	Regs.r_ax = 13;

	// Call the ISR with the register structure set up above
	intr(PPPInterrupt, &Regs);

	RetVal = ((unsigned long)(Regs.r_bx) << 16) | (unsigned long)(Regs.r_ax);
	RetVal -= ((unsigned long)(Regs.r_dx) << 16) | (unsigned long)(Regs.r_ax);

	return (RetVal * 10) / 182;
}

#ifdef _DEBUG
//------------------------------------------------------------------------------
//	PPPGetRespLevel()
//	This function will return the response level being used by PPP
//------------------------------------------------------------------------------
unsigned int PPPGetRespLevel(void)
{
	struct REGPACK Regs;

	// Make sure someone called PPPInit first with a valid interrupt
	if (PPPInterrupt == 0)
	{
		if (ResponseLevel >= 1)
			printf("PPPLIB: PPPGetRespLevel() -- PPPLIB was not initialized\n");
		return 0;
	}

	// AX contains the function code
	// The function code for 'GetRespLev' is 8
	Regs.r_ax = 8;

	// Call the ISR with the register structure set up above
	intr(PPPInterrupt, &Regs);

	ResponseLevel = Regs.r_ax ? 0 : Regs.r_bx;

	printf("PPPLIB: PPPGetRespLevel() -- Matching PPP response level %d\n",
		ResponseLevel);

	// The ISR returns the response level.  Note that AX contains the error code
	// (0 = success), the only error is that this might not be the debug version
	// of PPP
	return Regs.r_ax ? 0 : Regs.r_bx;
}

//------------------------------------------------------------------------------
//	PPPSetRespLevel()
//	This function will set the response level being used by PPP
//------------------------------------------------------------------------------
unsigned int PPPSetRespLevel(unsigned int ResponseLevel)
{
	struct REGPACK Regs;

	// Make sure someone called PPPInit first with a valid interrupt
	if (PPPInterrupt == 0)
	{
		if (ResponseLevel >= 1)
			printf("PPPLIB: PPPGetRespLevel() -- PPPLIB was not initialized\n");
		return 0x8FFD;
	}

	// AX contains the function code
	// The function code for 'SetRespLev' is 5
	Regs.r_ax = 5;

	// BX contains the desired response level
	Regs.r_bx = ResponseLevel;

	// Call the ISR with the register structure set up above
	intr(PPPInterrupt, &Regs);

	::ResponseLevel = ResponseLevel;

	printf("PPPLIB: PPPSetRespLevel() -- Setting and matching PPP response level %d\n",
		ResponseLevel);

	// The ISR returns the 0 on success, error when PPP is the non-debug version
	return Regs.r_ax;
}
#endif
