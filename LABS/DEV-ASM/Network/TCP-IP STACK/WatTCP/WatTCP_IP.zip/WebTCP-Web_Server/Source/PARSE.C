/*
 * PARSE.C
 *
 * Embedded Web Server
 * Copyright 1998,
 * JK microsystems, Inc. - ALL RIGHTS RESERVED
 * http://www.jkmicro.com
 *
 * THIS SOFTWARE IS NOT SHAREWARE, FREEWARE, OR PUBLIC DOMAIN.
 * IT IS THE PROPERTY OF JK microsystems.
 *
 * CUSTOMERS OF JK microsystems MAY MODIFY THE SOURCE CODE
 * AND/OR DISTRIBUTE THE BINARY IMAGE OF THIS SOFTWARE WITHOUT
 * ADDITIONAL COSTS PROVIDED IT IS RUN ONLY ON HARDWARE
 * MANUFACTURED BY JK microsystems.  ALL OTHER USE IS EXPRESSLY
 * PROHIBITED.
 *
 * THIS SOURCE CODE IS NOT TO BE DISCLOSED WITHOUT PRIOR APPROVAL
 * FROM JK microsystems.
 *
 * THIS PROGRAM IS DISTRIBUTED WITHOUT ANY WARRANTY;
 * WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * THE TCP/IP LIBRARIES ARE COPYRIGHT
 * UNIVERSITY OF WATERLOO.
 * THE LIBRARIES ARE PROVIDED FREE OF
 * CHARGE IN THEIR ORIGINAL DISTRIBUTION FORMAT.
 *
 */

/*
   See WEBTCP.H for revision notes
*/
#pragma option -ml				// large memory model
#pragma option -r-				// no register variables
#pragma option -2				// 286 instruction set (may be probs w/ 386 regs and TSRs)

#include "parse.h"

static char huge *ptr=NULL;

void huge *parse_file( FILE *fp, unsigned int *len, int *status )
{
static char far *ptr2;
static char far *p_start;
static char huge *p_ptr;
static int p_index;
static char c;
static int count=0;
static int i,j;

//	fprintf(dout,"%Fp %Fp ",ptr, fp);

	if (ptr == NULL) {
//		fprintf(msg_out,"Allocating space for parsed files\n---");
		ptr = (char huge *)farmalloc( (unsigned long)(FILE_BUF) ) ;
		if (!ptr)
			printf("PARSE_FILE: memory allocation error, %X\n",coreleft());
		else
			_fmemset( ptr, (int)'\0', (size_t)FILE_BUF );
	}
	*ptr = '\0';

//	ptr = (char huge *)farmalloc( (unsigned long)((*len)+4096) );
//	printf("%Fp ",ptr);

	if ( *len > (FILE_BUF-4096) ) {
		printf("PARSE_FILE: file too large %u \n\n", *len);
		*status=FORBIDDEN;
		*len=0;
		return(NULL);
	}
	ptr2 = (char far *)ptr;

	while ( (c=fgetc(fp)) != EOF ) {
		*(ptr2++)=c;
        *ptr2='\0';

//		putc(*(ptr2-1),dout);

		if (c=='<') {
			p_start = (ptr2-1);
			count = 1;
		}
		if (count)
			count++;
		if ( c=='>' ) {
			if (count > 24 && _fstrstr(p_start,"<!-- #include file=") ) {
				p_index = atoi( p_start+20 );
//				fprintf(dout,"\nindex: %d ",p_index );

				p_ptr = (char huge *)parse_value( p_index, &j, status );
//				fprintf(dout,"%.4d %d %Fp", j, *status, p_ptr );
				if (*status == OK) {
					ptr2 = p_start;
					for (i=0; i<j; i++) {
						*(ptr2++) = *(p_ptr+i);
//						putc(*(ptr2-1), dout );
					}
				}
			}
			count=0;
		}
	}
	*ptr2= '\0';
	*status = OK;
	*len = (unsigned)_fstrlen( (char far *) ptr );

//	putc('\n',dout);
//	printf("%d %u ",strlen(ptr), *len);
//	print_all( ptr,stdout);

	return( (void huge *)ptr );
}


void parse_free( void )
{
	if (ptr) farfree(ptr);
	return;
}