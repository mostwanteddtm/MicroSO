/*
 * WEBTCP.C
 *
 * Embedded Web Server
 * Copyright 1998,
 * JK microsystems, Inc. - ALL RIGHTS RESERVED
 * http://www.jkmicro.com
 *
 * THIS SOFTWARE IS NOT SHAREWARE, FREEWARE, OR PUBLIC DOMAIN.
 * IT IS THE PROPERTY OF JK microsystems.
 *
 * CUSTOMERS OF JK microsystems MAY MODIFY THE SOURCE CODE
 * AND/OR DISTRIBUTE THE BINARY IMAGE OF THIS SOFTWARE WITHOUT
 * ADDITIONAL COSTS PROVIDED IT IS RUN ONLY ON HARDWARE
 * MANUFACTURED BY JK microsystems.  ALL OTHER USE IS EXPRESSLY
 * PROHIBITED.
 *
 * THIS SOURCE CODE IS NOT TO BE DISCLOSED WITHOUT PRIOR APPROVAL
 * FROM JK microsystems.
 *
 * THIS PROGRAM IS DISTRIBUTED WITHOUT ANY WARRANTY;
 * WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * THE TCP/IP LIBRARIES ARE COPYRIGHT
 * UNIVERSITY OF WATERLOO.
 * THE LIBRARIES ARE PROVIDED FREE OF
 * CHARGE IN THEIR ORIGINAL DISTRIBUTION FORMAT.
 *
 */

/*
	See WEBTCP.H for revision notes
*/

#pragma option -ml      		// large model
#pragma option -r-				// no register vars
#pragma option -2				// 286 instruction set (may be probs w/ 386 regs and TSRs)

#include "webtcp.h"

extern int _directvideo=0;		// just to be sure, no direct viedo, no video adapter!

static tcp_Socket s;			// socket structure - needs to be in the heap or else big trouble
static char *server="Server: WebTCP 0.00a xxxxxxxx\r\n\0";

char pc=FALSE;					// is it a PC ???
FILE *msg_out=NULL;				// output message stream
FILE *dout=NULL;				// debug message stream

static		struct sockaddr *saptr;    		// socket address pointer ( peer info )
static		int sock_stat;					// socket status

static		char *web_time=NULL;            // pointer to buffer for time stamp

static		char *buffer, buffer2[128];		// misc buffers for string manipulation
static		char *rbuffer=NULL;				// receive buffer
static		char *tbuffer=NULL;				// transmit buffer
static		char query[256];                // query part of header (GET method FORMS)
static		char *bufferloc, *bufptr;       // pointers for processing queries
static		char peeraddr[30];              // internet address that requested page

static		FILE *fp = NULL;                // input file pointer
static		int file_handle;                // DOS file handle
static		struct stat file_stat;			// DOS file statistics, length, etc..
static		unsigned int drive_no;			// DOS drive number
static		unsigned int rdrive_no;         // DOS drive number of initial drive
static		unsigned int file_len;          // file length in usable form
static		char fileext[5];                // file extension used to determine mime type
static		char fileloc[50];               // [drive][path]8.3 file
static		int filetype = TXT;             // file mime type, text, html, etc.
static		char start_path[32];            // path from which server was started

static		char huge *df_ptr;				// pointer to dynamic file loaction
static		char huge *df_index;			// used when retrieving DF

static		int status;			  			// result of processing operation
static		char request=FALSE;             // type of request (HEAD, GET, etc)

static		char rx_done=FALSE;				// flag indicating header received

//                                         ping stuff
//		char *p_ptr = NULL;             // pointer to ping results
//		int pstatus=0;					// status returned by ping request
//		int plen=0;                     // length of ping results

static		char hdwr=FALSE;                // flag to control access to hardware page
static		FILE *hdr_out=NULL;				// place to write headers w/ -h flag - debug

static		int i,j;
static		long t_len;
static		long len;
static		long ticks;						// timer ticks (timeout holder)

#ifdef COUNT
unsigned long count = 0;        // hit count if counter enabled
#endif


void msg(const char* text)
{
	if(msg_out!=NULL) fprintf(msg_out,text);
}

void msgc(char ch)
{
	if(msg_out!=NULL) putc(ch,msg_out);
}

void dbg(const char* text)
{
	if(dout!=NULL) fprintf(dout,text);
}

void dbgc(char ch)
{
	if(dout!=NULL) putc(ch,dout);
}

void hdr(const char* text)
{
	if(hdr_out!=NULL) fprintf(hdr_out,text);
}



void main2(int argc, char *argv[])
{
	bufptr=strstr( server, "0.0" );
	strcpy( bufptr, VERSION );
	strcat( server, "\r\n\0");
	printf("\nEmbedded Web Server %s", bufptr );
	printf("Copyright 1998, JK microsystems - ALL RIGHTS RESERVED\n\n");

	rbuffer = (char *)malloc( RBUF );
	tbuffer = (char *)malloc( TBUF );
	web_time = (char *)malloc( WTBUF );
	saptr = (struct sockaddr *)malloc(sizeof(struct sockaddr));
	buffer = (char *)malloc( 1024 );

	if ( !rbuffer || !tbuffer || !web_time || !saptr || !buffer) {
		printf("Memory allocation error, program halted. \n");
		printf("%p %p %p, %uld\n\n",rbuffer,tbuffer,web_time,(unsigned long)coreleft());
		exit(-1);
	}

	if ( (rbuffer>rbuffer+RBUF) || (tbuffer > tbuffer+TBUF) ){
		printf("SEGMENT PROBLEMS: %Fp %Fp %Fp %Fp\n",
		rbuffer, rbuffer+RBUF, tbuffer, tbuffer+TBUF );
		exit(-1);
	}


	for( i=1; i< argc; i++) {
		if (!strcmp(strupr(argv[i]),"-V")) {
			msg_out = stdout;               // verbose console output
			msg("verbose messaging enabled.\n");
		}

		if (!strcmp(strupr(argv[i]),"-D")) {
			dout = stdout;               // debug output
			dbg("debug enabled.\n");
		}

		if (!strcmp(strupr(argv[i]),"-H")) {
			hdr_out = stdout;               // header debug output
			hdr("header output enabled.");
		}

		if (!strcmp(strupr(argv[i]),"-HF")) {
			if ( (hdr_out = fopen("b:/hdr.out","w")) == NULL ) {
				printf("file open error, using stdout\n");
				hdr_out = stdout;
			}
			else
				printf( "Headers saved to HDR.OUT. " );
		}
	}

	if ( getenv( "TZ" ) == NULL )   // check for time zone environmet
		putenv( TZ_ENV );       // default to PST8PDT

	tzset();                        // set the timezone

	if ( getenv( "PC" ) != NULL ) { // is server running on a PC?
		printf("Drive A ok. ");
		pc=TRUE;
	} else {
//	   printf("drive A forbidden\n");
		pc=FALSE;
	}
	if ( !(strcmp( strupr(getenv( "HDWR" )),"YES")) ) {
		printf("Port A/B Enabled. ");
		hdwr=TRUE;
	}
	else    {
		hdwr=FALSE;
	}

	// test for flashlite hardware... if not, get some!
	if ( !flashlite( (unsigned int)strtoul(getenv( "PC" ), NULL, 16) ) ) {
		printf("\nInvalid Hardware, program exiting.\n");
		exit(-1);
	}

	df_locate();		// see if DFS or parsing TSR installed

#ifdef COUNT
	printf("Requests for homepage.htm will be logged in c:\hit.htm\n");
#endif

	rdrive_no = getdisk();           // get current drive number (root drive)
	if (pc && rdrive_no >=2)
		rdrive_no = rdrive_no + 0x80 - 2;       // correct for PC hard disk ##
	drive_no = rdrive_no;

	sock_init();									// init WATTCP

	printf("\nMy address is: [%s]\n", inet_ntoa( buffer2, gethostid()));

	getcwd( start_path, sizeof(start_path) );
	chdir( DEF_PATH );              // change to working directory
	// need error check, bail if not successful

	printf( "File path=%s\n", getcwd(buffer2, sizeof(buffer2)) );
	printf( "\nPress the SPACE key to exit.\n");

	while ( !kbhit() || dos_getc() != 0x20) {			// exit on space only, avoid false exits

					// when console removed
		msgc('-');

		tcp_listen( &s, WEB_PORT, 0L, 0, NULL, 0 );		// pasive open
		sock_mode( &s, TCP_MODE_BINARY );               // set mode

		msgc('-');

		// these things should get hit ~every T_ESTAB second unless file
		// transfers in progress, then ?????

		// add code to keep watchdog happy
		//		df_tick();				// call df to give it a time slice
		//		p_ptr = (char *)proc_ping( NULL, p_ptr, &plen, &pstatus, msg_out );
		// call ping to give it a time slice

		// probably add hook for user routine here
		// will act similarly to proc_ping() returning location and length
		// of data.  must keep it short to avoid lost requests.

		sock_wait_established( &s, T_ESTAB, NULL, &sock_stat);
		// if timeout, goes to sock_err:, then to top of while (!kbhit())

		msgc('-');

		// we are connected

		request = FALSE;                // dont know request type yet
		rx_done = TRUE;					// assume good, set to bad if timeout
		rbuffer[0] = '\0';              // rbuffer is empty
		ticks=set_timeout(T_RXHEADER);			// set timeout
		bufptr = rbuffer;
		j=0;

		dbgc('.');

		while ( memcmp( bufptr, "\r\n\r\n", 4) != 0 ) {
			kbhit();
			tcp_tick( &s );

			if ( chk_timeout(ticks) ) { // see if we have timed out
				// header not recieved, reset the connection
				msg("-header Rx error, connection reset \n");
				rbuffer[j] = '\0';
				print_all( rbuffer, dout );
				if(msg_out)
					fprintf(msg_out,"length: %d\n", j );
				tcp_tick( &s );
				rx_done = FALSE;
				break;
			}

			if ( sock_rbused( &s ) ) {
				tcp_tick(&s);
				i=sock_fastread( &s, (byte *)buffer, 512 );	// read from socket

				if(i<0) goto sock_err;

				buffer[i]='\0';

				if(j+i>RBUF) {
					if(msg_out) fprintf(msg_out,"buffer overflow\n");
					tcp_tick(&s);
					rx_done=FALSE;
					break;
				}

				memmove( rbuffer+j, buffer, i );						// add stuff to Rx buffer
				j+=i;
				bufptr = ( (j-4) > 0 ? rbuffer+(j-4) : rbuffer);
			}
		}

		rbuffer[j] = '\0';
		dbgc('#');

		getpeername( &s, saptr, NULL);          // get peer address
		inet_ntoa( peeraddr, saptr->s_ip );     // put it in a string

		print_all( rbuffer, hdr_out );

		bufferloc = rbuffer;                    // parse request and filename from header

		while ( rx_done && (*bufferloc != '\0') &&
				( bufferloc < rbuffer+RBUF)  ) {

			i=0;
			while( (*(bufferloc) != '\r') &&
					 (bufferloc < (rbuffer+RBUF) )  ) {
				buffer[i] = *bufferloc;
				i++;
				if ( *bufferloc == '\0' )
					break;
				bufferloc++;
			}
			bufferloc +=2;                  // skip /r /n
			buffer[i] = '\0';       // NULL terminated line from header

			if ( !request ) {
				if ( strstr( buffer,"GET" ) )
					request = GET;
				else if ( strstr(buffer, "HEAD") )
					request = HEAD;
				else if ( strstr(buffer, "POST") )
					request = POST;
				else if ( strstr( buffer, "PUT") )
					request=PUT;
				else
					request=HTTP09;

				if ( request ) {        // if we found the request, we should have a filename...
					// if no request, dont try the rest of this
					// get filename from the header, skip leading '/'

					strncpy( fileloc, strchr( buffer, '/' )+1 , sizeof(fileloc) );

					// store GET method query
					if ( (bufptr=strchr(buffer, '?')) != NULL ) {
						*(strchr(fileloc, '?')) = '\0';         // NULL terminate filename
						strcpy( query, bufptr+1 );              // skip leading '?' store query
						if(msg_out!=NULL)
							fprintf(msg_out, " %s\n%s",query,rbuffer);
					}
					else
					*(strchr(fileloc, ' ')) = '\0'; 		// terminate file name

					if ( request == POST ) {        // store POST method query
						tcp_tick( &s );

						j = atoi(strstr( rbuffer, "Content-length")+15);
						strcpy( query, strstr(rbuffer, "\r\n\r\n")+4 );

						ticks=set_timeout(2);			// 2 second timeout

						while (  strlen(query) < j ) {
							if ( chk_timeout(ticks) ) { // see if we have timed out
								// header not recieved, reset the connection
								msg("-header Rx error, connection reset \n");
								print_all( rbuffer, msg_out );
								tcp_tick( &s );
								rx_done = FALSE;
								break;
							}

							tcp_tick( &s );

							if ( sock_rbused( &s ) ) {
								i=sock_fastread( &s, (byte *)buffer, 1024 ); // read from socket

								if(i<0) goto sock_err;

								buffer[i]='\0';
								strcat( query, buffer );	// add stuff to query buffer
							}
						}

						if (strlen(query) < j) {
					if(msg_out!=NULL)
								fprintf(msg_out, "Tx length: %d  Rx length: %d\n",j, strlen(query));
							print_all(query,msg_out);
							rx_done = FALSE;
							break;
						}
					}

					// sort out file name, drive, etc.
					fix_filename( fileloc );        // convert any '\' to '/'

					strupr( fileloc );              // make it all upper case

					bufptr=strchr(fileloc,':');

					if ( bufptr && fileloc[1] == ':' ) {
						drive_no=(*(bufptr-1))-'A';
						if ( pc && drive_no >=2 )			// fix drive # if PC
							drive_no = drive_no + 0x80 - 2;
					} else
						drive_no = rdrive_no;

					if(*fileloc==0)
//						strcpy(fileloc,"HOMEPAGE.HTM");
						;
					else {
						strncpy( fileext, strchr(fileloc,'.'), 4);
						fileext[4]='\0';
					}

//					printf("extension: %s: ",fileext );
//					printf("-Filename: %s \n", fileloc );

#ifdef COUNT
					// log hits to DEF_PAGE in file on C:
					// should probably be disabled
					if ( !strcmp(fileloc, DEF_PAGE ) ) {      // hit to homepage
						fp=fopen ("c:/hit.htm","r");
						fscanf(fp,"%*s %ld",&count);
						fclose(fp);
						//                                     printf(" %d ",count);
						count++;
						fp=fopen("c:/hit.htm","w");
						make_web_time( web_time );
						//									fprintf(fp,"<html><H1> %ld, %.20s</h1></html>",
						count, web_time+10 );
						fclose(fp);
					}
#endif
				}       // end if (request)...
			}       // end if (!request)...
		}     	// end while (rx_done...

		// build response header

		if ( *fileloc  == '\0' && rx_done ) {  // initial request to IP or name
			make_web_time( web_time );				// file not specified redirect browser to DEF_PAGE
			if (request == HTTP09 ) {
				sprintf( tbuffer, "HTTP/0.9 301\r\n"
					"%s%sLocation: http://%s/%s\r\n"
					"\r\n",server, web_time,
					inet_ntoa( buffer2, gethostid()), DEF_PAGE );
			} else {
				sprintf( tbuffer, "HTTP/1.0 301\r\n"
					"%s%sLocation: http://%s/%s\r\n"
					"\r\n",server, web_time,
					inet_ntoa( buffer2, gethostid()), DEF_PAGE );
			}
			status=MOVED_PERM;
			if(msg_out!=NULL)
				fprintf( msg_out, "-%d: %.20s [%-15s]\n", status, web_time+11, peeraddr );
		} else if ( request==GET || request == POST && rx_done ) { // request for file
			df_ptr=NULL;
//			parse = FALSE;
			if ( fp != NULL ) {  // be sure file is closed and pointer is NULL
				if ( fclose(fp) ) // 0 on success
					fp = NULL;
			}

			if ( strstr(fileloc,"HDWR.SCR") )   {   // request for embedded hardware page
				if ( hdwr ) {
					status=proc_hdwr( query );
				}
				else                            // must have env. var set right
					status=FORBIDDEN;
			}
/*
			else if ( strstr(fileloc,"PING.HTM") ) { // request for ping results
				df_ptr = (char far *)p_ptr; // results should already exist
				file_len = plen;
				printf("p_page: %d %Fp %d\n",pstatus, df_ptr, plen );
				if ( df_ptr && file_len )
					status=OK;
			} else if ( strstr(fileloc,"PING.SCR") )   {      // request for ping script
				p_ptr = (char *)proc_ping( query, p_ptr, &plen, &status, msg_out );
				printf(" %d %Fp %d\n",status, p_ptr, plen );
			}
*/
			else                            // if not internal (embedded) page, no status
				status=FALSE;

			// check for file in dynamic file system (only if not already found)
			if( status == FALSE) {
				df_ptr = (char far *)df( fileloc, &file_len, &status );

				if ( df_ptr != NULL && msg_out!=NULL ) {
					fprintf( msg_out, "\ndf return: %Fp, %d, %d\n", df_ptr, file_len, status );
				}
				else {
					msg("\r---");
//					printf("df return: %d, %Fp\n", status, df_ptr );
				}

//			 for (i=0; i<file_len; i++)
//				 printf("%c",df_ptr[i]);
//          printf("\n");
			}

			if ( status == OK || status == NO_CONTENT) {
				;
//				printf("status: %d %Fp %Fp\n",status, fp, df_ptr);
			}

			else if ( drive_no < 1 && !pc ) {    // no need to access A on flashlite
				status = FORBIDDEN;
			}               // check if drive ready, use bios so DOS doesnt hang

			else if ( (i=biosdisk( READ_DISK, drive_no, 0,1,1,1, buffer )) != 0 ) {
				// give it a second chance
				biosdisk( RESET, drive_no, 0,1,1,1, buffer );
				if( (i=biosdisk( READ_DISK, drive_no, 0,1,1,1, buffer )) != 0 ) {	// drive not available
					status=NOT_FOUND;
//					printf("biosdisk=%d, drive=%d\n",i,drive_no );
				}
				else
					fp= fopen( fileloc,"rb" );
			}
			else {
				fp= fopen( fileloc,"rb" );
			}

			if ( fp && strstr( fileloc, ".SHT" ) ) {
				file_handle = fileno ( fp );
				fstat( file_handle, &file_stat );

				file_len =  (int)file_stat.st_size;

				df_ptr = (char far *)parse_file( fp, &file_len, &status );
				if(dout!=NULL)
					fprintf(dout, "return: %Fp %d %d \n",df_ptr, file_len, status);
//				if ( status == OK )
//					parse=TRUE;

				fclose( fp );
				fp=NULL;
			}

//              when we get here, fp is either a valid, open file, or NULL
//              and dynamic file pointer is valid or NULL

			if ( fp || df_ptr ) {     	// good file, build header w/ file type & length
				if ( fp ) {			// if DOS file, get file handle and length
					file_handle = fileno ( fp );
					fstat( file_handle, &file_stat );
				}

				make_web_time( web_time );
				get_filetype (fileext, buffer, &filetype );

				sprintf( tbuffer, "HTTP/1.0 200 OK\r\n"
					"%s%s"
					"Content-type: %s\r\n"
					"Content-Length: %ld\r\n"
					"Location: http://%s/%s\r\n"
					"\r\n",	server, web_time, buffer,
					(df_ptr ? (long)file_len : file_stat.st_size ),
					inet_ntoa( buffer2, gethostid() ), fileloc );

				status=OK;

				if(msg_out!=NULL)
					fprintf( msg_out, "-%d: %.20s [%-15s] %s, %ld\n",
						status, web_time+11, peeraddr, fileloc,
						(df_ptr ? (long)file_len : file_stat.st_size) );

			} else {          // error - forbidden, not found, etc.
				make_web_time( web_time );
				switch (status) {
				case NO_CONTENT:
					strcpy( tbuffer, "HTTP/1.0 204\r\n");
					if(msg_out) {
						fprintf( msg_out, "-%d: %.20s [%-15s] %s\n", status,
							web_time+11, peeraddr, fileloc );
					}
					break;

				case FORBIDDEN:
					strcpy( tbuffer, "HTTP/1.0 403\r\n");
					if(msg_out) {
						fprintf( msg_out, "-%d FORBIDDEN: %.20s [%-15s] %s\n", status,
							web_time+11, peeraddr, fileloc );
					}
					break;

				default:
					strcpy( tbuffer, "HTTP/1.0 404\r\n");
					status=NOT_FOUND;
					if(msg_out) {
						fprintf( msg_out, "-%d: %.20s [%-15s] %s\n",status, web_time+11,
							peeraddr, fileloc );
					}
				}		// end switch( status )
				strcat( tbuffer, server );
				strcat( tbuffer, web_time );
				if ( status != NO_CONTENT )
					strcat( tbuffer, "Content-type: text/html\r\n");
				strcat( tbuffer, "\r\n" );      // finish header

				print_all( tbuffer, msg_out );
//				printf("\n");
				fclose( fp );
			}
		} else if (rx_done) {             // didn't understand command
			make_web_time( web_time );
			sprintf( tbuffer, "HTTP/1.0 501\r\n%s%s\r\n", server, web_time);

			status=NOT_IMP;

			if(msg_out!=NULL) {
				fprintf( msg_out, "-%d NOT IMPLEMENTED: %.20s [%-15s]\n", status,
					web_time+11, peeraddr );
				if (!request)
					fprintf( msg_out, "Request unknown\n" );

				print_all( rbuffer, msg_out );
				fprintf(msg_out,"\n");
			}
		} else  {         // bad header, or other wierdness
			make_web_time( web_time );
			sprintf( tbuffer, "HTTP/1.0 500\r\n%s%s\r\n",server, web_time);

			status=SERVER_ERR;

			if(msg_out!=NULL) {
				fprintf( msg_out, "-%d SERVER ERROR: %.20s\n", status,
					web_time+11 );
			}

			if (!rx_done) msg("-Incomplete Header\n");

			print_all( rbuffer, hdr_out );
			hdr("\n");
		}

		if ( !(status == OK && request == HTTP09) )		// no header if HTTP0.9 get
			sock_write( &s, (byte *)tbuffer, strlen(tbuffer) );		// send the header

		// build and send the message body (if any)
		switch ( status ) {
		case OK:
			if (request == HEAD)     // if head request, nothing else to do
			break;

			if ( df_ptr ) {
				df_index = df_ptr;
				len=(long)file_len;
			} else {
				len= file_stat.st_size;
			}

			ticks=biostime(0,0L) ;

			while ( len > 0L ) {
				if(_chk_socket(&s)==0)	// insure that the socket is valid
					break;

				t_len = (len < (long)(i=sock_tbleft( &s )) ) ? (int)len : i;

				if ( !t_len ) { 		// if no space available, dont try to send anything
					tcp_tick( &s );
					kbhit();
				} else if ( df_ptr != NULL ) {
					if ( sock_fastwrite( &s, (byte *)df_index, t_len ) != t_len ) {
						msg("ERROR: sock_write\n");
						sock_abort( &s );
						break;
					}
					df_index+= t_len;
				} else {
					if ( (i=fread( (void *)tbuffer, sizeof(char), t_len, fp )) != t_len) {
						if(msg_out)
							fprintf( msg_out, "file error %d %d %d\n",
								t_len, strlen(tbuffer), i );
						break;
					}

					if (t_len && sock_fastwrite( &s, (byte *)tbuffer, t_len ) != t_len ) {
						msg("ERROR: sock_write\n");
						sock_abort( &s );
						break;
					}

					if ( !(t_len=i) )
						len=0L;
				}

				len -= (long)t_len;		// len = length left to send

				tcp_tick( &s );
/*
				tcp_tick(&s);

				if(df_ptr!=NULL) {
					if(sock_write(&s,(byte*)df_ptr,file_len)!=file_len) {
						fprintf(msg_out,"Error: sock_write\n");
						sock_abort(&s);
						break;
					}
					len=0;
				} else {
					set_timeout(10);
					t_len = len<TBUF ? len : 500;

					if((i=fread(tbuffer,sizeof(char),(int)t_len,fp))!=t_len) {
						fprintf(msg_out,"Error: fread\n");
						sock_abort(&s);
						break;
					}

					if(sock_write(&s,(byte*)tbuffer,(int)t_len)<0) {
						fprintf(msg_out,"Error: sock_write\n");
						sock_abort(&s);
						break;
					}
					len-=t_len;
				}
*/
			}

			if(dout!=NULL)
				fprintf( dout, "%ld ", (biostime(0,0L)-ticks) );
			ticks=biostime(0,0L);

			tcp_tick( &s );

			if ( fp ) fclose( fp );
				break;

		case NOT_FOUND:
			if (request != GET) {		// if not a GET request, dont send reply message
				break;
			}
			sprintf( tbuffer, "<html><body>\n <h1>404 Not Found</h1>\r\n"
				"The requested URL was not found on this server\r\n"
				"</body></html>\r\n"
				"\r\n\0" );
			print_all( tbuffer, msg_out );
			sock_write( &s, (byte *)tbuffer, strlen(tbuffer) );
			break;

		case FORBIDDEN:
			if (request != GET)
				break;

			sprintf(tbuffer, "<html><body>\n <h1>403 Forbidden</h1>\r\n"
				"Access to the requested URL is forbidden.\r\n"
				"</body></html>\r\n"
				"\r\n\0" );

			sock_write( &s, (byte *)tbuffer, strlen(tbuffer) );
			break;

		case NO_CONTENT:
		case MOVED_PERM:
			break;

		default:
			if(dout!=NULL)
				fprintf( dout, "Status= %d\n",status );

			print_all(rbuffer,msg_out);

		}			// end switch( status )

		//		sock_flush( &s );			  	// flush unsent data and close the socket

		tcp_tick( &s );
		sock_close( &s );
		tcp_tick( &s );

		if(dout!=NULL)
			fprintf( dout, "%ld ",biostime(0,0L) - ticks );
		ticks=biostime(0,0L);

		dbgc('\n');
		sock_wait_closed (&s, 2, NULL, &sock_stat );		// wait for socket to close, timeout=2seconds

sock_err:                                       // get here when socket closes or other WATTCP error
		if ( sock_rbused( &s ) && msg_out!=NULL) {
			fprintf(msg_out,"rx ready: %d", sock_rbused( &s ) );
		}
		if (fp != NULL)							// be sure input file is closed.
			fclose(fp);

		msgc('\r');
//		msgc('\n');

		strcpy( buffer, sockerr( &s ) );
		if (strcmp ( buffer, "Open timed out") && dout!=NULL) {
			fprintf(dout,"%ld - ",biostime(0,0L) - ticks );
			fprintf(dout,"%s\n\n",buffer);
		}
		else
			msgc('\r');
	}	// end while( !kbhit() )	( main loop )

	free( buffer );					// free up allocated memory
	free( saptr );
	free( web_time );
	free( tbuffer );
	free( rbuffer );
	parse_free();
	fclose( hdr_out );

	//ping_free( p_ptr );			// force ping to free memory

	chdir( start_path );			// reset directory to startup dir

	if ( kbhit() )					// grab char to keep command line clean
		dos_getc();

	msgc('\n');
	return;
}

int main(int argc, char *argv[])
{
	static char far *p;
	static unsigned old_ss, old_sp, old_stklen;

	if ((p = farmalloc (66000L)) == NULL)	{
		printf ("\nNo room to allocate stack buffer! %X\n",(unsigned long)coreleft() );
		exit (1);
	}

	(long)p += 0x00010000L;   			// increment segment
	p -= 4;                  			// set offset to zero

	// p is now = (xxxx + 1):0000

	old_ss = _SS;            			// save old values
	old_sp = _SP;
	old_stklen = _stklen;

	_stklen = 60000U;        			// change the stack length (for checking)

	_SS = FP_SEG (p);        			// set up our new stack segment
	_SP = FP_OFF (&(p[_stklen]));		// set the stack to the top

	main2(_argc,_argv);					// use globals _argc & _argv because calls get lost w/ stack change

	_SS = old_ss;            			// reset the values
	_SP = old_sp;
	_stklen = old_stklen;

	(long)p -= (0x00010000L - 4);	   // set the pointer back to what it was to free it
	free ((void *) p);
	return (0);
}


