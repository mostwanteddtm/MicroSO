/*
 * PING.C
 *
 * Embedded Web Server
 * Copyright 1998,
 * JK microsystems, Inc. - ALL RIGHTS RESERVED
 * http://www.jkmicro.com
 *
 * THIS SOFTWARE IS NOT SHAREWARE, FREEWARE, OR PUBLIC DOMAIN.
 * IT IS THE PROPERTY OF JK microsystems.
 *
 * CUSTOMERS OF JK microsystems MAY MODIFY THE SOURCE CODE
 * AND/OR DISTRIBUTE THE BINARY IMAGE OF THIS SOFTWARE WITHOUT
 * ADDITIONAL COSTS PROVIDED IT IS RUN ONLY ON HARDWARE
 * MANUFACTURED BY JK microsystems.  ALL OTHER USE IS EXPRESSLY
 * PROHIBITED.
 *
 * THIS SOURCE CODE IS NOT TO BE DISCLOSED WITHOUT PRIOR APPROVAL
 * FROM JK microsystems.
 *
 * THIS PROGRAM IS DISTRIBUTED WITHOUT ANY WARRANTY;
 * WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * THE TCP/IP LIBRARIES ARE COPYRIGHT
 * UNIVERSITY OF WATERLOO.
 * THE LIBRARIES ARE PROVIDED FREE OF
 * CHARGE IN THEIR ORIGINAL DISTRIBUTION FORMAT.
 *
 */

/*
   See WEBTCP.H for revision notes
*/

#include "ping.h"

// ping destination(s) given in query.  return standard
// response string in html using DF protocol.
// there will be a static buffer in memory to
// hold this info, allocated by proc_ping() if not there.
// try to resolve given destination.
// may expand
// to include standard ping arguments, but not now.

// state machine
// PSTATE_ENTER - queue requests
// PSTATE_SEND - pull request from queue and send
// PSTATE_RXCHK - check for result/timeout, update output buffer
// PSTATE_DCHK - check for done/loop to PSTATE_SEND
// PSTATE_RESET - reset

// ex:  http://..../ping?n=129.97.176.98&n=jkmicro.com
//      look at ping.htm for the results

static int ping_state=0;
static struct pingq_struct *pingq;
static struct pingq_struct *pingq_p;
static char tmp[255];

void *proc_ping ( char *inbuf, char *outbuf, int *length, int *status, FILE *msg_out )
{
char *ptr, *ptr2;              // parsing pointers
struct pingq_struct *pptr;	// place holder
longword host, timer, sent=0L, new_rcvd;

		if (!ping_state && !inbuf) {            // idle state, do nothing,
//                printf("! l=%d ", *length );
				return( (void *)outbuf );       // dont trash buffer
		}
		else if ( ping_state && inbuf) { // not re-entrant
//				fprintf( msg_out, " not reentrant ");
				*status=FORBIDDEN;
				return( (void *)outbuf );               // dont trash buffer
		}
		else
				{ ; }
//                printf("%d %p %d\n", ping_state, outbuf, *length);

		if ( !outbuf ) {
				outbuf=(char *)malloc( PING_BUF );
//                printf(" %p ", outbuf );

		}
		if ( !pingq )
				pingq=(struct pingq_struct *)malloc(sizeof(struct pingq_struct));

		if (!outbuf || !pingq) {
//				fprintf( msg_out, "Ping: Memory allocation error\n");
					 *status=FORBIDDEN;
					 *length=0;
				if ( pingq )
						free( pingq );
				if ( outbuf )
						free( outbuf );

				return( NULL );
		}

		switch (ping_state) {
				case PSTATE_ENTER:
//                        r_no++;         // debug, number of requests
//                        sprintf(outbuf, "<body> %d\n", r_no );
						make_web_time( tmp );
						sprintf(outbuf, "<body>%s<br>\n", tmp);

						pingq->name[0] = '\0';
						pingq->next = NULL;
						pingq_p = pingq;

						strupr( inbuf );   // make it upper case
//                        printf("%s\n",inbuf);

						ptr=strstr(inbuf,"N=");
						if((ptr == NULL) || (*(ptr+2) == ' ')) {
//								fprintf( msg_out, "Ping: Bad request string %s\n", inbuf );
								*status=NOT_FOUND;
								*length=0;
								return( (void *)outbuf );       // bail out
						}
						while ( ptr ) {
								ptr+=2;         // advance past 'N='

								strcpy( pingq_p->name, ptr );           // copy host name into list
								if ( (ptr2=strchr(pingq_p->name,'&') ) != NULL )
										*ptr2='\0';             // terminate if more host names

								if ( (ptr2=strchr(pingq_p->name, ' ') ) != NULL )
										*ptr2='\0';             // terminate if last entry

								if ( (ptr2=strchr(pingq_p->name, '\r') ) != NULL )
										*ptr2='\0';             // terminate if last entry

//                              printf("[%s] %Fp, ",pingq_p->name, pingq_p);

								ptr = strstr( ptr, "N=" );              // find next address request
								if ( ptr ) {            // if another request, make space for it
										pingq_p->next = (struct pingq_struct *)malloc(sizeof(struct pingq_struct));
										if (pingq_p->next == NULL){
//												fprintf( msg_out, "Ping: Memory error, allocation in _ENTER failed");
												break;
										}
										pingq_p = pingq_p->next;
										pingq_p->next = NULL;

								}
								else
										pingq_p->next = NULL;
						}

						ping_state++;   // go on to next state
						pingq_p = pingq;       // point to the beginnign of list
//                      printf("\n");
//                      printf("\nexit state %d\n",ping_state);
				break;        // should give us a linked list of names to process

				case PSTATE_SEND:
//                      resolve... name to IP
						ptr = pingq_p->name;    // pull name off queue
//                        printf("\n%d %s\n",ping_state,ptr);

						if (*ptr == '\0' ) {
//                              printf("null request\n");
								ping_state++;
								break;
						}

						if (!(host = resolve( ptr ))) {
								sprintf( outbuf+(*length), "Unable to resolve '%s'<BR>\n", ptr );
//								if(msg_out)
//									fprintf( msg_out, "Unable to resolve: '%s'\n", ptr );
								ping_state=PSTATE_DCHK;
//                              *status=OK;
//                              *length=strlen( outbuf );
								break;
						}
//                      ping...
						pingq_p->host = host;
						pingq_p->timeout=PING_TIMEOUT;
						if ( isaddr( ptr )) {
//							if(msg_out!=NULL)
//								fprintf( msg_out, "Pinging [%s]...\n",inet_ntoa(tmp, host));
							sprintf( outbuf+(*length), "Pinging [%s]...",inet_ntoa(tmp, host));
						}
						else {
//							if(msg_out!=NULL)
//								fprintf( msg_out, "Pinging '%s' [%s]...\n", host, inet_ntoa(tmp, host));
							sprintf( outbuf+(*length), "Pinging '%s' [%s]...", host, inet_ntoa(tmp, host));
						}

						_arp_resolve( host, (eth_address *)tmp, 0 );   // resolve it before timer starts

						if (_ping( host , sent )) {
//							if(msg_out!=NULL)
//								fprintf( msg_out, "There was no response.\n" );
							strcat( outbuf+(*length), "There was no response.<br>\n" );
							ping_state=PSTATE_DCHK;         // bail out, get next request
							break;
						}
//                      printf("sent PING, ");  // (%d bytes), ", sizeof(struct icmp_echo) );
//                      sprintf( tmp, "sent PING, ");   // (%d bytes), ", sizeof(struct icmp_echo) );
//                      strcat ( outbuf, tmp );

						tcp_tick(NULL);
						ping_state++;
				break;

				case PSTATE_RXCHK:

						if ( *(pingq_p->name) == '\0' ) {     // dont process null requests
								ping_state++;
								break;
						}
						if ((timer = _chk_ping( pingq_p->host , &new_rcvd)) != 0xffffffffL) {
//                                printf("\nresponse time %lu.%02lu seconds\n",
//                                                        timer / 18L, ((timer %18L)*55)/10 );
								sprintf( tmp, "response time %lu.%02lu seconds.<br>\n",
											timer / 18L, ((timer %18L)*55)/10 );
								strcat( outbuf, tmp );
								ping_state++;
								break;
						}

						if ( !(pingq_p->timeout--) ) {
//                                printf("\nRequest timed out.\n" );
								strcat( outbuf, "Request timed out.<br>\n" );
								ping_state++;
						}
				break;

				case PSTATE_DCHK:
						if (pingq_p->next != NULL) {
//                                printf("chk free:%Fp %Fp %2d ",pingq_p, pingq_p->next, (int)*(pingq_p->name));
								pptr=pingq_p->next;
								free( pingq_p );        // free finished request
								pingq_p=pptr;           // move to next item in list
								ping_state=PSTATE_SEND;
//                                printf("%Fp %Fp\n",pingq_p, pingq_p->next );
						}
						else {
								ping_state++;
						}
				break;

				case PSTATE_RESET:
//                        printf("rst free:%Fp %Fp %d\n",pingq_p, pingq_p->next, (int)*(pingq_p->name));
						free( pingq_p );        // free finished request
						pingq=NULL;             // nothing in list
						ping_state = PSTATE_ENTER;       // do it again
						strcat( outbuf, "</body>\r\n\0" );
				break;
		}

		*status = NO_CONTENT;
		*length = strlen( outbuf );

//        printf(" rl=%d ", *length);
		return( (void *)outbuf );
										  // change screens or give error
}

void ping_free( char *ptr )                // force free of memory, program exiting
{
		if (!ptr)     			// free buffer memeory
			free(ptr);

		if (pingq == NULL )     // nothing to do
				return;
		while (pingq) {
				pingq_p = pingq;
				pingq = pingq->next;
				free(pingq_p);
		}
		return;
}
