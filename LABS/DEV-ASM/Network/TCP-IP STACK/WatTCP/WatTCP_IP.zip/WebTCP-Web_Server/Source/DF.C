/*
 * DF.C
 *
 * Embedded Web Server
 * Copyright 1998,
 * JK microsystems, Inc. - ALL RIGHTS RESERVED
 * http://www.jkmicro.com
 *
 * THIS SOFTWARE IS NOT SHAREWARE, FREEWARE, OR PUBLIC DOMAIN.
 * IT IS THE PROPERTY OF JK microsystems.
 *
 * CUSTOMERS OF JK microsystems MAY MODIFY THE SOURCE CODE
 * AND/OR DISTRIBUTE THE BINARY IMAGE OF THIS SOFTWARE WITHOUT
 * ADDITIONAL COSTS PROVIDED IT IS RUN ONLY ON HARDWARE
 * MANUFACTURED BY JK microsystems.  ALL OTHER USE IS EXPRESSLY
 * PROHIBITED.
 *
 * THIS SOURCE CODE IS NOT TO BE DISCLOSED WITHOUT PRIOR APPROVAL
 * FROM JK microsystems.
 *
 * THIS PROGRAM IS DISTRIBUTED WITHOUT ANY WARRANTY;
 * WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * THE TCP/IP LIBRARIES ARE COPYRIGHT
 * UNIVERSITY OF WATERLOO.
 * THE LIBRARIES ARE PROVIDED FREE OF
 * CHARGE IN THEIR ORIGINAL DISTRIBUTION FORMAT.
 *
 */

/*
   See WEBTCP.H for revision notes
*/
#pragma option -ml
#pragma option -r-
#pragma option -2				// 286 instruction set (may be probs w/ 386 regs and TSRs)

#include "df.h"
#include <string.h>

//#define DFS1
#define DFS2

union REGS regs;                // i86 processor regs
struct SREGS sregs;             // i86 segment regs

static unsigned int far *df_seg	= NULL;
static unsigned int df_off = 0x108;
static char par_found=0;

char df_locate ( void )			// see if DFS is present and get its code segment
{
unsigned int far *par_seg;
unsigned int far *par_off;
int far *i;
char far *c;

	df_seg = MK_FP(0, DF_SEG );		// get DFS segment register from int table
	i=MK_FP(*df_seg,0x105);
	c=MK_FP(*df_seg,0x107);
//	printf("%p %p %x %x",i,c,*i,(int)*c);

	if (*i != DF_SIG || *c < DF_VER ) {
		df_seg=NULL;
	}
	else
		printf("DFS Version %c.%c found.\n",0x30+((*c&0xF0)>>4),0x30+(*c&0xf) );

	par_seg = MK_FP( 0, PAR_SEG );					// parse int segment from int table
	par_off = MK_FP( 0, PAR_OFF );					// parse int offset from int table
	c=MK_FP(*par_seg, (*par_off + 20) );			// skip over startup code and look for signature and version
	i=MK_FP(*par_seg, (*par_off + 18) );

	if ( !par_seg || *c < 0x10 || *i != DF_SIG ) {
		par_found=FALSE;
	}
	else {
		par_found = TRUE;
		printf("INT 31h Version %c.%c found.\n",0x30+((*c&0xF0)>>4),0x30+(*c&0xF) );
	}

	if (!df_seg && !par_found ) {
		printf("TSR not found!\n");
		return( 0 );
	}
	else
		return( 1 );

}


/* void df_tick ( void )           // call df to give it a time slice
{
		if ( pc )
				return;
//		regs.w.ax = DF_TICK_FUNC;
//		int86( DF_INT, &regs, &regs );
		return;
}
*/
#ifdef DFS2
void huge *df ( char *filename, unsigned int *len, int *status )
{
static char far *df_name;
static int far *df_len;
static unsigned int *df_file;
static int i;
static char filelow[13];

	*len = 0;
	if ( !df_seg ) {
			*status = NOT_FOUND;
			return(NULL);
	}
	strcpy(filelow,filename);
	strlwr(filelow);

	for (i=0,df_off=0x108; i<4; i++, df_off+=17) {
		df_name = MK_FP(*df_seg, df_off);
		df_len = MK_FP(*df_seg, df_off+(strlen(df_name)+1) );
		df_file = MK_FP(*df_seg, df_off+15);

//		if(dout!=NULL) {
//			fprintf(dout, "\n\t%s %x %Fp %Fp %X\n",df_name, *df_len, df_name,
//				df_len, *df_file);
//		}

		if (!strcmp(df_name,filelow) ) {
			*status = OK;
			*len = *df_len;
//			printf("MATCH!\n");
			return( (void huge *)MK_FP(*df_seg,*df_file) );
		}
	}
	*status = NOT_FOUND;
	return(NULL);
}
#endif

#ifdef DFS1
void huge *df ( char *filename, int *len, int *status )
{
		*len=0;
		*status=NONE;

//        printf("\ndf: %s ", filename );
		if ( 0 ) {
				printf( "DF not supported.\n " );
				*status = FORBIDDEN;
				return ( NULL );
		}

		regs.w.ax = DF_TICK_FUNC;              // check that DF present

//        printf("\n %x %x",(int)DF_INT,(int)regs.w.ax );

		int86( DF_INT, &regs, &regs );
//        printf("\n %x %x\n",(int)regs.w.bx,(int)regs.w.cx );

		if (regs.w.cx != DF_SIG || regs.h.bl < DF_VER ) {
				*status = NOT_FOUND;    // was FORBIDDEN
				return ( NULL );
		}

		segread( &sregs );
//		printf("cs:%x ds:%x es:%x ss:%x\n", sregs.cs, sregs.ds, sregs.es, sregs.ss);
		sregs.es = FP_SEG( (char far *)filename );
		regs.w.bx = FP_OFF( (char far *)filename );
		regs.w.ax = DF_REQ_FUNC;

		int86x( DF_INT, &regs, &regs, &sregs );

//		printf("   cs:%x ds:%x es:%x ss:%x\n", sregs.cs, sregs.ds, sregs.es, sregs.ss );
//        printf(" int86x return: %d %X:%X\n", regs.w.cx, sregs.es, regs.w.bx);

		*len = regs.w.cx;
		if (*len)
				*status = OK;
		else
				*status = NOT_FOUND;

//        printf("%Fp len=%d ", MK_FP (sregs.es, regs.w.bx), *len);

		if ( *len )
				return( MK_FP( sregs.es, regs.w.bx) );
		else
				return( NULL );
}

#endif

// static char s_counter[10];
// static int counter = 0;

void huge *parse_value( int index, unsigned int *len, int *status )
{
	if ( !par_found ) {
		*len = 0;
		*status = NOT_FOUND;
		return(NULL);
	}
	segread( &sregs );
//		printf("cs:%x ds:%x es:%x ss:%x\n", sregs.cs, sregs.ds, sregs.es, sregs.ss);
//	if(dout!=NULL)
//		fprintf(dout," s: %.4x:%0.4x", _SS, _SP );

	regs.w.ax = 0x100 | (index & 0xff);
	int86x( PAR_INT, &regs, &regs, &sregs );

//	if(dout!=NULL) {
//		fprintf(dout," ax:%.4x bx:%.4x cx:%.4x s: %.4x:%0.4x ",
//			regs.w.ax, regs.w.bx, regs.w.cx, _SS, _SP );
//	}

	if ( (*len = regs.w.ax) != 0 ) {
		*status = OK;
		return( MK_FP( regs.w.cx, regs.w.bx) );
	}
	else {
		*status = NOT_FOUND;
		return( NULL );
	}
}

