/*
 * UTIL.C
 *
 * Embedded Web Server
 * Copyright 1998,
 * JK microsystems, Inc. - ALL RIGHTS RESERVED
 * http://www.jkmicro.com
 *
 * THIS SOFTWARE IS NOT SHAREWARE, FREEWARE, OR PUBLIC DOMAIN.
 * IT IS THE PROPERTY OF JK microsystems.
 *
 * CUSTOMERS OF JK microsystems MAY MODIFY THE SOURCE CODE
 * AND/OR DISTRIBUTE THE BINARY IMAGE OF THIS SOFTWARE WITHOUT
 * ADDITIONAL COSTS PROVIDED IT IS RUN ONLY ON HARDWARE
 * MANUFACTURED BY JK microsystems.  ALL OTHER USE IS EXPRESSLY
 * PROHIBITED.
 *
 * THIS SOURCE CODE IS NOT TO BE DISCLOSED WITHOUT PRIOR APPROVAL
 * FROM JK microsystems.
 *
 * THIS PROGRAM IS DISTRIBUTED WITHOUT ANY WARRANTY;
 * WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY
 * OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * THE TCP/IP LIBRARIES ARE COPYRIGHT
 * UNIVERSITY OF WATERLOO.
 * THE LIBRARIES ARE PROVIDED FREE OF
 * CHARGE IN THEIR ORIGINAL DISTRIBUTION FORMAT.
 *
 */

/*
   See WEBTCP.H for revision notes
*/

#pragma option -ml
#pragma option -r-
#pragma option -2				// 286 instruction set (may be probs w/ 386 regs and TSRs)


#include "util.h"

static char *dayname[] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
static char *monthname[] = { "Jan", "Feb", "Mar", "Apr", "May", "Jun",
							 "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

void fix_filename ( char *fn )
{
		while ( *fn != '\0' ) {
				if (*fn == '\\')
						*fn = '/';
				fn++;
		}
		return;
}

// determine mime type of file given extension
// input:       pointer to extension
// output:      buffer containing mimetype string
//              integer file type (from defined list)

void get_filetype ( char *ext, char *buffer, int *filetype)
{
		if ( !strcmp( ext, ".GIF" ) ) {
				*filetype = GIF;
				strcpy( buffer, "image/gif\0");
		}
		else if ( !strcmp( ext, ".JPG" ) ) {
				*filetype = JPG;
				strcpy( buffer, "image/jpeg\0");
		}
		else if ( !strcmp( ext, ".HTM" ) ) {
				*filetype = HTML;
				strcpy( buffer, "text/html\0");
		}
		else if ( !strcmp( ext, ".TXT" ) ) {
				*filetype = TXT;
				strcpy( buffer, "text/plain\0");
		}
		else if ( !strcmp( ext, ".PDF" ) ) {
				*filetype = PDF;
				strcpy( buffer, "application/pdf\0");
		}
		else if ( !strcmp( ext, ".ZIP" ) ) {
				*filetype = ZIP;
				strcpy( buffer, "application/zip\0");
		}
		else if ( !strcmp( ext, ".SHT" ) ) {
				*filetype = HTML;
				strcpy( buffer, "text/html\0");
		}
		else  {
				*filetype = DEF;
				strcpy( buffer, "*/*\0");
//				printf("file extension: %s ", fileext);
		}
}


// string must be of form port=(A,B,DIR_AB)&v=xx&v=xx&act=(READ,SET,CLEAR)
// xx: 0..9, A..F, hex value
// multiple V= strings are ANDed togetor to generate a mask for the operation

int proc_hdwr ( char *buffer )
{
unsigned int port;           	// I/O port location
unsigned char value=0;      	// operation Bit Mask
unsigned char c;				// 8bit port data
char *ptr;              		// parsing pointer
// int i;						// debug storage

		strupr( buffer );   // make it upper case
//        printf("proc_hdwr\n");
//        printf("%s\n",buffer);

		if( (ptr=strstr(buffer,"PORT")) == NULL )
				return (NOT_FOUND);             // request failed

		ptr+=5;         // advance past 'port='
		switch (*ptr) {
				case 'A':
						port=PORT_A;
						break;
				case 'B':
						port=PORT_B;
						break;
				case 'D':
						port=PORT_AB_DIR;
						break;
				case 'R':
						port=PORT_RELAY_IO;
						break;
				default:
						return (NOT_FOUND);     // request failed
		}
//		printf("port:%x ",(int)port );

		while ( (ptr = strstr(ptr,"V=")) != NULL && *ptr != '\0' ) {
				ptr+=2;         // advance past 'V='

				// compile bitmask
				value |= ( (*ptr >= 'A' && *ptr <= 'F') ? *ptr-0x37 : *ptr - 0x30) << 4;
				value |= (*(ptr+1) >= 'A' && *(ptr+1) <= 'F') ? *(ptr+1)-0x37 : *(ptr+1) - 0x30;

//                printf("|%x %x| ", (int)(*ptr), (int)*(ptr+1) );
		}
//        printf("value=%X, ",(int)value );
		ptr = (strstr(buffer,"ACT"));

		c=inportb(port);
//        i=c;				// store initial value (debug)
		if (*(ptr+4) == 'R') {
				printf(" read ");              // nothing else yet.
		}

		else if (*(ptr+4) == 'S' && !pc ) {
				c |= value;
				outportb( port, c );
//                printf("set: %x->%x |", (unsigned int)i, (unsigned int)c );
		}
		else if (*(ptr+4) == 'C' && !pc ) {
				c &= ~value;
				outportb( port, c );
//                printf("clear: %x->%x |", (unsigned int)i, (unsigned int)c );
		}
		else {
				;
//                printf("PC: %x %x|", (int)port, (int)value);
//                printf("%s\n",buffer);
		}

		return(NO_CONTENT);     // good return code, browser shouldn't
								// change screens or give error
}

void print_all (char *buf, FILE *out )     // print string displaying /n and /r
{                                          // sends to open file
	if(out==NULL) return;

		while (*buf != '\0' ) {
				if (*buf == '\r')
						fprintf( out, "\\r");
				else if (*buf == '\n' )
						fprintf( out, "\\n\n");
				else
						putc(*buf, out);
				buf++;
		}
}


void make_web_time (char * wt )         // format time/date per RFC-822
{
struct tm *tp;
time_t sec_now;

		time(&sec_now);
		tp = gmtime(&sec_now);

		sprintf( wt, "Date: %3s, %02d %03s %4d %02d:%02d:%02d GMT\r\n\0",
				dayname[tp->tm_wday], tp->tm_mday, monthname[tp->tm_mon],
				tp->tm_year + 1900, tp->tm_hour, tp->tm_min, tp->tm_sec );

//        printf("%s\n",wt);
}

// use int15h to verify JK micro company ID in MAC
int flashlite( unsigned int mac)
{
		if ( !pc ) {
			regs.w.ax= MAC_FCN;
			int86( IO_EXT_INT, &regs, &regs );
			if ((regs.w.bx == MAC_HI) && ((regs.w.cx & 0x00FF) == MAC_LO))
				return (1);
		}
		else if ( mac==MAC_HI )
			return (1);

		return (0);
}

int dos_getc( void )					// use DOS to get key from console and not echo
{										// assumes character is available.
	regs.h.ah=DOS_GETKBD;
	int86( DOS_INT, &regs, &regs);
	return((int)regs.h.al);
}

