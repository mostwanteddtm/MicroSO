#include <stdio.h>
#include <dos.h>
#include <conio.h>
#include <string.h>
#include <time.h>
#include <values.h>

#define ACK 0x06						// ascii acknowledge (ACK) character
#define FILENAME "dfshome.htm"			// file to send
#define FILENAME2 "dfhome.htm"			// file to send

#define RxB1  0xff70		// receive buffer register
#define TxB1  0xff72		// transmit buffer register
#define SRMS1 0xff75		// Serial reception MSCR (macro service control reg.)
#define STMS1 0xff76		// Serial transmission macro service control reg.)
#define SCM1  0xff78		// Serial mode register
#define SCC1  0xff79		// Serial control register
#define BRG1  0xff7a		// Baud rate generator
#define SCS1  0xff7b		// Serial status register
#define SEIC1 0xff7c		// Serial error interrupt request control register
#define SRIC1 0xff7d		// Serial reception interrupt request control reg.
#define STIC1 0xff7e		// Serial transmit interrupt request control reg.

#define SFR_BASE_ADDR  0xf000
unsigned char get_sfr_byte(int reg)
{
unsigned char far *pcb;
	pcb = MK_FP(SFR_BASE_ADDR, reg);	// SCC1 (serial comm control register)
	return(*pcb);
}

void put_sfr_byte(int reg, unsigned char v)
{
unsigned char far *pcb;
	pcb = MK_FP(SFR_BASE_ADDR, reg);	// SCC1 (serial comm control register)
	*pcb = v;
}

void set_uart( void ) {
char scm;

//		set baud	9600
			put_sfr_byte(SCC1, 2);
			put_sfr_byte(BRG1, 0x82);
//		set data bits 	8
			scm = get_sfr_byte(SCM1);
			scm |= 0x08;
			put_sfr_byte(SCM1, scm);

//		set stop bits	1
			scm = get_sfr_byte(SCM1);
			scm &= 0xfb;
			put_sfr_byte(SCM1, scm);

//		set parity	none
			scm = get_sfr_byte(SCM1);
			scm &= 0xcf;
			put_sfr_byte(SCM1, scm);

}
/*transmit a character */
void f_putchar(char c)
{
unsigned char p;
int delay=4000;

	do{
		p = get_sfr_byte(SCS1);  // serial status register
		if(p & 0x20){
			put_sfr_byte(TxB1, c);
			return;
		}
	}while(delay--);
}

main( void )
{
	unsigned int packet_no=0;					// packet number
	int headerlen=0;							// length of ACK+filename+length
	int filelen=0;								// complete file length
	unsigned char filelen_hi=0, filelen_lo=0;	// file length parts
	unsigned int chksum=0;						// complete checksum
	unsigned char chksum_hi=0, chksum_lo=0;		// checksum parts
	char file1[4096], file2[4096]; 				// big buffers for files
	char outfile[16384];
	char *bufp;									// pointer for parsing
	char tmp[128];								// temp for string processing
	FILE *fp;                       		    // disk file pointer
	time_t sec_now;			   					// stuff to work w/ time/date
	char c;
	int i;

	printf("File: %s\n", FILENAME );
										// set up serial port 9600,8,n,1
	set_uart();

	bufp = file1;						// read first file
	fp=fopen("home1.htm","rt");
	while ( (c=getc(fp)) != EOF ) {
		*bufp++ = c;
	}
	*bufp = '\0';						// null terminate frist piece
	fclose(fp);

	bufp = file2;						// read second file
	fp=fopen("home2.htm","rt");
	while ( (c=getc(fp)) != EOF ) {
		*bufp++ = c;
	}
	*bufp = '\0';						// null terminate frist piece
	fclose(fp);

	while ( !kbhit() || (kbhit() && ((c=getch()) != ' ')) ){
		if (c=='b') {
			printf("Forced bad checksum \n");
			chksum +=10;
			c=0;
		}
		chksum=0;
		filelen=0;
		headerlen=0;
		packet_no++;					// increment packet number

		// build output file
		// use ACKs as place holders for NULL and file length
		sprintf( outfile, "%c%s%c%c%c", ACK,FILENAME,ACK,ACK,ACK );
		headerlen=strlen(outfile);		// header length

		strcat(outfile, file1);			// append header file

		time(&sec_now);					// create ascii time/date stamp
		sprintf(tmp,"<P>The time is %.24s<p>This is packet #%u<P>",ctime(&sec_now), packet_no );
		strcat( outfile, tmp);

		strcat( outfile, file2);	  	// append footer file

		filelen=strlen(outfile);          	// get length of file
		filelen_hi=(unsigned char)((filelen-headerlen)>>8);		// make file length in 2 ascii chars
		filelen_lo=(unsigned char)((filelen-headerlen)&0xFF);

		bufp=strchr(outfile+1,ACK);	 	// have packet length, fill in place holders

		*bufp = NULL;					// put NULL into packet header
		*(bufp+1)=filelen_lo;			// plug file length into packet
		*(bufp+2)=filelen_hi;

		for (i=0; i < filelen; i++) {				// send file to COM port
			chksum+=(unsigned char)outfile[i];      // add data to checksum

//			outportb(DATA1,outfile[i]);              // write it to the UART
//			while ( !(inportb(LSR1) & 0x20)  ) {;}	// wait for char to transmit
			f_putchar(outfile[i]);
		}

		chksum = (unsigned int)(0x10000L - (long)chksum); 	// convert chksum to 2's complemnet

		chksum_lo=(unsigned char)(chksum&0xFF);		// send low byte of chksum
//		outportb(DATA1,chksum_lo);
//		while ( !(inportb(LSR1) & 0x20)  ) {;}		// wait for char to transmit
		f_putchar( chksum_lo );

		chksum_hi=(unsigned char)(chksum>>8);		// send hi byte of chksum
//		outportb(DATA1,chksum_hi);
//		while ( !(inportb(LSR1) & 0x20)  ) {;}		// wait for char to transmit
		f_putchar( chksum_hi );

		printf("Sent packet %.12s: #%5u, length: %0.2x%0.2x checksum: %0.2x%0.2x\n", FILENAME, packet_no,
					(int)filelen_hi, (int)filelen_lo, (int)chksum_hi, (int)chksum_lo );

		chksum=0;
		filelen=0;
		headerlen=0;

		// build output file
		// use ACKs as place holders for NULL and file length
		sprintf( outfile, "%c%s%c%c%c", ACK,FILENAME2,ACK,ACK,ACK );
		headerlen=strlen(outfile);		// header length

		strcat(outfile, "<body>");		// start HTML

		time(&sec_now);					// create ascii time/date stamp
		sprintf(tmp,"<P>The time is %.24s<p>This is packet #%u<P>",ctime(&sec_now), packet_no );
		strcat( outfile, tmp);

		strcat( outfile, "</body>");	  	// end HTML

		filelen=strlen(outfile);          	// get length of file
		filelen_hi=(unsigned char)((filelen-headerlen)>>8);		// make file length in 2 ascii chars
		filelen_lo=(unsigned char)((filelen-headerlen)&0xFF);

		bufp=strchr(outfile+1,ACK);	 	// have packet length, fill in place holders

		*bufp = NULL;					// put NULL into packet header
		*(bufp+1)=filelen_lo;			// plug file length into packet
		*(bufp+2)=filelen_hi;

		for (i=0; i < filelen; i++) {				// send file to COM port
			chksum+=(unsigned char)outfile[i];      // add data to checksum
//			outportb(DATA1,outfile[i]);
//			while ( !(inportb(LSR1) & 0x20)  ) {;}	// wait for char to transmit
			f_putchar(outfile[i]);

		}
		chksum = (unsigned int)(0x10000L - (long)chksum); 	// convert chksum to 2's complemnet

		chksum_lo=(unsigned char)(chksum&0xFF);		// send low byte of chksum
//		outportb(DATA1,chksum_lo);
//		while ( !(inportb(LSR1) & 0x20)  ) {;}		// wait for char to transmit
		f_putchar(chksum_lo);

		chksum_hi=(unsigned char)(chksum>>8);		// send hi byte of chksum
//		outportb(DATA1,chksum_hi);
//		while ( !(inportb(LSR1) & 0x20)  ) {;}		// wait for char to transmit
		f_putchar(chksum_hi);

		printf("Sent packet %.12s: #%5u, length: %0.2x%0.2x checksum: %0.2x%0.2x\n", FILENAME2, packet_no,
					(int)filelen_hi, (int)filelen_lo, (int)chksum_hi, (int)chksum_lo );
	}
return(0);
}




