/* * * * * * * * * * * * *
NOTE: This is an interrupt service routine. You can NOT compile this program with Test Stack Overflow
turned on and get an executable file which will operate correctly.
Due to the nature of this function the formula used to compute the number of paragraphs may
not necessarily work in all cases.  Use with care!
Terminate Stay Resident (TSR) programs are complex and no other support for them is provided.
Refer to the MS-DOS technical documentation for more information.
 * * * * * * * * * * * * */

#include <dos.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define FALSE 0
#define TRUE !(FALSE)

#define VERSION 0x10

#define INTR 0x31				// The parse table interrupt

#define ON "<img src=\"on.gif\" witdth=20 height=20 hspace=10>"
#define OFF "<img src=\"off.gif\" witdth=20 height=20 hspace=10>"

#ifdef __cplusplus
	#define __CPPARGS ...
#else
	#define __CPPARGS
#endif

/* reduce heaplength and stacklength to make a smaller program in memory */
extern unsigned _heaplen = 2048;
extern unsigned _stklen  = 1024;

extern int adconvert(int ad);

void interrupt (*oldirq)(__CPPARGS);
void interrupt (*oldisr)(__CPPARGS);

char t_entries=4;
char *entry[5];
char *ptr;
char *stuff0 = "0000000000";
char *stuff1 = "1111111111";
char *stuff2 = "2222222222";
char stuff3[512];
char stuff4[32];

// int 31 vars
static int i=0;
static unsigned int j;

void interrupt handler( unsigned bp, unsigned di, unsigned si,
						unsigned ds, unsigned es, unsigned dx,
						unsigned cx, unsigned bx, unsigned ax,
						unsigned ip, unsigned cs, unsigned flags )
{
// insert signature and version
asm {
	jmp skip
	dw 0x055AA
	db VERSION
skip:
}

ax=_AX;
switch ( ax & 0xFF00 ) {
	case 0x00:
		ax=(unsigned)t_entries;
		bx=0;
		cx=(unsigned)_DS;
		break;

	case 0x100:
		ax &= 0xff;
		if ( ax >= t_entries ) {
			ax=bx=0;
			break;
		}

		ptr=entry[ax];

		switch (ax) {
			case 0:
				i = atoi(ptr);
				outportb(0x61,(char)i);

				itoa( ++i, ptr, 10);
				break;

			case 3:
				i=inportb(0x60);
				*(ptr)='\0';
				for (j=0x80; j>0; j=j>>1) {
					if (i & j) {
						strcat(ptr,ON);
					}
					else {
						strcat(ptr,OFF);
					}
				}
				break;

			case 4:
				break;

			default:
				j=adconvert( (int)(ax-1) );

				itoa( (int)j, ptr, 10);
				j=strlen(ptr);
				ptr[j] = '\0';

//				ptr[j] = ptr[j-1];
//				ptr[j-1] = '.';
//				ptr[j+1] = '\0';
		}

		cx= (unsigned)_DS;
		bx= (unsigned)entry[ax];
		ax= (unsigned)( strlen(ptr) );
	}

	return;
}


int main(void)
{
	entry[0]=stuff0;	entry[1]=stuff1;
	entry[2]=stuff2;    entry[3]=stuff3;
//	entry[4]=stuff4;

	oldisr= getvect(INTR);		// get the address of the current handler

	disable();						// no ints while changing things
	setvect(INTR, handler);			// install the new interrupt handler
	enable();						// ints ok

	puts("PARSE TABLE Version 1.0" );
	puts("Copyright JK microsystems, 1998");
	puts("INT 31 driver installed.");
	putc('\n',stdout);

/***
_psp is the starting address of the program in memory.  The top of the stack is the end.
Using _SS and _SP together we can get the end of the stack.  You may want to allow a bit
of safety space to insure that enough room is being allocated ie:
   (_SS + ((_SP + safety space)/16) - _psp)
***/
//	printf("%x %x %x %x\n", _SS, _SP, _psp,(_SS + ((_SP+512)/16) - _psp));
	keep(0, (_SS + ((_SP+512)/16) - _psp));
	return 0;
}

