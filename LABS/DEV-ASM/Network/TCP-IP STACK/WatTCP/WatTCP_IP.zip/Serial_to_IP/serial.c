/*
 *  Ethernet Modem
 *
 *  Kelly Hall
 *  09 APR 99
 *
 *  serial.c
 *    routines to mess with the serial port(s)
 *
 */

#include "em.h"

// abbreviations for UART registers
#define DLL  (BASE_ADDR)
#define DLH  (BASE_ADDR+1)
#define TBR  (BASE_ADDR)
#define RBR  (BASE_ADDR)
#define LCR  (BASE_ADDR+3)
#define LSR  (BASE_ADDR+5)
#define IER  (BASE_ADDR+1)
#define IIR  (BASE_ADDR+2)
#define MCR  (BASE_ADDR+4)
#define MSR  (BASE_ADDR+6)
#define SCR  (BASE_ADDR+7)

// uFlash UART clock frequency
#define BCLKIN  1843200L

// local data
RECV_BUFFER com1_recv;                // receive buffer
SEND_BUFFER com1_send;                // send buffer
void interrupt (*oldcom1)(void);      // holds old ISR for COM1
int rts, ints;


void xmit(void) {
	unsigned char lsr = inportb(LSR);
	if( ! (lsr & 0x40) ) return;
	if( com1_send.hi != com1_send.lo ) {
		disable();
		outportb(TBR, com1_send.buff[com1_send.lo++]);
		if( com1_send.lo >= COM1_SEND_BUFF ) com1_send.lo = 0;
		enable();
	}
	return;
}


// ISR for COM1
static unsigned char isr, lsr, msr;
void interrupt newcom1(void) {
	disable();
	isr = inportb(IIR);      // why did we get called?

	while( !(isr&0x01) ) {
		if( isr&0x02 ) {
			// TX buffer empty
			xmit();
		} else if( isr&0x04 ) {
			// RX buffer full
			lsr = inportb(LSR);
			if( lsr & 0x01 ) {
				com1_recv.buff[com1_recv.hi++] = inportb(RBR);
				if( com1_recv.hi >= COM1_RECV_BUFF ) com1_recv.hi = 0;
			}
		} else if( isr&0x06 ) {
			// line status
			lsr = inportb(LSR);
		} else {
			// modem status registers
			msr = inportb(MSR);
		}

		isr = inportb(IIR);
	}
	enable();
	outportb(0x20,0x20);     // reset PIC
	return;
}


void serial_init(void) {
	// initialize COM1 based on the CONFIG
	unsigned int divisor;
	unsigned char divlo, divhi;
	unsigned char db, sb, par;
	unsigned char temp;

	puts("serial_init():");

	// setup baud rate
	outportb(LCR, 0x80);	// set bit 7 of LCR to access divisor latch registers

	// write divisor values (lo and hi)
	divisor = (unsigned int)(BCLKIN / (long)(16L * (long)global_config.baud));
	divlo = (unsigned char)(divisor % 256);
	divhi = (unsigned char)(divisor / 256);
	outportb(DLL, divlo);
	outportb(DLH, divhi);

	// setup data bits, stop bits, parity; set bit 7 of LCR
	switch( global_config.databits ) {
		case 5 : db = 0x00;  break;
		case 6 : db = 0x01;  break;
		case 7 : db = 0x02;  break;
		case 8 : db = 0x03;  break;
		default : db = 0x03; break;
	}
	temp = (db);
	switch( global_config.stopbits ) {
		case 1 : sb = 0x00;  break;
		case 2 : sb = 0x01;  break;
		default : sb = 0x00; break;
	}
	temp |= (sb << 2);
	switch( global_config.parity ) {
		case none  : par = 0x00;  break;
		case even  : par = 0x03;  break;
		case odd   : par = 0x01;  break;
		case mark  : par = 0x07;  break;
		case space : par = 0x05;  break;
		default : par = 0x00;  break;
	}
	temp |= (par << 3);
	outportb(LCR, temp);

	// dork with RTS, DTR
	outportb(MCR, 0x03);
	rts = 1;

	// initialize the buffers
	com1_recv.lo = 0;
	com1_recv.hi = 0;
	com1_send.lo = 0;
	com1_send.hi = 0;

	// clean up COM1
	while( (inportb(LSR) & 0x01) ) {
		inportb(RBR);
		printf(".");
	}

	// install the COM1 isr
	outportb(IER, 0x0F);   // enable RX interrupt
	outportb(SCR, 0x0F);   // save a copy of IER to SCR
	ints = 15;

	disable();
	oldcom1 = getvect(IRQ_NUM+8);
	setvect(IRQ_NUM+8, newcom1);

	outportb(0x21, inportb(0x21)&~(IRQ_MASK));
	enable();
}


// public function to shutdown the serial routines
void serial_shutdown(void) {
	puts("serial_shutdown():");

	// install the old COM1 isr
	disable();
	outportb(IER, 0x00);
	outportb(SCR, 0x00);  // save a copy of IER to SCR
	ints = 0;
	setvect(IRQ_NUM+8, oldcom1);
	outportb(0x21, inportb(0x21)|IRQ_MASK);
	enable();
}


// private function to return the available size of the send buffer
int send_room_left(void) {
	int size;
	disable();
	size = com1_send.lo - com1_send.hi - 1;
	if( size < 0 ) {
		size += COM1_SEND_BUFF;
	}
	enable();
	return size;
}


// public function for adding characters to the send buffer
int send_com1_buff( BUFFER *b ) {
	int i, len;

#ifdef DUMPSEND
	putsl("to COM1: ");
	for(i = 0; i < b->len; putch(b->buff[i]), i++) ;
#endif

	len = b->len;
	if( send_room_left() >= len ) {
		disable();
		for(i = 0; i < len; i++) {
			com1_send.buff[com1_send.hi++] = b->buff[i];
			if( com1_send.hi >= COM1_SEND_BUFF ) {
				puts("send_com1_buff: rollover");
				com1_send.hi = 0;
			}
		}
		enable();
		xmit();
		if( global_data.verbose == true ) {
			printf("  sent buffer %d, length %d on COM1\n", b->num, b->len);
			printf("send_com1_buff freeing buffer %d\n", b->num);
		}
		free_buff(b);
		return 0;
	} else {
		puts("send_com1_buff(): not enough room in send buffer");
		return -1;
	}
}


// public function for sending one character
int send_com1_char( char ch ) {
	if( send_room_left() > 0 ) {
		disable();
		com1_send.buff[com1_send.hi++] = ch;
		if( com1_send.hi == COM1_SEND_BUFF ) com1_send.hi = 0;
		enable();
		xmit();
		return 1;
	} else {
		puts("send_com1_char(): send buffer overflow");
		return -1;
	}
}


// public function for polled sending on COM1
int polled_send(void) {
	unsigned char foo;
	int retval;
	disable();
	foo = inportb(LSR);
	if( foo & 0x20 ) {
		if( com1_send.lo == com1_send.hi ) {
			retval = -1;
		} else {
			outportb(TBR, com1_send.buff[com1_send.lo]);
			com1_send.lo = (com1_send.lo + 1) % COM1_SEND_BUFF;
			retval = 0;
		}
	}
	enable();
	return retval;
}


// public function for printing status of COM1 buffers
void print_buff_stats(void) {
	printf("com1 send buffer: lo = %d hi = %d\n", com1_send.lo, com1_send.hi);
	printf("com1 recv buffer: lo = %d hi = %d\n", com1_recv.lo, com1_recv.hi);
}


// public function for checking if com1 has characters waiting
int recv_com1_avail(void) {
	int foo;
	disable();
	foo = com1_recv.hi - com1_recv.lo;
	if( foo < 0 ) {
		foo = foo + COM1_RECV_BUFF;
	}
	enable();
	return foo;
}


// public function to return the first received char on COM1
char recv_com1_char(void) {
	char foo;
	if( recv_com1_avail() ) {
		disable();
		foo = com1_recv.buff[com1_recv.lo++];
		if( com1_recv.lo >= COM1_RECV_BUFF ) com1_recv.lo = 0;
		enable();
		outportb(MCR, 0x03);  // set RTS and DTR
		rts = 1;
		return foo;
	}
	return 0;
}


// public function for receiving a buff of chars from COM1
BUFFER *recv_com1_buff(unsigned int len) {
	BUFFER *b;
	int size = recv_com1_avail();

	if( global_data.verbose == true ) {
		puts("recv_com1_buff allocating a buffer");
	}
	b = alloc_buff();

	if( size ) {
		if( size > len ) {
			size = len;
		}
		disable();
		for(len = 0; len < size; len++) {
			b->buff[len] = com1_recv.buff[com1_recv.lo++];
			if( com1_recv.lo >= COM1_RECV_BUFF ) com1_recv.lo = 0;
		}
		enable();
		b->len = size;
		outportb(MCR, 0x03);  // set RTS and DTR
		rts = 1;
	}
	return b;
}


void serial_state(void) {
	printf("serial receive: buff.lo = %d  buff.hi = %d\n", com1_recv.lo, com1_recv.hi);
	printf("serial send:    buff.lo = %d  buff.hi = %d\n", com1_send.lo, com1_send.hi);
	printf("RTS = %d  MSR = %02X  LSR = %02X\n", rts, inportb(MSR), inportb(LSR));
	putsl("COM1 Interupts ");
	switch(ints) {
		case 0: puts("disabled");                   break;
		case 1: puts("on receive");                 break;
		case 2: puts("on send");                    break;
		case 3: puts("on both send and receive");   break;
		default: puts("unknown");                   break;
	}
	printf("real IER value is %02X\n", inportb(SCR));
}


void serial_sanity(void) {
	int foo;
	// make sure TX interrupts are enabled when our buffer isn't empty
	if( (inportb(SCR) != 0x03) &&                   // TX interrupts are off
			(inportb(LSR) & 0x60) ) {
		disable();
		foo = (com1_send.lo != com1_send.hi);
		enable();
		if( foo ) xmit();
	}
}
