// abbreviations for COM1 UART registers
#define DLL  (BASE_ADDR)
#define DLH  (BASE_ADDR+1)
#define TBR  (BASE_ADDR)
#define RBR  (BASE_ADDR)
#define LCR  (BASE_ADDR+3)
#define LSR  (BASE_ADDR+5)
#define IER  (BASE_ADDR+1)
#define IIR  (BASE_ADDR+2)
#define MCR  (BASE_ADDR+4)
#define MSR  (BASE_ADDR+6)
#define SCR  (BASE_ADDR+7)

void xmit(void) {
unsigned char lsr = inportb(LSR);
  if( ! (lsr & 0x40) ) return;     // if the TX buffer isn't empty, return
  if( com1_send.hi != com1_send.lo ) {  // anything in our send buffer?
    disable();                          // disable ints
    outportb(TBR, com1_send.buff[com1_send.lo++]);
    if( com1_send.lo >= COM1_SEND_BUFF ) com1_send.lo = 0;
    enable();                           // enable ints
  }
  return;
}


// ISR for COM1
static unsigned char isr, lsr, msr;
void interrupt newcom1(void) {
  disable();               // disable further interrupts
  isr = inportb(IIR);      // why did we get called?

  while( !(isr&0x01) ) {   // repeat as long as there are things to do
    if( isr&0x02 ) {         // TX buffer empty
      xmit();                  // write a character to the TX buffer
    } else if( isr&0x04 ) {  // RX buffer full
      lsr = inportb(LSR);      // read buffer full?
      if( lsr & 0x01 ) {       // yes - read character into buffer
        com1_recv.buff[com1_recv.hi++] = inportb(RBR);
        if( com1_recv.hi >= COM1_RECV_BUFF ) com1_recv.hi = 0;
      }
    } else if( isr&0x06 ) {  // line status
      lsr = inportb(LSR);      // read this register to clear the interrupt
    } else {                 // modem status registers
      msr = inportb(MSR);      // read this register to clear the interrupt
    }

    isr = inportb(IIR);      // update the isr value for the while() test
  }
  enable();                // re-enable interrupts
  outportb(0x20,0x20);     // reset PIC
  return;
}
