/*
 *  Ethernet Modem
 *
 *  Kelly Hall
 *  08 APR 99
 *
 *  console.c
 *    routines to deal with the console port
 *
 */

#include "em.h"

// local function prototypes
void console_parse(void);
void console_command(char *);
void console_directive(char *, char*);
void command_help(void);


// local data
CONSOLE console;
char command[CONSOLE_BUFF];


// functions
void console_init(void) {
	extern int _directvideo;
	puts("init_console():");
	console.len = 0;
	_directvideo = 0;
}


void console_tick(void) {
	char ch;

	WHERE('K');

	// read console data if available
	while( kbhit() ) {
		WHERE('k');
		ch = getch();                            // fetch a character - no echo
		if( ch == '\b' ) {                       // backspace
			console.len = console.len - 1;            // back up pointer
			if( console.len < 0 ) {                   // stay sane
				console.len = 0;
			}
			console.buff[console.len]='\0';
			printf("\b \r%s",console.buff);   // put backspace on console
		} else if( ch == '\r' ) {                // carriage return
			putch(ch);                                // echo it
			console.buff[ console.len ] = '\0';       // null terminate
			strcpy(command, console.buff);            // get the command
			console_parse();                          // deal with the command
			console.len = 0;                          // reset the input buffer
		} else {                                 // normal
			putch(ch);                                // echo it
			console.buff[ console.len++ ] = ch;       // add it to buffer
			if( console.len >= CONSOLE_BUFF ) {
				puts("console_tick(): overflowed console buffer");
				console.len = 0;
			}
		}
	}
	WHERE(' ');
}


void console_parse(void) {
	char *tok[TOKENS_PER_COMMAND];
	int  ntokens;
	char delimstr[] = {' ', '\t', '\r','\n', '='};

	// tokenize the command
	strupr(command);                                  // force to uppercase
	ntokens = 0;
	tok[ntokens] = strtok(command, delimstr);
	while( (tok[ntokens] != NULL) && (ntokens < TOKENS_PER_COMMAND) ) {
		ntokens += 1;
		tok[ntokens] = strtok(NULL, delimstr);
	}

	if( ntokens >= TOKENS_PER_COMMAND ) {
		puts("console_parse(): too many tokens!");
		return;
	}

	if( ntokens == 0 ) {
		;
	} else if( ntokens == 1 ) {
		puts("");
		console_command(tok[0]);
	} else if( ntokens == 2 ) {
		puts("");
		console_directive(tok[0], tok[1]);
	} else {
		puts("");
		puts("console_parse(): too many tokens");
	}

}


// table of commands
#define COM_HANGUP      "HANGUP"
#define COM_CONNECT     "CONNECT"
#define COM_SHOW        "SHOW"
#define COM_SAVE        "SAVE"
#define COM_STATUS      "STATUS"
#define COM_REBOOT      "REBOOT"
#define COM_EXIT        "EXIT"
#define COM_HELP        "HELP"
#define COM_EGG1        "YYYY"
#define COM_EGG2        "XYZZY"
#define COM_VERBOSE     "VERBOSE"

#define is_it( x )      if(!strcmp(com,x))

void console_command(char *com) {
	is_it( COM_HANGUP ) {
		ether_disconnect();
		global_data.command = nop;
		puts("ok");
	}	else is_it( COM_CONNECT ) {
		ether_connect();
		global_data.command = nop;
		puts("ok");
	} else is_it( COM_SHOW ) {
		print_config(stdout);
		puts("ok");
		global_data.command = nop;
	}	else is_it( COM_SAVE ) {
		save_config();
		puts("ok");
		global_data.command = nop;
	} else is_it( COM_STATUS ) {
		putsl("verbose mode is ");
		switch(global_data.verbose) {
			case true:   puts("on");       break;
			case false:  puts("off");      break;
			default:     puts("unknown");
		}
		serial_state();
		putsl("The network is ");
		switch(global_data.network) {
			case up:     puts("up");        break;
			case down:   puts("down");      break;
			case listen: puts("listening"); break;
			default:     puts("unknown");
		}
		switch(global_data.connect_dir) {
			case we_did:   puts("we initiated the current connection");         break;
			case they_did: puts("other host initiated the current connection"); break;
			case no_conn:  puts("no connection at present");                    break;
			default:       puts("unknown connection direction");
		}
		switch(global_data.bad_resolve) {
			case true:   puts("target_name could not be resolved"); break;
			case false:  puts("target_name successfully resolved"); break;
			default:     puts("target_name resolution state unknown");
		}
		buff_stats();
		printf("Waterloo says: %s\n", ether_state());
		puts("ok");
		global_data.command = nop;
	}	else is_it( COM_REBOOT ) {
		puts("not yet");
		global_data.command = nop;
	} else is_it( COM_EXIT ) {
		puts("ok");
		global_data.command = bye;
	} else is_it( COM_HELP ) {
		command_help();
		puts("ok");
		global_data.command = nop;
	} else is_it( COM_EGG1 ) {
		puts("The quick brown fox jumped over the lazy dog");
		global_data.command = nop;
	} else is_it( COM_EGG2 ) {
		puts("nothing happens");
		global_data.command = nop;
	} else if( com[ strlen(com)-1 ] == '?' ) {
		global_data.unknown_directive = 0;
		com[ strlen(com)-1 ] = '\0';
		config_query(com);
		if( global_data.unknown_directive ) {
			putsl("console_directive(): unknown directive '");
			putsl(com);
			puts("'");
			global_data.unknown_directive = 0;
		}
		global_data.command = nop;
	} else is_it( COM_VERBOSE ) {
			if( global_data.verbose == false ) {
				puts("verbose mode");
				global_data.verbose = true;
			} else {
				puts("quiet mode");
				global_data.verbose = false;
			}
	} else {
		putsl("unknown command '");
		putsl(com);
		puts("'");
		global_data.command = nop;
	}
}


void command_help(void) {
	puts("Ethernet Modem commands:");
	puts("  hangup  - modem breaks TCP connection (if established)");
	puts("  connect - modem establishes TCP connection (if offline)");
	puts("  show    - modem prints current configuration data");
	puts("  save    - modem writes configuration data to Flash");
	puts("  status  - describe the state of the modem");
	puts("  reboot  - modem resets as if power was cycled");
	puts("  verbose - toggles informative messages");
	puts("  exit    - modem exits to DOS");
	puts("  help    - this explanatory information");
	puts("  <variable> = <data>   - set the value of a variable");
	puts("  <variable>?           - query the value of a variable");
}


void console_directive(char *name, char *value) {
	// for now, do nothing
	global_data.unknown_directive = 0;
	global_data.reset = 0;
	my_init(name,value);
	if( global_data.unknown_directive ) {
		putsl("console_directive(): unknown directive '");
		putsl(name);
		puts("'");
		global_data.unknown_directive = 0;
	}
	if( global_data.reset ) {
		if( global_data.network == up ) {
			ether_disconnect();
		}
		ether_init();
	}
}
