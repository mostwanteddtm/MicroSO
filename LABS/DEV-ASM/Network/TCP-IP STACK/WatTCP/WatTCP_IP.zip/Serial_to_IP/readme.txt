EM is a simple serial to ethernet conversion example. 

EM is intended to connect a serial device on COM1 to the
ethernet. EM can act as a TCP/IP client or a server.

EM uses watTCP and requires a valid WATTCP.CFG file.
EM also uses EM.CFG to store its configuration parameters.
to write a default configuration file, start EM and 
type SAVE to write the current configuration to disk.

commands:
  hangup  - modem breaks TCP connection (if established)
  connect - modem establishes TCP connection (if offline)
  show    - modem prints current configuration data
  save    - modem writes configuration data to Flash
  status  - describe the state of the modem
  reboot  - modem resets as if power was cycled
  verbose - toggles informative messages
  exit    - modem exits to DOS
  help    - this explanatory information
  <variable> = <data>   - set the value of a variable
  <variable>?           - query the value of a variable


By default, EM will listen on port 2222 for a connection.

Use the following example to prove the system and 
investigate the posibilities of EM.

Equipment:
	JKmicrosystems controller with ethernet (uFlash, LogicFlex, etc.)
	PC with 2 serial ports and ethernet
	Console serial cable
	Null-Modem serial cable
	Hyperterm (or equivilant) 
	Telnet
	ethernet cables/hub
	
Hardware Configuration:
	connect COM2/Console port to the PC using the console cable
	connect COM1 to the PC w/ the null-modem cable.
	connect the ethernet to the PC using a hub or x-over cable

PC Software Configuration:
	start Hyperterminal configured for 9600/8/1/n on COM1
	start Hyperterminal configured for 9600/8/1/n on COM2
	start telnet
		
Controller Software Configuration:
	upload EM.EXE 
	load the network driver
	configure the wattcp.cfg file, see sample below:
		B:\>type wattcp.cfg
		my_ip=10.10.5.5
		gateway=
		netmask=255.0.0.0

Run EM, you should see the following on the console:
	B:\>em
	main():
	init_config():
	serial_init():
	init_console():
	packet_init():
	enter a command:
	going into listen mode
	listening

type SHOW
	target_name = 127.0.0.1
	target_port = 9
	local_port = 2222
	connect = demand
	dto_source = 15
	dto_target = 15
	baud = 9600
	parity = none
	stopbits = 1
	databits = 8
	packet_timeout = 10
	packet_length = 15
	packet_end0 = -1
	packet_end1 = -1
	allow_anyone = yes
	drop_sentinel = yes
	ok

at this point you should be able to connect to the Controller using
telnet. open a connection to the IP address and port 2222.
from windows: use connect-remote system, then specify the
address and port.

EM will respond:
	got a connection

at this point there is an open communication channel between the
TELNET session and the COM1 hyperterminal session. characters
typed on the TELNET console will be displayed on the hyperterminal,
and vise-versa. if there is no activity within the specified timeout
period (15 second default) EM will drop the ethernet connection.

You can change any of the EM parameters by typing the parameter name
the '=' and the new value. For example:
	dto_source = 60

to save the changes to the config file, type SAVE.

to close EM and return to DOS, type EXIT.


This is a breif overview, for more information refer to the
source files distributed with EM.

-----
28FEB03 -EW