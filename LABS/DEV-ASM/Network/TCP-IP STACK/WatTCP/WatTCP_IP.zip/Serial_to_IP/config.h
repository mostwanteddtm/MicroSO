/*
 *  Ethernet Modem
 *
 *  Kelly Hall
 *  08 APR 99
 *
 *  config.h
 *    routines to read, write and modify the configuration data
 *
 */


// public fuctions
extern void init_config(void);
extern void my_init(char *, char *); 
extern void default_config(void);
extern void print_config(FILE *);
extern int  save_config(void);
extern void config_query(char *);


