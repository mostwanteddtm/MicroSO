/*
 *  Ethernet Modem
 *
 *  Kelly Hall
 *  19 APR 99
 *
 *  ether.h
 *    routines to send and receive packets on the Ethernet
 *
 */


// configurable values
#define CONNECT_TIMEOUT  sock_delay


// public types


// public functions
extern void    ether_init(void);
extern void    ether_tick(void);
extern void    ether_shutdown(void);
extern void    ether_send_buff(BUFFER *);
extern BUFFER *ether_recv_buff(void);
extern int     ether_connect(void);
extern int     ether_disconnect(void);
extern char   *ether_state(void);
extern void    ether_listen(void);
extern void    ether_nolisten(void);
