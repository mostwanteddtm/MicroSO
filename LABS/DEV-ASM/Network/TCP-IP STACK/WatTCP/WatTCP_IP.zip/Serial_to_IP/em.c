/*
 *  Ethernet Modem
 *
 *  Kelly Hall
 *  08 APR 99
 *
 *  em.c
 *    main()
 *
 */

#include "em.h"

//  allocate global data structures
CONFIG global_config;
GLOBAL global_data;

FILE *debugfile;


int main(void) {
	BUFFER *rrr, *sss;
	int dupl;

	int exit_loop = 0;

	puts("main():");

	init_config();

	// wait for keypress and dump the buffer
	puts("enter a command:");
	do {
		WHERE('@ ');

#ifdef WHERE
		fflush(debugfile);
		dupl = dup(fileno(debugfile));
		close(dupl);
#endif

		ether_tick();
		rrr = packet_tick();
		sss = ether_recv_buff();

		tcp_tick(NULL);

		if( sss && (sss->len) ) {
			WHERE('S');
			send_com1_buff(sss);
			WHERE(' ');
		}

		tcp_tick(NULL);

		if( rrr && (rrr->len) ) {
			WHERE('R');
			ether_send_buff(rrr);
			WHERE(' ');
		}

		tcp_tick(NULL);

		// check for console input
		console_tick();

		tcp_tick(NULL);

		switch( global_data.command ) {
			case nop:                          // do nothing
					break;

			case bye:                          // user wants out
					exit_loop = 1;
					break;

			default:                           // how'd this happen?
					puts("main(): unknown command");
					global_data.command = nop;
					break;
		}

		tcp_tick(NULL);

		serial_sanity();
		
		WHERE('~ ');
	} while( !exit_loop );

	// now shut things down
	serial_shutdown();
	packet_shutdown();

	return 0;
}


// a local version of puts() without the trailing newline
void putsl(const char *s) {
	while( *s ) {
		putch(*s);
		s++;
	}
}
