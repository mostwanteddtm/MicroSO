/*
 *  Ethernet Modem
 *
 *  Kelly Hall
 *  19 APR 99
 *
 *  ether.c
 *    routines to send and receive packets on the Ethernet
 *
 */

#include "em.h"

// local data
tcp_Socket s;
longword destaddr;
char desthost[TARGET_NAME_SIZE];


// code

void ether_init(void) {
	global_data.network = down;

	strcpy(desthost, global_config.target_name);
	destaddr = resolve(desthost);
	if( !destaddr ) {
		global_data.bad_resolve = true;
		strcpy(desthost, "");
		puts("ether_init(): could not resolve hostname");
	} else {
		global_data.bad_resolve = false;
	}
}


void ether_shutdown(void) {
	;
}


// local vars for ether_tick
static struct sockaddr block;
static int blen;
static char cb[25];

void ether_tick(void) {
	tcp_tick(NULL);

	WHERE('E');
	if( global_data.network == down ) {           // no connection
		WHERE('d');
		// if we should be up, connect
		if( global_config.connect == always ) {
			ether_connect();
		}
		// listen if appropriate
		if( global_config.connect == demand ) {
			puts("going into listen mode");
			ether_listen();
		}
	} else if( global_data.network == up ) {      // connection
		WHERE('u');
		// check for a timeout if connections are transient
		if( global_config.connect != always ) {
			if( chk_timeout(global_data.timeout) ) {
				if(global_data.verbose == true) {
					puts("timeout occurred");
				}
				ether_disconnect();
			}
		}
		// hang up if we've been cut off
		if( !sock_established(&s) ) {
			if(global_data.verbose == true) {
				puts("remote host dropped connection");
			}
			ether_disconnect();
		}
	} else if( global_data.network == listen ) {  // listening
		WHERE('l');
		// if we've moved into IGNORE, stop listening
		if( global_config.connect == ignore ) {
			ether_nolisten();
		}
		// check for a completed connection
		if( sock_established(&s) ) {
			puts("got a connection");
			tcp_tick(&s);
			// is this host allowed to talk?
			if( global_config.allow_anyone == no ) {
				blen = sizeof( struct sockaddr );
				getpeername(&s, &block, &blen);
				if( blen ) {
					if( block.s_ip != destaddr ) {
						inet_ntoa(cb, block.s_ip);
						printf("%s is not allowed to talk\n", cb);
						ether_disconnect();
					}
				} else {
					puts("getpeername failed");
				}
			}
			global_data.timeout = set_timeout(global_config.dto_target);
			global_data.network = up;
			global_data.connect_dir = they_did;
		}
	} else {
		WHERE('?');
		if( global_data.verbose ) {
			puts("ether_tick(): unknown network state");
		}
		ether_disconnect();
	}
	WHERE(' ');
}


void ether_send_buff(BUFFER *b) {
	int actual;

#ifdef DUMPSEND
	int i;
	puts("to ether:");
	for(i = 0; i < b->len; putch(b->buff[i]),i++) ;
	puts("");
#endif

	tcp_tick(NULL);

	WHERE('~');
	if( global_data.network != up ) {
		WHERE('c');
		ether_connect();
	}

	WHERE('w');
	actual = sock_write(&s, b->buff, b->len);

	if( actual != b->len ) {
		printf("ether_sent_buff: tried to write %d but only did %d\n", b->len, actual);
	}
	if( global_data.verbose == true ) {
		printf("  sent buffer %d with length %d on ether1\n", b->num, b->len);
	}
	free_buff(b);

	WHERE('x');
	if( global_config.connect == demand ) {
		WHERE('d');
		if( global_data.connect_dir == we_did ) {
			global_data.timeout = set_timeout(global_config.dto_source);
		} else {
			global_data.timeout = set_timeout(global_config.dto_target);
		}
		WHERE('b');
	}
	WHERE(' ');
}


BUFFER *ether_recv_buff(void) {
	int len, actual;
	BUFFER *tb;

	WHERE('>');

	tcp_tick(&s);

	if( global_data.network != up ) {
		WHERE('d');
		WHERE(' ');
		return NULL;
	}

	len = sock_dataready(&s);
	if( len < 1 ) {
		WHERE('l');
		WHERE(' ');
		return NULL;
	}

	if( global_data.verbose == true ) {
		puts("ether_recv_buff allocating a buffer");
	}
	tb = alloc_buff();

	actual = sock_fastread(&s, tb->buff, len);
	tb->len = actual;
	if( actual != len ) {
		printf("ether_recv_buff: wanted to read %d and got %d\n", len, actual);
	}

#ifdef DUMPRECV
	puts("from ether:");
	for(len = 0; len < tb->len; len++)  putch(tb->buff[len]);
	puts("");
#endif

	if( global_config.connect == demand ) {
		WHERE('c');
		if( global_data.connect_dir == we_did ) {
			global_data.timeout = set_timeout(global_config.dto_source);
		} else {
			global_data.timeout = set_timeout(global_config.dto_target);
		}
	}

	WHERE(' ');

	return tb;
}


int ether_connect(void) {
	int status;

	puts("trying to connect");

	if( global_data.bad_resolve == true ) {
		return 0;
	}
	if( global_data.network == up ) {
		return 0;
	}
	if( global_data.network == listen ) {
		ether_nolisten();
	}

	if( !tcp_open(&s,
								global_config.local_port,
								destaddr,
								global_config.target_port,
								NULL) ) {
		return -1;
	}

	sock_wait_established(&s, CONNECT_TIMEOUT, NULL, &status);

	global_data.network = up;
	global_data.connect_dir = we_did;
	return 0;

	sock_err:
	switch (status) {
		case 1 : puts("ether_connect(): sockerr (timeout)"); break;
		case -1: puts("ether_connect(): sockerr (-1)");
	}
	return -1;

}


int ether_disconnect(void) {
	longword to;

	puts("trying to disconnect");

	if( global_data.network == down ) {
		return 0;
	}

	to = set_timeout(sock_delay);
	sock_close(&s);
	while( sock_established(&s) && !chk_timeout(to)) {
		tcp_tick(&s);
	}
	if( chk_timeout(to) ) {
		// timeout on sock close - pretend we worked
		puts("ether_disconnect(): timeout on sock_close()");
		global_data.network = down;
		global_data.connect_dir = no_conn;
		return -1;
	} else {
		global_data.network = down;
		global_data.connect_dir = no_conn;
		return 0;
	}
}


char *ether_state(void) {
	return sockstate(&s);
}


void ether_listen(void) {
	puts("listening");
	tcp_listen(&s, global_config.local_port, 0, 0, NULL, 0);
	global_data.network = listen;
}


void ether_nolisten(void) {
	puts("listening no more");
	sock_close(&s);
	tcp_tick(&s);
	global_data.network = down;
}
