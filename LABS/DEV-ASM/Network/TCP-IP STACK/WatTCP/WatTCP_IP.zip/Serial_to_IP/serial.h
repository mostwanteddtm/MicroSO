/*
 *  Ethernet Modem
 *
 *  Kelly Hall
 *  09 APR 99
 *
 *  serial.h
 *    routines to mess with the serial port(s)
 *
 */


// configurable values

// setup for COM1
#define BASE_ADDR 0x3F8
#define IRQ_NUM   4
#define IRQ_MASK  (1<<IRQ_NUM)

// setup for COM1 buffers
#define COM1_SEND_BUFF  4096
#define COM1_RECV_BUFF  4096


// private types
typedef struct sendbuff_struct {
	byte buff[COM1_SEND_BUFF];
	unsigned int lo;
	unsigned int hi;
} SEND_BUFFER;

typedef struct recvbuff_struct {
	byte buff[COM1_RECV_BUFF];
	unsigned int lo;
	unsigned int hi;
} RECV_BUFFER;


// public functions
extern void serial_init(void);
extern void serial_shutdown(void);
extern int  send_com1_buff(BUFFER*);
extern int  send_com1_char(char);
extern int  polled_send(void);
extern void print_buff_stats(void);
extern int  recv_com1_avail(void);
extern char recv_com1_char(void);
extern BUFFER *recv_com1_buff(unsigned int);
extern void serial_state(void);
extern void serial_sanity(void);

