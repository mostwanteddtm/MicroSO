/*
 *  Ethernet Modem
 *
 *  Kelly Hall
 *  08 APR 99
 *
 *  em.h
 *    #includes everything
 *    defines constants, types
 */


// include everything we need
#include <io.h>
#include <dos.h>
#include <mem.h>
#include <conio.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <tcp.h>


// configurable parameters
#define TARGET_NAME_SIZE  128
#define CONFIG_FILE_NAME  "em.cfg"
#define BUFFERSIZE 1600


// macros
#define WHERE(x)
//#define WHERE(x)   putch(x)
//#define WHERE(x)   fputc(x,debugfile);
#undef DUMPSEND
//#define DUMPSEND
#undef DUMPRECV
//#define DUMPRECV

// global types
enum commands      { nop, bye };
enum ether_status  { up, down, listen };
enum connect_enum  { we_did, they_did, no_conn };
enum truth         { false, true };
enum buffer_state  { in_use, idle };

typedef struct global_struct {
	int               unknown_directive;   // set when we can't identify a directive
	int               unknown_command;     // set when we can't identify a command
	int               reset;               // should we reopen the TCP socket?
	longword          timeout;             // timeout value for dropping connections
	enum commands     command;             // set when the program needs to exit
	enum ether_status network;             // network status (connected or not)
	enum connect_enum connect_dir;         // who initiated the current connection
	enum truth        bad_resolve;         // set if the last DNS resolution failed
	enum truth        verbose;             // should be be chatty?
} GLOBAL;

enum connect_type { demand, always, ignore };
enum parity_type  { none, even, odd, mark, space };
enum yesno_type   { yes, no };

typedef struct config_struct {
	char              target_name[TARGET_NAME_SIZE];
	word              target_port;
	word              local_port;
	enum connect_type connect;
	word							dto_source;
	word              dto_target;
	long int          baud;
	enum parity_type  parity;
	unsigned          stopbits;
	unsigned          databits;
	int               packet_timeout;
	unsigned          packet_length;
	int               packet_end0;
	int               packet_end1;
	enum yesno_type   allow_anyone;
	enum yesno_type   drop_sentinel;
} CONFIG;

typedef struct buffer_struct {
	unsigned int      len;                      // number of characters
	byte              buff[BUFFERSIZE];         // the chars themselves
  int               num;                      // what number is this from the pool
	enum buffer_state state;                    // current state of this buffer
} BUFFER;



#include "config.h"
#include "ether.h"
#include "packet.h"
#include "serial.h"
#include "console.h"


// global data definitions
extern CONFIG global_config;
extern GLOBAL global_data;

extern FILE* debugfile;

// global functions
extern void putsl(const char *);


