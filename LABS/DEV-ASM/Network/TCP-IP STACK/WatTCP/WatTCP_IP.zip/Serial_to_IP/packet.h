/*
 *  Ethernet Modem
 *
 *  Kelly Hall
 *  15 APR 99
 *
 *  packet.h
 *    routines to packet up the serial input buffer
 *
 */

#define NUMBUFFS  10


// public functions
BUFFER *packet_tick(void);
BUFFER *packet_flush(void);
void packet_init(void);
void packet_shutdown(void);
BUFFER *alloc_buff(void);
void free_buff(BUFFER *);
void buff_stats(void);
