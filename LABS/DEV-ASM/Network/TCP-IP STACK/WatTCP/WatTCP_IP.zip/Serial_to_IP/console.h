/*
 *  Ethernet Modem
 *
 *  Kelly Hall
 *  15 APR 99
 *
 *  console.h
 *    routines to deal with the console port
 *
 */


// configurable values

//   size of console input buffer
#define CONSOLE_BUFF 128

//   number of tokens allowed on a command line
#define TOKENS_PER_COMMAND 5


// private types
typedef struct console_struct {
	char           buff[CONSOLE_BUFF];             // buffer
	int            len;                            // number of chars
} CONSOLE;


// public functions
extern void console_init(void);
extern void console_tick(void);