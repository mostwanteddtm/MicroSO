/*
 *  Ethernet Modem
 *
 *  Kelly Hall
 *  08 APR 99
 *
 *  packet.c
 *    routines to packet up the serial input buffer
 *
 */

#include "em.h"


// local data

//   buffers we allocate from
BUFFER buffs[NUMBUFFS];
BUFFER *curr_buff;

//   timeout variable for end-of-packet
longword  timeout;

//   number of matching chars for end-of-packet sentinels
int matches;

//   we need a long, long timeout that should never happen
#define FOREVER 10000


// local function prototypes


// functions
void packet_init(void) {
	int i;
	puts("packet_init():");
	for(i = 0; i < NUMBUFFS; i++) {
		buffs[i].len   = 0;
		buffs[i].state = idle;
		buffs[i].num   = i;
	}
	curr_buff = alloc_buff();

	timeout = set_timeout(FOREVER);
	matches = 0;
}


void packet_shutdown(void) {
	puts("packet_shutdown():");
	if( curr_buff->len != 0 ) {
		printf("discarding %d chars in current buffer\n", curr_buff->len);
	}
	free_buff(curr_buff);
}


BUFFER *packet_tick(void) {
	int n, packed;
	char ch;
	BUFFER *retval;

	WHERE('P');

	packed = 0;
	retval = NULL;

	// see if anything is available on COM1
	n = recv_com1_avail();
	if( n ) {
		WHERE('n');
		ch = recv_com1_char();
		curr_buff->buff[curr_buff->len] = ch;
		curr_buff->len++;
		timeout = set_timeout(global_config.packet_timeout);

		// deal with sentinels
		if( (global_config.packet_end0 != -1) && (matches == 0) ) {
			if( ch == global_config.packet_end0 ) matches++;
		} else if( (global_config.packet_end1 != -1) && (matches == 1) ) {
			if( ch == global_config.packet_end1 ) matches++;
		} else {
			matches = 0;
		}
		if( (matches == 1) && (global_config.packet_end1 == -1) ) {
			packed = 1;
			if( global_config.drop_sentinel == yes ) {
				curr_buff->len -= 1;
			}
		} else if( (matches == 2) && (global_config.packet_end1 != 1) ) {
			packed = 1;
			if( global_config.drop_sentinel == yes ) {
				curr_buff->len -= 2;
			}
		}

		// deal with fixed lengths
		if( curr_buff->len >= global_config.packet_length ) {
			WHERE('a');
			packed = 1;
		} else if( curr_buff->len >= BUFFERSIZE ) {
			WHERE('b');
			packed = 1;
		}
	}

	// now check for timeouts
	if( chk_timeout(timeout) ) {
		WHERE('t');
		packed = 1;
		timeout = set_timeout(FOREVER);
	}

	// can we bundle up a packet?
	if( packed ) {
		WHERE('p');

		if( curr_buff->len <= 0 ) {
			if( global_data.verbose == true ) {
				puts("disregarding end of packet on empty buffer");
			}
		} else {
			retval    = curr_buff;
			curr_buff = alloc_buff();                 // move to next buffer
#ifdef DUMPRECV
	puts("from COM1:");
	for(n = 0; n < retval->len; n++) putch(retval->buff[n]);
	puts("");
#endif
		}
	}

	WHERE(' ');
	return retval;
}


BUFFER *packet_flush(void) {
	BUFFER *retval;
	retval = curr_buff;
	curr_buff = alloc_buff();
	return retval;
}


BUFFER *alloc_buff(void) {
	int i;
	for(i = 0; i < NUMBUFFS; i++) {
		if(buffs[i].state == idle) break;
	}
	if( i == NUMBUFFS ) {
		puts("alloc_buff: all buffers in use! (reusing #0)");
		return &buffs[0];
	} else {
		buffs[i].state = in_use;
		buffs[i].len = 0;
		return &buffs[i];
	}
}


void free_buff(BUFFER *b) {
	b->len = 0;
	b->state = idle;
}


void buff_stats(void) {
	int i, cnt;
	for(i = 0, cnt = 0; i < NUMBUFFS; i++) {
		if( buffs[i].state == in_use ) {
			cnt++;
		}
	}
	printf("Buffers: %d allocated from a pool of %d\n", cnt, NUMBUFFS);
}
