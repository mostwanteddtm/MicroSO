/*
 *  Ethernet Modem
 *
 *  Kelly Hall
 *  08 APR 99
 *
 *  config.c
 *    routines to read, write and modify the configuration data
 *
 */

#include "em.h"

// local function prototypes
void global_init(void);


// shorthand for directive names
#define TARGET_NAME     "TARGET_NAME"
#define TARGET_PORT     "TARGET_PORT"
#define LOCAL_PORT			"LOCAL_PORT"
#define CONNECT         "CONNECT"
#define DTO_SOURCE      "DTO_SOURCE"
#define DTO_TARGET      "DTO_TARGET"
#define BAUD            "BAUD"
#define PARITY          "PARITY"
#define STOPBITS        "STOPBITS"
#define DATABITS        "DATABITS"
#define PACKET_TIMEOUT  "PACKET_TIMEOUT"
#define PACKET_LENGTH   "PACKET_LENGTH"
#define PACKET_END0     "PACKET_END0"
#define PACKET_END1     "PACKET_END1"
#define ALLOW_ANYONE    "ALLOW_ANYONE"
#define DROP_SENTINEL   "DROP_SENTINEL"

// shorthand for directive values
#define PAR_NONE				"NONE"
#define PAR_EVEN        "EVEN"
#define PAR_ODD         "ODD"
#define PAR_MARK        "MARK"
#define PAR_SPACE       "SPACE"

#define CON_DEMAND      "DEMAND"
#define CON_ALWAYS      "ALWAYS"
#define CON_IGNORE      "IGNORE"

#define YESNO_YES       "YES"
#define YESNO_NO        "NO"

// shorthand for comparing names and values
#define is_it( x )      if(!strcmp(name,x))
#define has_it( x )     if(!strcmp(value,x))

void my_init(char *name, char *value) {
	// routine called from WATTCP to review name/value pairs
	// from WATTCP.CFG file

	int temp;
	long int longtemp;

	is_it( TARGET_NAME ) {
		strncpy(global_config.target_name, value, TARGET_NAME_SIZE);
		global_data.reset = 1;
	} else is_it( TARGET_PORT ) {
		global_data.reset = 1;
		global_config.target_port = atoi(value);
	} else is_it( LOCAL_PORT ) {
		global_data.reset = 1;
		global_config.local_port = atoi(value);
	} else is_it( CONNECT ) {
		strupr(value);
		has_it( CON_DEMAND ) {
			global_config.connect = demand;
		} else has_it( CON_ALWAYS ) {
			global_config.connect = always;
		} else has_it( CON_IGNORE ) {
			global_config.connect = ignore;
		} else {
			putsl("my_init(): invalid connection strategy '");
			putsl(value);
			puts("'");
		}
	} else is_it( DTO_SOURCE ) {
		global_config.dto_source = atoi(value);
	} else is_it( DTO_TARGET ) {
		global_config.dto_target = atoi(value);
	} else is_it( BAUD ) {
		longtemp = atol(value);
		// sanity check the baud rate here
		global_config.baud = longtemp;
	} else is_it( PARITY ) {
		strupr(value);
		has_it( PAR_NONE ) {
			global_config.parity = none;
		} else has_it( PAR_EVEN ) {
			global_config.parity = even;
		} else has_it( PAR_ODD ) {
			global_config.parity = odd;
		} else has_it( PAR_MARK ) {
			global_config.parity = mark;
		} else has_it( PAR_SPACE ) {
			global_config.parity = space;
		} else {
			putsl("my_init(): invalid parity '");
			putsl(value);
			puts("'");
		}
	} else is_it( STOPBITS ) {
		temp = atoi(value);
		if((temp == 1) || (temp == 2)) {
			global_config.stopbits = temp;
		} else {
			putsl("my_init(): invalid stop bits (1 or 2 only) '");
			putsl(value);
			puts("'");
		}
	} else is_it( DATABITS ) {
		temp = atoi(value);
		if((temp >= 5) || (temp <= 8)) {
			global_config.databits = temp;
		} else {
			putsl("my_init(): invalid data bits (5 through 8 only) '");
			putsl(value);
			puts("'");
		}
	} else is_it( PACKET_TIMEOUT ) {
		global_config.packet_timeout = atoi(value);
	} else is_it( PACKET_LENGTH ) {
		global_config.packet_length = atoi(value);
	} else is_it( PACKET_END0 ) {
		global_config.packet_end0 = atoi(value);
	} else is_it( PACKET_END1 ) {
		global_config.packet_end1 = atoi(value);
	} else is_it( ALLOW_ANYONE ) {
		strupr(value);
		has_it( YESNO_YES ) {
			global_config.allow_anyone = yes;
		} else has_it( YESNO_NO ) {
			global_config.allow_anyone = no;
		} else {
			putsl("my_init(): invalid allow_anyone '");
			putsl(value);
			puts("'");
		}
	} else is_it( DROP_SENTINEL ) {
		strupr(value);
		has_it( YESNO_YES ) {
			global_config.drop_sentinel = yes;
		} else has_it( YESNO_NO ) {
			global_config.drop_sentinel = no;
		} else {
			putsl("my_init(): invalid drop_sentinel '");
			putsl(value);
			puts("'");
		}
	} else {
		// set the global flag meaning we couldn't identify the directive
		global_data.unknown_directive = 1;
	}
}


void init_config(void) {
	// top level configuration routine
	puts("init_config():");

#if WHERE
	debugfile = fopen("em.log", "w");
#endif

	default_config();           // set up the default config values

	global_init();              // set up the default global values

	usr_init = my_init;         // install my parser for WATTCP.CFG

	sock_init();                // initialize WATTCP

	serial_init();              // initialize the serial port drivers

	console_init();             // initialize the console driver

	packet_init();              // initialize the packet code

	ether_init();								// initialize the ethernet code
}


void default_config(void) {
	// load up global_config struct with default values
	strcpy(global_config.target_name, "127.0.0.1");
	global_config.target_port     = 9;
	global_config.local_port      = 2222;
	global_config.connect         = demand;
	global_config.dto_source      = 15;
	global_config.dto_target      = 15;
	global_config.baud            = 9600;
	global_config.parity          = none;
	global_config.stopbits        = 1;
	global_config.databits        = 8;
	global_config.packet_timeout  = 10;
	global_config.packet_length   = 15;
	global_config.packet_end0     = -1;
	global_config.packet_end1     = -1;
	global_config.allow_anyone    = yes;
	global_config.drop_sentinel   = yes;
}


void global_init(void) {
	// set up the default global values
	global_data.unknown_directive = 0;
	global_data.unknown_command   = 0;
	global_data.command           = nop;
	global_data.connect_dir       = no_conn;
	global_data.verbose           = true;
}


void print_config(FILE *fp) {
	// print the current global_config struct to the file *

	char *constr, *parstr, *aastr, *dsstr;

	// select some text
	switch( global_config.connect ) {
		case demand : constr = "demand"; break;
		case always : constr = "always"; break;
		case ignore : constr = "ignore"; break;
		default: constr = "invalid";
	}
	switch( global_config.parity ) {
		case none  : parstr = "none";  break;
		case even  : parstr = "even";  break;
		case odd   : parstr = "odd";   break;
		case mark  : parstr = "mark";  break;
		case space : parstr = "space"; break;
		default: parstr = "invalid"; break;
	}
	switch( global_config.allow_anyone ) {
		case yes : aastr = "yes"; break;
		case no  : aastr = "no";  break;
		default : aastr = "invalid"; break;
	}
	switch( global_config.drop_sentinel ) {
		case yes : dsstr = "yes"; break;
		case no  : dsstr = "no";  break;
		default : dsstr = "invalid"; break;
	}

	// dump the text
	fprintf(fp, "target_name = %s\r\n",    global_config.target_name);
	fprintf(fp, "target_port = %u\r\n",    global_config.target_port);
	fprintf(fp, "local_port = %u\r\n",     global_config.local_port);
	fprintf(fp, "connect = %s\r\n",        constr);
	fprintf(fp, "dto_source = %u\r\n",     global_config.dto_source);
	fprintf(fp, "dto_target = %u\r\n",     global_config.dto_target);
	fprintf(fp, "baud = %u\r\n",           global_config.baud);
	fprintf(fp, "parity = %s\r\n",         parstr);
	fprintf(fp, "stopbits = %d\r\n",       global_config.stopbits);
	fprintf(fp, "databits = %d\r\n",       global_config.databits);
	fprintf(fp, "packet_timeout = %u\r\n", global_config.packet_timeout);
	fprintf(fp, "packet_length = %u\r\n",  global_config.packet_length);
	fprintf(fp, "packet_end0 = %d\r\n",    global_config.packet_end0);
	fprintf(fp, "packet_end1 = %d\r\n",    global_config.packet_end1);
	fprintf(fp, "allow_anyone = %s\r\n",   aastr);
	fprintf(fp, "drop_sentinel = %s\r\n",  dsstr);
}


int save_config(void) {
	// save the current configuration data
	// return 0 if successful, -1 else
	FILE *fp;

	fp = fopen(CONFIG_FILE_NAME, "wb");
	if( fp == NULL ) {
		return -1;
	}
	print_config(fp);
	fclose(fp);
	return 0;
}


void config_query(char *name) {
	char *constr, *parstr, *aastr, *dsstr;

	is_it( TARGET_NAME ) {
		printf("target_name = %s\n",    global_config.target_name);
	} else is_it( TARGET_PORT ) {
		printf("target_port = %u\n",    global_config.target_port);
	} else is_it( LOCAL_PORT ) {
		printf("local_port = %u\n",     global_config.local_port);
	} else is_it( CONNECT ) {
		switch( global_config.connect ) {
			case demand : constr = "demand"; break;
			case always : constr = "always"; break;
			case ignore : constr = "ignore"; break;
			default: constr = "invalid";
		}
		printf("connect = %s\n",        constr);
	} else is_it( DTO_SOURCE ) {
		printf("dto_source = %u\n",     global_config.dto_source);
	} else is_it( DTO_TARGET ) {
		printf("dto_target = %u\n",     global_config.dto_target);
	} else is_it( BAUD ) {
		printf("baud = %u\n",           global_config.baud);
	} else is_it( PARITY ) {
		switch( global_config.parity ) {
			case none  : parstr = "none";  break;
			case even  : parstr = "even";  break;
			case odd   : parstr = "odd";   break;
			case mark  : parstr = "mark";  break;
			case space : parstr = "space"; break;
			default: parstr = "invalid"; break;
		}
		printf("parity = %s\n",         parstr);
	} else is_it( STOPBITS ) {
		printf("stopbits = %d\n",       global_config.stopbits);
	} else is_it( DATABITS ) {
		printf("databits = %d\n",       global_config.databits);
	} else is_it( PACKET_TIMEOUT ) {
		printf("packet_timeout = %u\n", global_config.packet_timeout);
	} else is_it( PACKET_LENGTH ) {
		printf("packet_length = %u\n",  global_config.packet_length);
	} else is_it( PACKET_END0 ) {
		printf("packet_end0 = %d\n",    global_config.packet_end0);
	} else is_it( PACKET_END1 ) {
		printf("packet_end1 = %d\n",    global_config.packet_end1);
	} else is_it( ALLOW_ANYONE ) {
		switch( global_config.allow_anyone ) {
			case yes : aastr = "yes"; break;
			case no  : aastr = "no";  break;
			default : aastr = "invalid"; break;
		}
		printf("allow_anyone = %s\n",   aastr);
	} else is_it( DROP_SENTINEL ) {
		switch( global_config.drop_sentinel ) {
			case yes : dsstr = "yes"; break;
			case no  : dsstr = "no";  break;
			default : dsstr = "invalid"; break;
		}
		printf("drop_sentinel = %s\n",  dsstr);
	} else {
		// set the global flag meaning we couldn't identify the directive
		global_data.unknown_directive = 1;
	}
}
