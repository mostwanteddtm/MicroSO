/****************************************************************************
 * Name:        driver.h                                                    *
 * Purpose:     NT driver module                                            *
 *                                                                          *
 * Created by Lawrence Rust, Software Systems Consultants               .   *
 * lvr@softsystem.co.uk. Tel/Fax +33 5 49 72 79 63                          *
 *__________________________________________________________________________*
 *                                                                          *
 * Revision History:                                                        *
 *                                                                          *
 * No.   Date     By   Reason                                               *
 *--------------------------------------------------------------------------*
 * 100 10 Apr 03  lvr  Created                                              *
 * 101 29 Jun 05  lvr  Added pfnGetInfo to Driver_SDeviceInfo               *
 * 102 16 Oct 05  lvr  Added Driver_FGetMcastList                           *
 * 105 18 May 06  lvr  Added Driver_FGetDesc                                *
 *__________________________________________________________________________*/

#ifndef DRIVER_H
#define DRIVER_H

#ifdef __cplusplus
extern "C" {
#endif

/* Constants */


/* Types */
typedef long Driver_FOpen( void**, void*, struct _IRP*);
typedef long Driver_FClose( void*, void*, struct _IRP*);
typedef long Driver_FRead( void*, void*, struct _IRP*, void*, unsigned long*);
typedef long Driver_FWrite( void*, void*, struct _IRP*, void*, unsigned long*);
typedef long Driver_FCancel( void*, void*, struct _IRP*);
typedef long Driver_FGetMacAddr( void*, void*, void*);
typedef long Driver_FSetMcastList( void*, void*, const void*, unsigned);
typedef long Driver_FGetMcastList( void*, void*, void*, unsigned*);
typedef long Driver_FSetPromiscuity( void*, void*, int);
typedef long Driver_FWriteScatter( void*, void*, struct _IRP*, void*, unsigned long*);
typedef long Driver_FGetInfo( void*, void*);
typedef long Driver_FGetDesc( void*, void*, unsigned*);

/* Device despatch table */
typedef struct Driver_SDeviceInfo
  {
  Driver_FOpen*            pfnOpen;
  Driver_FClose*           pfnClose;
  Driver_FRead*            pfnRead;
  Driver_FWrite*           pfnWrite;
  Driver_FCancel*          pfnCancel;
  Driver_FGetMacAddr*      pfnGetMacAddr;
  Driver_FSetMcastList*    pfnSetMulticastList;
  Driver_FGetMcastList*    pfnGetMulticastList;
  Driver_FSetPromiscuity*  pfnSetPromiscuity;
  Driver_FWriteScatter*    pfnWriteScatter;
  Driver_FGetInfo*         pfnGetInfo;
  Driver_FGetDesc*         pfnGetDesc;
  } Driver_SDeviceInfo;


/*
 * Functions
 */
/* Add a device */
extern int Driver_AddDevice(
  struct _DEVICE_OBJECT**,            /* OUT */
  const Driver_SDeviceInfo*,          /* IN: -> Despatch table */
  void*                               /* IN: Callback context */
);

/* Remove a device */
extern void Driver_RemoveDevice(
  struct _DEVICE_OBJECT*              /* IN */
);

/* Set current device */
extern void Driver_SetDevice(
  struct _DEVICE_OBJECT*              /* IN */
);

/* Complete a pending request */
extern void Driver_CompleteRequest(
  struct _IRP*,                       /* IN */
  long,                               /* IN */
  unsigned long                       /* IN: Information - bytes transferred */
);

/* Read a config value */
extern int Driver_ReadParamDword(
  const unsigned short*,              /* IN: 16-bit char string */
  unsigned long*                      /* OUT: Value */
);

#ifdef __cplusplus
}
#endif
#endif /*ndef DRIVER_H*/
/* End of file */
