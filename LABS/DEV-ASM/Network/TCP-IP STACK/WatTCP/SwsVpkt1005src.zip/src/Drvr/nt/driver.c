/****************************************************************************
 * Name:        driver.c                                                    *
 * Purpose:     NT/WDM Driver entry points                                  *
 *                                                                          *
 * Created by Lawrence Rust, Software Systems Consultants               .   *
 * lvr@softsystem.co.uk. Tel/Fax +33 5 49 72 79 63                          *
 *                                                                          *
 * Runtime:     Windows NT4sp3, 2000, XP                                    *
 *__________________________________________________________________________*
 *                                                                          *
 * Revision History:                                                        *
 *                                                                          *
 * No.   Date     By   Reason                                               *
 *--------------------------------------------------------------------------*
 * 100 20 Mar 03  lvr  Created the day war broke in Iraq :-(                *
 * 101 18 May 06  lvr  Added IOCTL_GETDESC                                  *
 *__________________________________________________________________________*/

/* Compilation options */
#ifndef OPT_MULTI
#define OPT_MULTI 1 /* !0 for multiple open per binding */
#endif

/* Quieten VC++ level 4 warnings about the DDK */
#pragma warning( disable : 4201) /* nonstandard extension used : nameless struct/union */
#pragma warning( disable : 4214) /* nonstandard extension used : bit field types other than int */
#pragma warning( disable : 4115) /* named type definition in parentheses */
#pragma warning( disable : 4514) /* unreferenced inline function has been removed */
/* File specific warnings */
#pragma warning( disable : 4055) /* 'type cast' : from data pointer 'void *' to function pointer */
#pragma warning( disable : 4710) /* function not expanded */
#pragma warning( disable : 4505) /* unreferenced local function has been removed */


/* Exports */
#include "driver.h"

/* Imports */
/* ANSI */

/* NT DDK */
#if SWS_WDM
#include <wdm.h>
#else
#include <ntddk.h>
#endif

/* Project specific */
#include "ioctls.h"                   /* Driver ioctl defintions */
#include "protocol.h"                 /* Protocol driver module */

#include "debug.h"
#include "tracelog.h"


/*
 * Macros & constants
 */
/* Length of an array - sorely missing from stddef.h */
#ifndef lengthof
#define lengthof( _a) ((size_t)( sizeof(_a)/sizeof((_a)[0]) ))
#endif

#define _WIDETEXT( quote) L##quote
#define WIDETEXT( quote) _WIDETEXT( quote)

#define SYMBOLIC_NAME   L"\\DosDevices\\" WIDETEXT( IOCTL_DEVICE)
#define DEVICE_NAME     L"\\Device\\" WIDETEXT( IOCTL_DEVICE)
#define DEVICE_CODE     0xA50C /* Arbitrary device code, Microsoft uses 0 - 0x7FFF, OEMs use 0x8000 - 0xFFFF */
#define kwsParameters   L"Parameters"

#ifndef FILE_DEVICE_SECURE_OPEN
#define FILE_DEVICE_SECURE_OPEN 0
#endif


/*
 * Types
 */
enum EMagic { kMagic = 'asck'};

typedef struct  DEVICE_EXTENSION
  {
#if DBG
  enum EMagic eMagic;                   /* For assert checks */
#endif
  PDEVICE_OBJECT    pDeviceObject;      /* -> Parent device */
  ULONG             ulDeviceID;
  UNICODE_STRING    suSymbolicName;
  WCHAR             aswSymbolicName[ lengthof( SYMBOLIC_NAME) + 4 ];

  BOOL              bClosing;
  LONG              lPending;           /* No. pending IRP's */
  KEVENT            evIdle;             /* Set when device is idle */

  Driver_SDeviceInfo adapterInfo;
  void*             pvContext;
  } DEVICE_EXTENSION, *PDEVICE_EXTENSION;


/*
 * Function prototypes
 */
#ifdef __cplusplus
extern "C" {
#endif

extern NTSTATUS DriverEntry( IN PDRIVER_OBJECT, IN PUNICODE_STRING);
static VOID DriverUnload( IN PDRIVER_OBJECT);
static NTSTATUS DriverCreate( IN PDEVICE_OBJECT, IN PIRP);
static NTSTATUS DriverCleanup( IN PDEVICE_OBJECT, IN PIRP);
static NTSTATUS DriverClose( IN PDEVICE_OBJECT, IN PIRP);
static NTSTATUS DriverRead( IN PDEVICE_OBJECT, IN PIRP);
static NTSTATUS DriverWrite( IN PDEVICE_OBJECT, IN PIRP);
static NTSTATUS DriverControl( IN PDEVICE_OBJECT, IN PIRP);
static VOID DriverCancel( IN PDEVICE_OBJECT, IN PIRP);

#ifdef DEBUG_TRACE_LEVEL
static int GetDebugLevel( PUNICODE_STRING);
#endif
static void TraceLog( const char*);

#ifdef __cplusplus
}
#endif


/*
 * Module data
 */
static PDRIVER_OBJECT s_pDriverObject;
static PDEVICE_OBJECT s_pDeviceObject, s_pCurrentDeviceObject;
static WCHAR s_aswRegistryPath[ 512];
static UNICODE_STRING s_suRegistryPath; /* Driver registry path */
static ULONG s_ulDevices;               /* Bit mask of device IDs in use */

/* Debugging */
DEBUG_TRACE( 1, &TraceLog)              /* Default trace level, 1= warnings */


/****************************************************************************
 * Driver load and unload
 ****************************************************************************/
/*
 * DriverEntry - Device driver initialisation
 * The primary initialization routine for the driver.
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma alloc_text( INIT, DriverEntry)
extern NTSTATUS DriverEntry(
  IN PDRIVER_OBJECT pDriverObject,
  IN PUNICODE_STRING pRegistryPath    /* Unicode registry pathname for this driver */
) {
  NTSTATUS Status;
  PDEVICE_OBJECT pDeviceObject;
  PDEVICE_EXTENSION pDeviceExtension;
  UNICODE_STRING suDeviceName;
  static const WCHAR kwszSymbolicName[] = SYMBOLIC_NAME;

  KdPrint(( IOCTL_DEVICE ": DriverEntry(%p,'%ls')\n",
    pDriverObject, pRegistryPath ? pRegistryPath->Buffer : NULL));

  PAGED_CODE();
  ASSERT( PASSIVE_LEVEL == KeGetCurrentIrql());
  ASSERT( NULL != pDriverObject);
  ASSERT( NULL != pRegistryPath);

  s_pDriverObject = pDriverObject;

  /* Save the base registry path */
  s_suRegistryPath.Length = 0;
  s_suRegistryPath.MaximumLength = lengthof( s_aswRegistryPath);
  s_suRegistryPath.Buffer = s_aswRegistryPath;
  RtlCopyUnicodeString( &s_suRegistryPath, pRegistryPath);

  /* Set default trace detail and initial breakpoint from registry params */
  DEBUG_SET_TRACE_LEVEL( GetDebugLevel( pRegistryPath));
  DEBUG_SET_TRACE_FN( &TraceLog);
  TRACE( 2, ("DriverEntry trace level %d\n", (int)DEBUG_TRACE_LEVEL));

  /* Initialize the driver object with this driver's entry points. */
  pDriverObject->MajorFunction[ IRP_MJ_CREATE]         = &DriverCreate;
  pDriverObject->MajorFunction[ IRP_MJ_CLEANUP]        = &DriverCleanup;
  pDriverObject->MajorFunction[ IRP_MJ_CLOSE]          = &DriverClose;
  pDriverObject->MajorFunction[ IRP_MJ_READ]           = &DriverRead;
  pDriverObject->MajorFunction[ IRP_MJ_WRITE]          = &DriverWrite;
  pDriverObject->MajorFunction[ IRP_MJ_DEVICE_CONTROL] = &DriverControl;
  pDriverObject->DriverUnload                          = &DriverUnload;

  /* Create a device object for the driver.*/
  RtlInitUnicodeString( &suDeviceName, DEVICE_NAME);
  Status = IoCreateDevice(
    pDriverObject,
    sizeof( *pDeviceExtension),
    &suDeviceName,                      /* Optional device name */
    DEVICE_CODE,                        /* Device type */
    (1 * FILE_DEVICE_SECURE_OPEN),      /* Device characteristics */
    FALSE,                              /* TRUE for single open instance */
    &pDeviceObject                      /* OUT: Device object */
  );
  if ( !NT_SUCCESS( Status))
    {
    _TRACE( "!IoCreateDevice returned 0x%08x\n", Status);
    return Status;
    }
  s_pDeviceObject = pDeviceObject;

  /* Setup the device extension */
  pDeviceExtension = (PDEVICE_EXTENSION) pDeviceObject->DeviceExtension;
  RtlZeroMemory( pDeviceExtension, sizeof( *pDeviceExtension));
#if DBG
  pDeviceExtension->eMagic = kMagic;
#endif
  pDeviceExtension->pDeviceObject = pDeviceObject;
  KeInitializeEvent( &pDeviceExtension->evIdle, NotificationEvent, TRUE);

  /* Create a Win32 visible symbolic device name */
  RtlInitUnicodeString( &pDeviceExtension->suSymbolicName, kwszSymbolicName);
  Status = IoCreateSymbolicLink( &pDeviceExtension->suSymbolicName, &suDeviceName);
  if ( !NT_SUCCESS( Status))
    {
    _TRACE( "!IoCreateSymbolicLink '%ls' failed 0x%08lx\n",
      pDeviceExtension->suSymbolicName.Buffer, Status);
    IoDeleteDevice( pDeviceObject);
    return Status;
    }

  /* Register the protocol */
  Status = ProtocalInstall();
  if ( Status)
    {
    _TRACE( "!ProtocalInstall failed(%d)\n", (int)Status);
    IoDeleteSymbolicLink(  &pDeviceExtension->suSymbolicName);
    IoDeleteDevice( pDeviceObject);
    return STATUS_UNSUCCESSFUL;
    }

  return STATUS_SUCCESS;
  }


/*
 * Driver finalisation
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma alloc_text( PAGE, DriverUnload)
VOID DriverUnload(
  IN PDRIVER_OBJECT pDriverObject
) {
  PDEVICE_OBJECT pDeviceObject;

  KdPrint(( IOCTL_DEVICE ": DriverUnload(%p)\n",pDriverObject));

  PAGED_CODE();
  ASSERT( PASSIVE_LEVEL == KeGetCurrentIrql());
  ASSERT( NULL != pDriverObject);

  Driver_SetDevice( NULL);
  if ( NULL != s_pDriverObject)
    {
    ASSERT( s_pDriverObject == pDriverObject);
    s_pDriverObject = NULL;

    /* Unload the protocol driver */
    /* BUGBUG: ProtocolUnload causes NT4 to BSOD because of pending open adapters */
    ProtocolUnload();

    /* Destroy all device objects */
    s_pDeviceObject = NULL;
    while ( NULL != (pDeviceObject = pDriverObject->DeviceObject) )
      {
      PDEVICE_EXTENSION pDeviceExtension = (PDEVICE_EXTENSION) pDeviceObject->DeviceExtension;
      if ( NULL != pDeviceExtension)
        {
        ASSERT( kMagic == pDeviceExtension->eMagic);
        ASSERT( pDeviceExtension->pDeviceObject == pDeviceObject);

        /* Destroy Win32 device name */
        if ( NULL != pDeviceExtension->suSymbolicName.Buffer)
          {
          TRACE( 2, ("DriverUnload() %ls\n",
            pDeviceExtension->suSymbolicName.Buffer));
          IoDeleteSymbolicLink( &pDeviceExtension->suSymbolicName);
          }
        }

      IoDeleteDevice( pDeviceObject);
      }
    }
  }


/*
 * Inc/decrement the no,.pending IRP's
 */
static __inline void IoIncrement( IN PDEVICE_OBJECT pDeviceObject)
  {
  PDEVICE_EXTENSION pDeviceExtension = (PDEVICE_EXTENSION) pDeviceObject->DeviceExtension;

  if ( 1 == InterlockedIncrement( &pDeviceExtension->lPending))
    {
    KeClearEvent( &pDeviceExtension->evIdle);
    }
  }

static __inline void IoDecrement( IN PDEVICE_OBJECT pDeviceObject)
  {
  PDEVICE_EXTENSION pDeviceExtension = (PDEVICE_EXTENSION) pDeviceObject->DeviceExtension;

  if ( 0 == InterlockedDecrement( &pDeviceExtension->lPending))
    {
    KeSetEvent( &pDeviceExtension->evIdle, 0, FALSE);
    }
  }


/****************************************************************************
 * External functions
 ****************************************************************************/
/*
 * Add a device
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma alloc_text( PAGE, Driver_AddDevice)
extern int Driver_AddDevice(
  PDEVICE_OBJECT* ppDeviceObject,     /* OUT */
  const Driver_SDeviceInfo* pInfo,    /* IN: -> Despatch table */
  void* pvContext                     /* IN: Callback context */
) {
  NTSTATUS Status;
  PDEVICE_OBJECT pDeviceObject;
  PDEVICE_EXTENSION pDeviceExtension;
  WCHAR wszDeviceName[ sizeof( DEVICE_NAME) + 32];
  UNICODE_STRING suDeviceName;
  ULONG ulDeviceId;

  TRACE( 9, ("Driver_AddDevice(%p,%p)\n",pInfo,pvContext));

  PAGED_CODE();
  ASSERT( PASSIVE_LEVEL == KeGetCurrentIrql());
  ASSERT( NULL != ppDeviceObject);
  ASSERT( NULL != pInfo);
  ASSERT( pInfo->pfnOpen);
  ASSERT( pInfo->pfnClose);
  ASSERT( pInfo->pfnRead);
  ASSERT( pInfo->pfnWrite);
  ASSERT( pInfo->pfnCancel);
  ASSERT( pInfo->pfnGetMacAddr);

  *ppDeviceObject = NULL;

  /* Assign an unused device ID */
  for ( ulDeviceId = 0; ulDeviceId < 32; ++ulDeviceId)
    {
    if ( !(s_ulDevices & (1 << ulDeviceId)))
      break;
    }

  /* Append device instance to name */
  swprintf( wszDeviceName, DEVICE_NAME L"%lu", ulDeviceId);
  RtlInitUnicodeString( &suDeviceName, wszDeviceName);

  /* Create a device object */
  Status = IoCreateDevice(
    s_pDriverObject,
    sizeof( *pDeviceExtension),
    &suDeviceName,                      /* Optional device name */
    DEVICE_CODE,                        /* Device type */
    (1 * FILE_DEVICE_SECURE_OPEN),      /* Device characteristics */
    OPT_MULTI ? FALSE : TRUE,           /* TRUE for single open instance */
    &pDeviceObject                      /* OUT: Device object */
  );
  if ( !NT_SUCCESS( Status))
    {
    TRACE( 0, ("!Driver_AddDevice() IoCreateDevice returned 0x%08x\n", Status));
    return Status;
    }
  ASSERT( NULL != pDeviceObject);
  Driver_SetDevice( pDeviceObject);

  /* Setup the device extension */
  pDeviceExtension = (PDEVICE_EXTENSION) pDeviceObject->DeviceExtension;
  RtlZeroMemory( pDeviceExtension, sizeof( *pDeviceExtension));
#if DBG
  pDeviceExtension->eMagic = kMagic;
#endif
  pDeviceExtension->pDeviceObject = pDeviceObject;
  pDeviceExtension->ulDeviceID = ulDeviceId;
  s_ulDevices |= (1 << ulDeviceId);
  KeInitializeEvent( &pDeviceExtension->evIdle, NotificationEvent, TRUE);

  /* Save client context */
  pDeviceExtension->adapterInfo = *pInfo;
  pDeviceExtension->pvContext = pvContext;

  /* Append device instance number to symbolic name */
  swprintf( pDeviceExtension->aswSymbolicName, SYMBOLIC_NAME L"%lu", ulDeviceId);
  RtlInitUnicodeString(
    &pDeviceExtension->suSymbolicName,
    pDeviceExtension->aswSymbolicName
  );

  /* Create a Win32 visible symbolic device name */
  Status = IoCreateSymbolicLink(
    &pDeviceExtension->suSymbolicName,
    &suDeviceName
  );
  if ( !NT_SUCCESS( Status))
    {
    TRACE( 0, ("!Driver_AddDevice() IoCreateSymbolicLink '%ls' failed 0x%08lx\n",
      pDeviceExtension->suSymbolicName.Buffer, Status));
    IoDeleteDevice( pDeviceObject);
    return Status;
    }
  TRACE( 2, ("Driver_AddDevice() %ls\n",
    pDeviceExtension->suSymbolicName.Buffer));

  /* Set buffer mode for read/write operations (IRP_MJ_READ & IRP_MJ_WRITE)
   * Doesn't affect IOCTL operations, they're defined using the CTL_CODE macro
   */
  pDeviceObject->Flags |= DO_DIRECT_IO; /* or DO_BUFFERED_IO */
  pDeviceObject->AlignmentRequirement = FILE_WORD_ALIGNMENT;

  /* Clear the DO_DEVICE_INITIALIZING flag. This is required
   * when creating device objects outside of DriverEntry.
   */
  pDeviceObject->Flags &= ~DO_DEVICE_INITIALIZING;

  *ppDeviceObject = pDeviceObject;
  return STATUS_SUCCESS;
  }


/*
 * Remove a device
 * NB Not paged 'cos on NT4 can unbind at APC level
 */
void Driver_RemoveDevice(
  PDEVICE_OBJECT pDeviceObject
) {
  TRACE( 9, ("Driver_RemoveDevice(%p)\n",pDeviceObject));

  if ( PASSIVE_LEVEL == KeGetCurrentIrql()
    && NULL != pDeviceObject
  ) {
    PDEVICE_EXTENSION pDeviceExtension = (PDEVICE_EXTENSION)pDeviceObject->DeviceExtension;
    ASSERT( NULL != pDeviceExtension);
    ASSERT( kMagic == pDeviceExtension->eMagic);

    Driver_SetDevice( NULL);
    TRACE( 2, ("Driver_RemoveDevice() %ls\n",
      pDeviceExtension->suSymbolicName.Buffer));

    /* Destroy the Win32 device name */
    IoDeleteSymbolicLink( &pDeviceExtension->suSymbolicName);

    /* Cancel all pending requests */
    pDeviceExtension->bClosing = TRUE;
    if ( pDeviceExtension->adapterInfo.pfnCancel)
      {
      /* Cancel all pending IRP's */
      (*pDeviceExtension->adapterInfo.pfnCancel)( pDeviceExtension->pvContext, NULL, NULL);
      }

    if ( pDeviceExtension->lPending > 0)
      {
      NTSTATUS status;
      LARGE_INTEGER timeout;

      /* Wait for all IRP's to complete */
      timeout.QuadPart = -3000 * (LONGLONG)10000L; /* 1e-7s ticks, -ve relative */
      status = KeWaitForSingleObject( &pDeviceExtension->evIdle, Executive, UserMode, TRUE, &timeout);
      if ( STATUS_SUCCESS != status)
        TRACE( 0, ("!Driver_RemoveDevice wait failed %#lx\n",status));
      }

    /* Mark the device ID as free */
    ASSERT( pDeviceExtension->ulDeviceID < 32);
    ASSERT( s_ulDevices & (1 << pDeviceExtension->ulDeviceID));
    s_ulDevices &= ~(1 << pDeviceExtension->ulDeviceID);

    /* Destroy the device */
    IoDeleteDevice( pDeviceObject);
    }
  }


/*
 * Set current device
 */
void Driver_SetDevice(
  struct _DEVICE_OBJECT* pDeviceObject
) {
  TRACE( 9, ("Driver_SetDevice(%p)\n",pDeviceObject));
  s_pCurrentDeviceObject = pDeviceObject;
  }


/*
 * Complete a request
 */
void Driver_CompleteRequest(
  PIRP pIrp,
  long status,
  unsigned long info
) {
  PDEVICE_OBJECT pDeviceObject = IoGetCurrentIrpStackLocation( pIrp)->DeviceObject;

  TRACE( 9, ("Driver_CompleteRequest(%p,%#lx,%lu)\n",pIrp,status,info));

#pragma warning( disable : 4055) /* 'type cast' : from data pointer 'void *' to function pointer */
  IoSetCancelRoutine( pIrp, 0);
#pragma warning( default : 4055)

  pIrp->IoStatus.Information = info;
  pIrp->IoStatus.Status = status;
  IoCompleteRequest( pIrp, IO_NO_INCREMENT);
  
  IoDecrement( pDeviceObject);
  }


/*
 * Read a parameter from the registry
 * IRQL PASSIVE_LEVEL
 */
#pragma alloc_text( PAGE, Driver_ReadParamDword)
int Driver_ReadParamDword(
  const unsigned short* pwsz,
  unsigned long* pdw
) {
  NTSTATUS Status;
  RTL_QUERY_REGISTRY_TABLE ParamTable[3];
  ULONG ulZero = 0;
  COMPILATION_REQUIRES( sizeof(*pdw) == sizeof( DWORD));
  COMPILATION_REQUIRES( sizeof(*pwsz) == sizeof( WCHAR));
    
  TRACE( 9, ( "Driver_ReadParamDword('%ls',%p)\n", pwsz, pdw));
  PAGED_CODE();
  ASSERT( PASSIVE_LEVEL == KeGetCurrentIrql());
  ASSERT( NULL != pwsz);
  ASSERT( NULL != pdw);

  RtlZeroMemory( ParamTable, sizeof(ParamTable));

  /* change to the parmeters key */
  ParamTable[0].QueryRoutine = NULL;
  ParamTable[0].Flags = RTL_QUERY_REGISTRY_SUBKEY;
  ParamTable[0].Name = (PWSTR)kwsParameters;

  ParamTable[1].QueryRoutine = 0;
  ParamTable[1].Flags = RTL_QUERY_REGISTRY_DIRECT;
  ParamTable[1].Name = (PWSTR)pwsz;
  ParamTable[1].EntryContext = pdw;
  ParamTable[1].DefaultType = REG_DWORD;
  ParamTable[1].DefaultData = &ulZero;
  ParamTable[1].DefaultLength = sizeof( ulZero);

  Status = RtlQueryRegistryValues(
    RTL_REGISTRY_ABSOLUTE | RTL_REGISTRY_OPTIONAL,
    s_suRegistryPath.Buffer,
    &ParamTable[ 0],
    NULL,
    NULL
  );

  return NT_SUCCESS( Status);
  }


/****************************************************************************
 * Dispatch functions
 ****************************************************************************/
/*
 * Create a device instance
 *
 * IRQL PASSIVE_LEVEL
 */
/*#pragma alloc_text( PAGE, DriverCreate)*/
NTSTATUS DriverCreate(
  IN PDEVICE_OBJECT pDeviceObject,
  IN PIRP pIrp
) {
  PDEVICE_EXTENSION pDeviceExtension = (PDEVICE_EXTENSION) pDeviceObject->DeviceExtension;
  NTSTATUS status;
  PFILE_OBJECT pFileObject;

  PAGED_CODE();
  ASSERT( PASSIVE_LEVEL == KeGetCurrentIrql());
  ASSERT( NULL != pIrp);
  ASSERT( NULL != pDeviceObject);
  ASSERT( NULL != pDeviceExtension);
  ASSERT( kMagic == pDeviceExtension->eMagic);

  Driver_SetDevice( pDeviceObject);
  TRACE( 2, ("DriverCreate(%p,%p)\n",pDeviceObject,pIrp));

  pIrp->IoStatus.Information = 0;
  IoIncrement( pDeviceObject);

  if ( pDeviceExtension->bClosing)
    {
    status = STATUS_DELETE_PENDING;
    }
  else if ( !pDeviceExtension->adapterInfo.pfnOpen)
    {
    status = STATUS_SUCCESS;
    }
  else if ( NULL == (pFileObject = IoGetCurrentIrpStackLocation( pIrp)->FileObject) )
    {
    TRACE( 1, ("*DriverCreate() No file object\n"));
    status = STATUS_FILE_INVALID;
    }
  else
    {
    status = (*pDeviceExtension->adapterInfo.pfnOpen)(
      &pFileObject->FsContext,
      pDeviceExtension->pvContext,
      pIrp
    );
    }

  if ( STATUS_PENDING != status)
    {
    pIrp->IoStatus.Status = status;
    IoCompleteRequest( pIrp, IO_NO_INCREMENT);
    IoDecrement( pDeviceObject);
    }

  Driver_SetDevice( NULL);
  return status;
  }


/*
 * Close a device instance
 *
 * IRQL PASSIVE_LEVEL
 */
/*#pragma alloc_text( PAGE, DriverClose)*/
NTSTATUS DriverClose(
  IN PDEVICE_OBJECT pDeviceObject,
  IN PIRP pIrp
) {
  PDEVICE_EXTENSION pDeviceExtension = (PDEVICE_EXTENSION) pDeviceObject->DeviceExtension;
  NTSTATUS status;

  PAGED_CODE();
  ASSERT( PASSIVE_LEVEL == KeGetCurrentIrql());
  ASSERT( NULL != pIrp);
  ASSERT( NULL != pDeviceObject);
  ASSERT( NULL != pDeviceExtension);
  ASSERT( kMagic == pDeviceExtension->eMagic);

  Driver_SetDevice( pDeviceObject);
  TRACE( 2, ("DriverClose(%p,%p)\n",pDeviceObject,pIrp));

  pIrp->IoStatus.Information = 0;
  IoIncrement( pDeviceObject);

  if ( pDeviceExtension->bClosing)
    {
    status = STATUS_DELETE_PENDING;
    }
  else if ( !pDeviceExtension->adapterInfo.pfnClose)
    {
    status = STATUS_SUCCESS;
    }
  else
    {
    PFILE_OBJECT pFileObject = IoGetCurrentIrpStackLocation( pIrp)->FileObject;

    ASSERT( NULL != pFileObject);

    status = (*pDeviceExtension->adapterInfo.pfnClose)(
      pDeviceExtension->pvContext,
      pFileObject->FsContext,
      pIrp
    );
    }

  if ( STATUS_PENDING != status)
    {
    pIrp->IoStatus.Status = status;
    IoCompleteRequest( pIrp, IO_NO_INCREMENT);
    IoDecrement( pDeviceObject);
    }

  Driver_SetDevice( NULL);
  return status;
  }


/*
 * Cleanup a device instance
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma alloc_text( PAGE, DriverCleanup)
NTSTATUS DriverCleanup(
  IN PDEVICE_OBJECT pDeviceObject,
  IN PIRP pIrp
) {
  NTSTATUS status;
  PDEVICE_EXTENSION pDeviceExtension = (PDEVICE_EXTENSION) pDeviceObject->DeviceExtension;
  PFILE_OBJECT pFileObject = IoGetCurrentIrpStackLocation( pIrp)->FileObject;

  PAGED_CODE();
  ASSERT( PASSIVE_LEVEL == KeGetCurrentIrql());
  ASSERT( NULL != pDeviceObject);
  ASSERT( NULL != pIrp);
  ASSERT( NULL != pDeviceExtension);
  ASSERT( kMagic == pDeviceExtension->eMagic);

  Driver_SetDevice( pDeviceObject);
  TRACE( 3, ("DriverCleanup(%p,%p) %ld pending\n",
    pDeviceObject, pIrp, pDeviceExtension->lPending));

  pIrp->IoStatus.Information = 0;

  if ( pDeviceExtension->bClosing)
    {
    pIrp->IoStatus.Status = status = STATUS_DELETE_PENDING;
    IoCompleteRequest( pIrp, IO_NO_INCREMENT);
    return status;
    }

  if ( pDeviceExtension->adapterInfo.pfnCancel)
    {
    /* Cancel all pending IRP's */
    (*pDeviceExtension->adapterInfo.pfnCancel)(
      pDeviceExtension->pvContext,
      NULL != pFileObject ? pFileObject->FsContext : NULL,
      NULL
    );
    }

  if ( NULL == pFileObject->FsContext
    && pDeviceExtension->lPending > 0
  ) {
    LARGE_INTEGER timeout;

    /* Wait for all IRP's to complete */
    timeout.QuadPart = -3000 * (LONGLONG)10000L; /* 1e-7s ticks, -ve relative */
    status = KeWaitForSingleObject( &pDeviceExtension->evIdle, Executive, UserMode, TRUE, &timeout);
    if ( STATUS_SUCCESS != status)
      TRACE( 0, ("!DriverCleanup wait failed %#lx\n",status));
    }

  pIrp->IoStatus.Status = STATUS_SUCCESS;
  IoCompleteRequest( pIrp, IO_NO_INCREMENT);

  Driver_SetDevice( NULL);
  return STATUS_SUCCESS;
  }


/*
 * Handle a read request
 *
 * IRQL PASSIVE_LEVEL
 */
/*#pragma alloc_text( PAGE, DriverRead)*/
NTSTATUS DriverRead(
  IN PDEVICE_OBJECT pDeviceObject,
  IN PIRP pIrp
) {
  PDEVICE_EXTENSION pDeviceExtension = (PDEVICE_EXTENSION) pDeviceObject->DeviceExtension;
  NTSTATUS status;
  unsigned long ulTransferred;
  PVOID pvBuf;

  PAGED_CODE();
  ASSERT( PASSIVE_LEVEL == KeGetCurrentIrql());
  ASSERT( NULL != pIrp);
  ASSERT( NULL != pDeviceObject);
  ASSERT( NULL != pDeviceExtension);
  ASSERT( kMagic == pDeviceExtension->eMagic);

  Driver_SetDevice( pDeviceObject);
  TRACE( 9, ("DriverRead(%p,%p)\n",pDeviceObject,pIrp));

  pIrp->IoStatus.Information = 0;

  if ( pDeviceExtension->bClosing)
    {
    status = STATUS_DELETE_PENDING;
    }
  else if ( !pDeviceExtension->adapterInfo.pfnRead)
    {
    status = STATUS_INVALID_DEVICE_REQUEST;
    }
  /* This device uses DO_DIRECT_IO */
  else if ( NULL == pIrp->MdlAddress)
    {
    TRACE( 1, ("*DriverRead() invalid MdlAddress\n"));
    status = STATUS_BUFFER_TOO_SMALL;
    }
#if DBG && DDK_VERSION >= 50 && !defined BINARY_COMPATIBLE
  else if ( NULL == (pvBuf = MmGetSystemAddressForMdlSafe( pIrp->MdlAddress, LowPagePriority)) )
#else
  else if ( NULL == (pvBuf = MmGetSystemAddressForMdl( pIrp->MdlAddress)) )
#endif
    {
    TRACE( 1, ("*DriverRead() MmGetSystemAddressForMdl failed\n"));
    status = STATUS_INSUFFICIENT_RESOURCES;
    }
  else
    {
    PFILE_OBJECT pFileObject = IoGetCurrentIrpStackLocation( pIrp)->FileObject;

    ASSERT( NULL != pFileObject);

    ulTransferred = MmGetMdlByteCount( pIrp->MdlAddress);

    IoIncrement( pDeviceObject);
    IoMarkIrpPending( pIrp);
#pragma warning( disable : 4055) /* 'type cast' : from data pointer to function pointer */
#pragma warning( disable : 4054) /* 'type cast' : from function pointer to data pointer */
    IoSetCancelRoutine( pIrp, &DriverCancel);
#pragma warning( default : 4054)
#pragma warning( default : 4055)

    ASSERT( pDeviceExtension->adapterInfo.pfnCancel); 
    status = (*pDeviceExtension->adapterInfo.pfnRead)(
      pDeviceExtension->pvContext,
      pFileObject->FsContext,
      pIrp,
      pvBuf,
      &ulTransferred
    );
    if ( STATUS_PENDING != status)
      Driver_CompleteRequest( pIrp, status, ulTransferred );

    Driver_SetDevice( NULL);
    return STATUS_PENDING;
    }

  pIrp->IoStatus.Status = status;
  IoCompleteRequest( pIrp, IO_NO_INCREMENT);
  Driver_SetDevice( NULL);
  return status;
  }


/*
 * Handle a write request
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma alloc_text( PAGE, DriverWrite)
NTSTATUS DriverWrite(
  IN PDEVICE_OBJECT pDeviceObject,
  IN PIRP pIrp
) {
  PDEVICE_EXTENSION pDeviceExtension = (PDEVICE_EXTENSION) pDeviceObject->DeviceExtension;
  NTSTATUS status;
  unsigned long ulTransferred;
  PVOID pvBuf;

  PAGED_CODE();
  ASSERT( PASSIVE_LEVEL == KeGetCurrentIrql());
  ASSERT( NULL != pIrp);
  ASSERT( NULL != pDeviceObject);
  ASSERT( NULL != pDeviceExtension);
  ASSERT( kMagic == pDeviceExtension->eMagic);

  Driver_SetDevice( pDeviceObject);
  TRACE( 9, ("DriverWrite(%p,%p)\n",pDeviceObject,pIrp));

  pIrp->IoStatus.Information = 0;

  if ( pDeviceExtension->bClosing)
    {
    status = STATUS_DELETE_PENDING;
    }
  else if ( !pDeviceExtension->adapterInfo.pfnWrite)
    {
    status = STATUS_INVALID_DEVICE_REQUEST;
    }
  /* This device uses DO_DIRECT_IO */
  else if ( NULL == pIrp->MdlAddress)
    {
    TRACE( 1, ("*DriverWrite() invalid MdlAddress\n"));
    status = STATUS_BUFFER_TOO_SMALL;
    }
#if DBG && DDK_VERSION >= 50 && !defined BINARY_COMPATIBLE
  else if ( NULL == (pvBuf = MmGetSystemAddressForMdlSafe( pIrp->MdlAddress, LowPagePriority)) )
#else
  else if ( NULL == (pvBuf = MmGetSystemAddressForMdl( pIrp->MdlAddress)) )
#endif
    {
    TRACE( 1, ("*DriverWrite() MmGetSystemAddressForMdl failed\n"));
    status = STATUS_INSUFFICIENT_RESOURCES;
    }
  else
    {
    PFILE_OBJECT pFileObject = IoGetCurrentIrpStackLocation( pIrp)->FileObject;

    ASSERT( NULL != pFileObject);

    ulTransferred = MmGetMdlByteCount( pIrp->MdlAddress);

    IoIncrement( pDeviceObject);
    IoMarkIrpPending( pIrp);
#pragma warning( disable : 4055) /* 'type cast' : from data pointer to function pointer */
#pragma warning( disable : 4054) /* 'type cast' : from function pointer to data pointer */
    IoSetCancelRoutine( pIrp, &DriverCancel);
#pragma warning( default : 4054)
#pragma warning( default : 4055)

    ASSERT( pDeviceExtension->adapterInfo.pfnCancel); 
    status = (*pDeviceExtension->adapterInfo.pfnWrite)(
      pDeviceExtension->pvContext,
      pFileObject->FsContext,
      pIrp,
      pvBuf,
      &ulTransferred
    );
    if ( STATUS_PENDING != status)
      Driver_CompleteRequest( pIrp, status, ulTransferred );

    Driver_SetDevice( NULL);
    return STATUS_PENDING;
    }

  pIrp->IoStatus.Status = status;
  IoCompleteRequest( pIrp, IO_NO_INCREMENT);
  Driver_SetDevice( NULL);
  return status;
  }


/*
 * Handle device control IRPs
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma alloc_text( PAGE, DriverControl)
NTSTATUS DriverControl(
  IN PDEVICE_OBJECT pDeviceObject,
  IN PIRP pIrp
) {
  NTSTATUS status;
  PDEVICE_EXTENSION pDeviceExtension;
  PIO_STACK_LOCATION pioStack;
  PVOID pvBuf;
  PFILE_OBJECT pFileObject;
  unsigned uLen;
    
  PAGED_CODE();
  ASSERT( PASSIVE_LEVEL == KeGetCurrentIrql());
  ASSERT( NULL != pDeviceObject);
  ASSERT( NULL != pIrp);

  Driver_SetDevice( pDeviceObject);
  TRACE( 9, ("DriverControl(%p,%p)\n",pDeviceObject,pIrp));

  pDeviceExtension = (PDEVICE_EXTENSION)pDeviceObject->DeviceExtension;
  ASSERT( kMagic == pDeviceExtension->eMagic);

  if ( pDeviceExtension->bClosing)
    {
    pIrp->IoStatus.Status = status = STATUS_DELETE_PENDING;
    IoCompleteRequest( pIrp, IO_NO_INCREMENT);
    return status;
    }

  IoIncrement( pDeviceObject);
  pIrp->IoStatus.Information = 0;

  /* CAUTION: NT ioctl's using METHOD_BUFFERED have a single buffer
   * for both input & output */

  /* Get a pointer to the current I/O stack location */
  pioStack = IoGetCurrentIrpStackLocation( pIrp);
  pFileObject = pioStack->FileObject;
  ASSERT( NULL != pFileObject);

  switch ( pioStack->Parameters.DeviceIoControl.IoControlCode)
    {
  default:
    TRACE( 1, ("*DriverControl() invalid code\n"));
    status = STATUS_INVALID_DEVICE_REQUEST;
    break;

  case IOCTL_GETMACADDR:
    if ( pioStack->Parameters.DeviceIoControl.OutputBufferLength < 6
      || NULL == pIrp->AssociatedIrp.SystemBuffer
    ) {
      TRACE( 1, ("*DriverControl(GETMACADDR) output buffer too small\n"));
      status = STATUS_BUFFER_TOO_SMALL;
      }
    else if ( !pDeviceExtension->adapterInfo.pfnGetMacAddr)
      {
      status = STATUS_INVALID_DEVICE_REQUEST;
      }
    else
      {
      pIrp->IoStatus.Information = 6;
      status = (*pDeviceExtension->adapterInfo.pfnGetMacAddr)(
        pDeviceExtension->pvContext,
        pFileObject->FsContext,
        pIrp->AssociatedIrp.SystemBuffer
      );
      }
    break;

  case IOCTL_SETMULTICASTLIST:
    /* NB the list maybe empty if no memberships */
    if ( !pDeviceExtension->adapterInfo.pfnSetMulticastList)
      {
      status = STATUS_INVALID_DEVICE_REQUEST;
      }
    else
      {
      pIrp->IoStatus.Information = pioStack->Parameters.DeviceIoControl.InputBufferLength;
      status = (*pDeviceExtension->adapterInfo.pfnSetMulticastList)(
        pDeviceExtension->pvContext,
        pFileObject->FsContext,
        pIrp->AssociatedIrp.SystemBuffer,
        pioStack->Parameters.DeviceIoControl.InputBufferLength
      );
      }
    break;

  case IOCTL_GETMULTICASTLIST:
    if ( NULL == pIrp->AssociatedIrp.SystemBuffer)
      {
      TRACE( 1, ("*DriverControl(GETMULTICASTLIST) output buffer too small\n"));
      status = STATUS_BUFFER_TOO_SMALL;
      }
    else if ( !pDeviceExtension->adapterInfo.pfnGetMulticastList)
      {
      status = STATUS_INVALID_DEVICE_REQUEST;
      }
    else
      {
      uLen = pioStack->Parameters.DeviceIoControl.OutputBufferLength;

      status = (*pDeviceExtension->adapterInfo.pfnGetMulticastList)(
        pDeviceExtension->pvContext,
        pFileObject->FsContext,
        pIrp->AssociatedIrp.SystemBuffer,
        &uLen
      );
      pIrp->IoStatus.Information = uLen;
      }
    break;

  case IOCTL_SETPROMISCUITY:
    if ( pioStack->Parameters.DeviceIoControl.InputBufferLength < sizeof(BYTE)
      || NULL == pIrp->AssociatedIrp.SystemBuffer
    ) {
      TRACE( 1, ("*DriverControl(SETPROMISCUITY) input buffer too small\n"));
      status = STATUS_BUFFER_TOO_SMALL;
      }
    else if ( !pDeviceExtension->adapterInfo.pfnSetPromiscuity)
      {
      status = STATUS_INVALID_DEVICE_REQUEST;
      }
    else
      {
      pIrp->IoStatus.Information = sizeof(BYTE);
      status = (*pDeviceExtension->adapterInfo.pfnSetPromiscuity)(
        pDeviceExtension->pvContext,
        pFileObject->FsContext,
        *(BYTE*)pIrp->AssociatedIrp.SystemBuffer
      );
      }
    break;

  case IOCTL_WRITE_SCATTER:
    if ( NULL == pIrp->MdlAddress
#if DBG && DDK_VERSION >= 50 && !defined BINARY_COMPATIBLE
      || NULL == (pvBuf = MmGetSystemAddressForMdlSafe( pIrp->MdlAddress, LowPagePriority))
#else
      || NULL == (pvBuf = MmGetSystemAddressForMdl( pIrp->MdlAddress))
#endif
    ) {
      TRACE( 1, ("*DriverControl(WRITE_SCATTER) No scatter list\n"));
      status = STATUS_BUFFER_TOO_SMALL;
      }
    else if ( !pDeviceExtension->adapterInfo.pfnWriteScatter)
      {
      status = STATUS_INVALID_DEVICE_REQUEST;
      }
    else
      {
      unsigned long ulTransferred;

      ulTransferred = MmGetMdlByteCount( pIrp->MdlAddress);

      IoIncrement( pDeviceObject);
      IoMarkIrpPending( pIrp);
#pragma warning( disable : 4055) /* 'type cast' : from data pointer to function pointer */
#pragma warning( disable : 4054) /* 'type cast' : from function pointer to data pointer */
      IoSetCancelRoutine( pIrp, &DriverCancel);
#pragma warning( default : 4054)
#pragma warning( default : 4055)

      ASSERT( pDeviceExtension->adapterInfo.pfnCancel); 
      status = (*pDeviceExtension->adapterInfo.pfnWriteScatter)(
        pDeviceExtension->pvContext,
        pFileObject->FsContext,
        pIrp,
        pvBuf,
        &ulTransferred
      );
      if ( STATUS_PENDING != status)
        Driver_CompleteRequest( pIrp, status, ulTransferred );

      Driver_SetDevice( NULL);
      return STATUS_PENDING;
      }
    break;

  case IOCTL_GETINFO:
    if ( pioStack->Parameters.DeviceIoControl.OutputBufferLength < sizeof( IOCTL_INFO)
      || NULL == pIrp->AssociatedIrp.SystemBuffer
    ) {
      TRACE( 1, ("*DriverControl(GETINFO) output buffer too small\n"));
      status = STATUS_BUFFER_TOO_SMALL;
      }
    else if ( !pDeviceExtension->adapterInfo.pfnGetInfo)
      {
      status = STATUS_INVALID_DEVICE_REQUEST;
      }
    else
      {
      pIrp->IoStatus.Information = sizeof( IOCTL_INFO);
      status = (*pDeviceExtension->adapterInfo.pfnGetInfo)(
        pDeviceExtension->pvContext,
        pIrp->AssociatedIrp.SystemBuffer
      );
      }
    break;

  case IOCTL_GETDESC:
    if ( NULL == pIrp->AssociatedIrp.SystemBuffer)
      {
      TRACE( 1, ("*DriverControl(IOCTL_GETDESC) output buffer too small\n"));
      status = STATUS_BUFFER_TOO_SMALL;
      }
    else if ( !pDeviceExtension->adapterInfo.pfnGetDesc)
      {
      status = STATUS_INVALID_DEVICE_REQUEST;
      }
    else
      {
      uLen = pioStack->Parameters.DeviceIoControl.OutputBufferLength;

      status = (*pDeviceExtension->adapterInfo.pfnGetDesc)(
        pDeviceExtension->pvContext,
        pIrp->AssociatedIrp.SystemBuffer,
        &uLen
      );
      pIrp->IoStatus.Information = uLen;
      }
    break;
    }

  ASSERT( STATUS_PENDING != status);
  pIrp->IoStatus.Status = status;
  IoCompleteRequest( pIrp, IO_NO_INCREMENT);
  IoDecrement( pDeviceObject);

  Driver_SetDevice( NULL);
  return status;
  }


/*
 * Handle request cancellation
 *
 * IRQL DISPATCH_LEVEL
 */
VOID DriverCancel(
  IN PDEVICE_OBJECT pDeviceObject,
  IN PIRP pIrp
) {
  DEVICE_EXTENSION* pDeviceExtension;
  PFILE_OBJECT pFileObject = IoGetCurrentIrpStackLocation( pIrp)->FileObject;

  ASSERT( NULL != pDeviceObject);
  ASSERT( NULL != pIrp);

  Driver_SetDevice( pDeviceObject);
  TRACE( 4, ("DriverCancel(%p,%p)\n",pDeviceObject,pIrp));

  pDeviceExtension = (PDEVICE_EXTENSION)pDeviceObject->DeviceExtension;
  ASSERT( kMagic == pDeviceExtension->eMagic);

  IoReleaseCancelSpinLock( pIrp->CancelIrql);

  if ( !pDeviceExtension->bClosing)
    {
    ASSERT( pDeviceExtension->adapterInfo.pfnCancel);
    (*pDeviceExtension->adapterInfo.pfnCancel)(
      pDeviceExtension->pvContext,
      NULL != pFileObject ? pFileObject->FsContext : NULL,
      pIrp
    );
    }

  Driver_SetDevice( NULL);
  }

  
/****************************************************************
 * TRACE output
 ****************************************************************/

#ifdef DEBUG_TRACE_LEVEL
/*
 * Get debug level & initial break condition from registry
 *
 * IRQL PASSIVE_LEVEL
 */
#ifdef ALLOC_PRAGMA
#pragma alloc_text( INIT, GetDebugLevel)
#endif
int GetDebugLevel(
  IN PUNICODE_STRING pRegistryPath      /* -> Unicode registry path */
) {
  NTSTATUS Status;
  RTL_QUERY_REGISTRY_TABLE ParamTable[4];
  ULONG ulZero = 0;
  ULONG ulDebugLevel, ulCurrentDebugLevel = (ULONG)DEBUG_TRACE_LEVEL;
  ULONG ulBreak = 0;
    
  ASSERT( PASSIVE_LEVEL == KeGetCurrentIrql());
  RtlZeroMemory( ParamTable, sizeof(ParamTable));

  /* change to the parmeters key */
  ParamTable[0].QueryRoutine = NULL;
  ParamTable[0].Flags = RTL_QUERY_REGISTRY_SUBKEY;
  ParamTable[0].Name = (PWSTR)kwsParameters;

  ParamTable[1].QueryRoutine = 0;
  ParamTable[1].Flags = RTL_QUERY_REGISTRY_DIRECT;
  ParamTable[1].Name = (PWSTR)L"DebugBreak";
  ParamTable[1].EntryContext =&ulBreak;
  ParamTable[1].DefaultType = REG_DWORD;
  ParamTable[1].DefaultData = &ulZero;
  ParamTable[1].DefaultLength = sizeof( ulZero);

  ParamTable[2].QueryRoutine = 0;
  ParamTable[2].Flags = RTL_QUERY_REGISTRY_DIRECT;
  ParamTable[2].Name = (PWSTR)L"DebugLevel";
  ParamTable[2].EntryContext =&ulDebugLevel;
  ParamTable[2].DefaultType = REG_DWORD;
  ParamTable[2].DefaultData = &ulCurrentDebugLevel;
  ParamTable[2].DefaultLength = sizeof( ulCurrentDebugLevel);

  Status = RtlQueryRegistryValues(
    RTL_REGISTRY_ABSOLUTE | RTL_REGISTRY_OPTIONAL,
    pRegistryPath->Buffer,
    &ParamTable[ 0],
    NULL,
    NULL
  );
  if ( NT_SUCCESS( Status))
    {
    if ( ulBreak)
      {
      DbgBreakPoint();
      }

    return (int)ulDebugLevel;
    }

  return (int)DEBUG_TRACE_LEVEL;
  }
#endif


/*
 * Debug trace handler
 */
void TraceLog( const char* psz)
  {
  if ( NULL == psz)
    return;

  /* Send to debugger */
  KdPrint(( IOCTL_DEVICE ": %s", psz));

#if 1
  {
  PIO_ERROR_LOG_PACKET pLog;
  size_t size;
  ANSI_STRING saText;

  /* BUGBUG on Win2k(checked) IoAllocateErrorLogEntry asserts:
   *  'EX: Pageable code called at IRQL 2' (2= DISPATCH_LEVEL).
   * But MSDN says IoAllocateErrorLogEntry & IoWriteErrorLogEntry OK at <= DISPATCH_LEVEL
   */
  if ( KeGetCurrentIrql() > APC_LEVEL /*DISPATCH_LEVEL*/)
    return;

  /* Calc. log packet size */
  RtlInitAnsiString( &saText, psz);
  size = sizeof( *pLog) - sizeof(pLog->DumpData)
#if 0 /* BUGBUG NT4 DDK fails to compile RtlAnsiStringToUnicodeSize: "sizeof((UCHAR)NULL))" */
    + RtlAnsiStringToUnicodeSize( &saText);
#else
    + (saText.Length + sizeof('\0')) * sizeof(WCHAR);
#endif
  if ( size > ERROR_LOG_MAXIMUM_SIZE)
    {
    /* Truncate the string */
    saText.MaximumLength = saText.Length =
      (ERROR_LOG_MAXIMUM_SIZE - sizeof( *pLog)
        + sizeof(pLog->DumpData)) / sizeof( WCHAR) - 1;
    size = ERROR_LOG_MAXIMUM_SIZE;
    }

  /* Allocate event log packet */
  pLog = (PIO_ERROR_LOG_PACKET) IoAllocateErrorLogEntry(
    NULL != s_pCurrentDeviceObject ? (PVOID)s_pCurrentDeviceObject :
      NULL != s_pDeviceObject ? (PVOID)s_pDeviceObject : (PVOID)s_pDriverObject,
    (UCHAR)size
  );
  if ( NULL != pLog)
    {
    UNICODE_STRING suText;

    RtlZeroMemory( pLog, sizeof(IO_ERROR_LOG_PACKET));

    pLog->FinalStatus = STATUS_SUCCESS;
    if ( '!' == *psz)
      pLog->ErrorCode = TRACELOG_ERROR_MSG;       /* format %1: ERROR: %2. */
    else if ( '*' == *psz)
      pLog->ErrorCode = TRACELOG_WARNING_MSG;     /* format %1: WARNING: %2. */
    else
      pLog->ErrorCode = TRACELOG_INFORMATION_MSG; /* format %1: %2. */

    pLog->NumberOfStrings = 1;
    pLog->StringOffset = FIELD_OFFSET( IO_ERROR_LOG_PACKET, DumpData);

    /* Append string */
    suText.Length = 0;
    suText.MaximumLength = (USHORT)(size - sizeof( *pLog) + sizeof(pLog->DumpData));
    suText.Buffer = (PWSTR)pLog->DumpData;
    RtlAnsiStringToUnicodeString( &suText, &saText, FALSE);

    /* Add to event log */
    IoWriteErrorLogEntry( pLog);
    }
  }
#endif
  }

/* End of file */
