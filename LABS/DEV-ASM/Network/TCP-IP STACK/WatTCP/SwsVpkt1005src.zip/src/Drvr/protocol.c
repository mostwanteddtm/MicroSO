/****************************************************************************
 * protocol.c                                                               *
 * Purpose:     NDIS protocol driver module                                 *
 *              Provides network I/O for the virtual packet driver          *
 *                                                                          *
 * Created by Lawrence Rust, Software Systems Consultants                   *
 * lvr@softsystem.co.uk. Tel/Fax +33 5 49 72 79 63                          *
 *                                                                          *
 * Runtime:     Windows NT 4.0, 2000, XP                                    *
 *__________________________________________________________________________*
 *                                                                          *
 * Revision History:                                                        *
 *                                                                          *
 * No.   Date     By   Reason                                               *
 *--------------------------------------------------------------------------*
 * 100 21 Mar 03  lvr  Created                                              *
 * 101 03 Aug 04  lvr  Added WAN                                            *
 * 102 04 Jun 05  lvr  Support multiple opens                               *
 * 103 29 Jun 05  lvr  Added DeviceGetInfo                                  *
 * 104 06 Sep 05  lvr  Replace NdisInterlockedRemoveHeadList with           *
 *                      RemoveHeadList in ReleaseResources for passive use  *
 * 105 14 Oct 05  lvr  Count multicast clients                              *
 *                      Multicast adddress of ff.. enables all m/cast       *
 * 106 27 Oct 05  lvr  ProtocolReceive doesnt use DPR functions             *
 * 107 18 May 06  lvr  Add DeviceGetDesc                                    *
 *__________________________________________________________________________*/

/* Quieten VC++ level 4 warnings about the DDK */
#pragma warning( disable : 4201) /* nonstandard extension used : nameless struct/union */
#pragma warning( disable : 4214) /* nonstandard extension used : bit field types other than int */
#pragma warning( disable : 4115) /* named type definition in parentheses */
#pragma warning( disable : 4514) /* unreferenced inline function has been removed */
/* File specific warnings */
#pragma warning( disable : 4127) /* conditional expression is constant */
#pragma warning( disable : 4710) /* function not expanded */
#if DDK_VERSION == 41
#pragma warning( disable : 4057) /* slightly different base types */
#endif

#ifndef OPT_DPR
#define OPT_DPR 0 /* !0 to use DPR optimised functions */
#endif


/* Exports */
#include "protocol.h"


/* Imports */
/* ANSI */

/* NT DDK */
#ifdef __cplusplus
extern "C" {
#endif
#include <ndis.h>
#if DDK_VERSION == 40 && !defined BINARY_COMPATIBLE
#include <tdikrnl.h> /* NT4: TdiCopyLookaheadData */
#endif
#ifdef __cplusplus
}
#endif

/* Project specific */
#include "driver.h" /* Device registration */
#include "ioctls.h"
#include "debug.h"


/*
 * Macros & constants
 */
#if !defined NDIS_MAJOR_VERSION
 #if NDIS50
  #define NDIS_MAJOR_VERSION 5
  #define NDIS_MINOR_VERSION 0
 #elif NDIS41
  #define NDIS_MAJOR_VERSION 4
  #define NDIS_MINOR_VERSION 1
 #elif NDIS40
  #define NDIS_MAJOR_VERSION 4
  #define NDIS_MINOR_VERSION 0
 #else
  #define NDIS_MAJOR_VERSION 3
  #define NDIS_MINOR_VERSION 0
 #endif
#endif


/* Runtime configuration */
#define kwszPackets L"Packets"
#define kPacketPoolSize 128    /* Min packet pool size */
#define kPacketPoolMax  0xffff /* Max packet pool size */

#define kwszBuffers L"Buffers"
#define kBufferPoolSize 128  /* NDIS buffer pool size */

#define kwszAllLocal L"AllLocal" /* Receive all local packets sent */
#define kwszWanAllLocal L"WanAllLocal" /* Receive all local WAN packets sent */
#define kwszWanMedia L"WanEnable" /* Bind WAN media */

/* Length of an array - sorely missing from stddef.h */
#ifndef lengthof
#define lengthof( _a) ((unsigned)( sizeof(_a)/sizeof((_a)[0]) ))
#endif

#define kEthernetHeader 14
#define kEthernetData 1500

#if DDK_VERSION == 40 /* NT4 */
#define NdisAllocatePacketPoolEx(a,b,c,d,e) NdisAllocatePacketPool(a,b,c,e)
LONG FASTCALL InterlockedIncrement( IN PLONG Addend);
LONG FASTCALL InterlockedDecrement( IN PLONG Addend);
#define	NdisInterlockedIncrement(Addend)	InterlockedIncrement(Addend)
#define	NdisInterlockedDecrement(Addend)	InterlockedDecrement(Addend)
#endif /* DDK_VERSION == 40 */

#if DDK_VERSION == 41 /* Win98 */
#define NdisInterlockedIncrement(_p) ++(*(_p))
#define NdisInterlockedDecrement(_p) --(*(_p))
#define NdisAllocatePacketPoolEx(a,b,c,d,e) NdisAllocatePacketPool(a,b,c,e)
#define NdisInitializeListHead(_ListHead) InitializeListHead(_ListHead)

#ifndef STATUS_PENDING
#define STATUS_PENDING                0x00000103L
#endif
#ifndef STATUS_BUFFER_TOO_SMALL
#define STATUS_BUFFER_TOO_SMALL       0xC0000023L
#endif
#ifndef STATUS_INSUFFICIENT_RESOURCES
#define STATUS_INSUFFICIENT_RESOURCES 0xC000009AL
#endif
#ifndef STATUS_CANCELLED
#define STATUS_CANCELLED              0xC0000120L
#endif
#ifndef STATUS_INVALID_DEVICE_REQUEST
#define STATUS_INVALID_DEVICE_REQUEST 0xC0000010L
#endif
#ifndef STATUS_NETWORK_BUSY
#define STATUS_NETWORK_BUSY           0xC00000BFL
#endif
#ifndef STATUS_DEVICE_POWERED_OFF
#define STATUS_DEVICE_POWERED_OFF     0x8000000FL
#endif
#endif /* DDK_VERSION == 41 */

#if DDK_VERSION == 50 /* Win2k */ && defined BINARY_COMPATIBLE
#define NdisAllocatePacketPoolEx(a,b,c,d,e) NdisAllocatePacketPool(a,b,c,e)
#endif

/* Memory type used for binding instance */
#define kMemoryType ((0*NDIS_MEMORY_CONTIGUOUS) | (0*NDIS_MEMORY_NONCACHED))


/*
 * Types
 */
enum EMagic { kMagic = 'sskp' };

/* Binding instance data */
typedef struct  SBindingInstance
  {
  enum EMagic eMagic;                   /* For assert checks */

  NDIS_HANDLE       hAdapter;           /* NDIS open adapter */
  UINT              MediumIndex;        /* Index to s_pMedia */

#if DBG && DDK_VERSION >= 50 && !defined BINARY_COMPATIBLE
  NDIS_STRING       nsAdapterName;      /* Friendly name */
#endif

  BOOLEAN           bBinding;           /* NdisComplete(un)BindAdapter required */
  NDIS_HANDLE       BindContext;        /* (Un)BindAdapter context */

  NDIS_HANDLE       hPacketPool;
  NDIS_HANDLE       hBufferPool;

  NDIS_SPIN_LOCK    ClientSpinLock;     /* Protect ClientList */
  LIST_ENTRY        ClientList;         /* List of SClient */

#ifdef NDIS_PACKET_TYPE_ALL_LOCAL
  BOOLEAN           bAllLocal;
  BOOLEAN           bWanAllLocal;
#endif

  BOOLEAN           bMediaDisconnected;
  BOOLEAN           bWanDown;
  BOOLEAN           bResetInProgress;   /* Adapter reset in progress */
  BOOLEAN           bPowerOn;           /* Adapter is powered */
  ULONG             ulReceiveFilter;

  struct _DEVICE_OBJECT* pDeviceObject;
  LONG              lRefs;              /* Number of opens */
  LONG              lPromiscuousClients; 
  LONG              lMulticastClients;

  /* Per adapter stats */
  ULONG             ulRxPackets;
  ULONG             ulRxBytes;
  ULONG             ulRxPacketsDropped;
  ULONG             ulRxErrors;
  ULONG             ulTxPackets;
  ULONG             ulTxBytes;
  ULONG             ulTxPacketsDropped;
  ULONG             ulTxErrors;
  } SBindingInstance;

/* Open client handle instance */
typedef struct SClient
  {
  enum EMagic eMagic;                   /* For assert checks */

  LIST_ENTRY        ListElement;        /* List of SClient */

  NDIS_SPIN_LOCK    RecvSpinLock;       /* Protect RecvList */
  LIST_ENTRY        RecvList;           /* List of SPacketReserved */

  BOOLEAN           bPromiscuous;
  BOOLEAN           bMulticast;

  /* Per client stats */
  ULONG             ulRxPackets;
  ULONG             ulRxBytes;
  ULONG             ulRxPacketsDropped;
  ULONG             ulRxPacketsRejected;
  ULONG             ulRxErrors;
  ULONG             ulTxPackets;
  ULONG             ulTxBytes;
  ULONG             ulTxPacketsDropped;
  ULONG             ulTxErrors;
  } SClient;

/* NDIS_PACKET private data */
typedef struct SPacketReserved
  {
  LIST_ENTRY     ListElement;
  struct _IRP*   pIrp;
  void*          pvBuf;
  unsigned long  ulBuf;
  SClient*       pClient;
  } SPacketReserved;

/* Convert PNDIS_PACKET to SPacketReserved */
#define RESERVED(_p) ((SPacketReserved*)((_p)->ProtocolReserved))

/* NDIS_REQUEST wrapper */
typedef struct SRequest
  {
  NDIS_REQUEST Request;
  NDIS_EVENT   Event;
  NDIS_STATUS  Status;
  } SRequest;


/*
 * Function prototypes
 */
#ifdef __cplusplus
extern "C" {
#endif

static VOID ProtocolBindAdapter(
  OUT PNDIS_STATUS  Status,
  IN  NDIS_HANDLE   BindContext,
  IN  PNDIS_STRING  DeviceName,
  IN  PVOID         SystemSpecific1,
  IN  PVOID         SystemSpecific2
);

static VOID ProtocolUnbindAdapter(
  OUT PNDIS_STATUS  Status,
  IN  NDIS_HANDLE   ProtocolBindingContext,
  IN  NDIS_HANDLE   UnbindContext
);

static VOID ProtocolOpenAdapterComplete(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN NDIS_STATUS    Status,
  IN NDIS_STATUS    OpenErrorStatus
);

static VOID ProtocolCloseAdapterComplete(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN NDIS_STATUS    Status
);

static NDIS_STATUS ProtocolReceiveIndicate(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN NDIS_HANDLE    MacReceiveContext,
  IN PVOID          HeaderBuffer,
  IN UINT           HeaderBufferSize,
  IN PVOID          LookAheadBuffer,
  IN UINT           LookAheadBufferSize,
  IN UINT           ProtocolSize
);

static VOID ProtocolReceiveComplete(
  IN NDIS_HANDLE    ProtocolBindingContext
);

static VOID ProtocolRequestComplete(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN PNDIS_REQUEST  pRequest,
  IN NDIS_STATUS    Status
);

static VOID ProtocolSendComplete(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN PNDIS_PACKET   pProtocol,
  IN NDIS_STATUS    Status
);

static VOID ProtocolResetComplete(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN NDIS_STATUS    Status
);

static VOID ProtocolStatus(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN NDIS_STATUS    Status,
  IN PVOID          StatusBuffer,
  IN UINT           StatusBufferSize
);

static VOID ProtocolStatusComplete(
  IN NDIS_HANDLE    ProtocolBindingContext
);

static VOID ProtocolTransferDataComplete(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN PNDIS_PACKET   Protocol,
  IN NDIS_STATUS    Status,
  IN UINT           BytesTransferred
);

#if NDIS_MAJOR_VERSION >= 4
static INT ProtocolReceivePacket(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN PNDIS_PACKET   Packet
);
#endif

#if DDK_VERSION >= 50
static NDIS_STATUS ProtocolPNPHandler(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN PNET_PNP_EVENT pNetPnPEvent
);
#endif

static Driver_FOpen  DeviceOpen;
static Driver_FClose DeviceClose;
static Driver_FRead  DeviceRead;
static Driver_FWrite DeviceWrite;
static Driver_FCancel DeviceCancel;
static Driver_FGetMacAddr DeviceGetMacAddr;
static Driver_FSetMcastList DeviceSetMulticastList;
static Driver_FSetPromiscuity DeviceSetPromiscuity;
static Driver_FGetInfo DeviceGetInfo;
static Driver_FGetDesc DeviceGetDesc;
static Driver_FGetMcastList DeviceGetMulticastList;

static void ReleaseResources( SBindingInstance*);
static void ReleaseClient( SClient*);
static NDIS_STATUS CloseAdapter( SBindingInstance*);
static NDIS_STATUS SyncNdisRequest( SBindingInstance*, SRequest*);

#ifdef __cplusplus
}
#endif


/*
 * Module data
 */
static const NDIS_PHYSICAL_ADDRESS kHighestAcceptableMax =
  NDIS_PHYSICAL_ADDRESS_CONST( -1, -1);

static const Driver_SDeviceInfo s_info = {
  &DeviceOpen,
  &DeviceClose,
  &DeviceRead,
  &DeviceWrite,
  &DeviceCancel,
  &DeviceGetMacAddr,
  &DeviceSetMulticastList,
  &DeviceGetMulticastList,
  &DeviceSetPromiscuity,
  0, /* TODO: Driver_FWriteScatter */
  &DeviceGetInfo,
  &DeviceGetDesc
};

/* The protocol handle */
static NDIS_HANDLE s_hProtocol;

/* Supported media types */
static NDIS_MEDIUM s_aMediaWan[] = {
  NdisMediumDix, NdisMedium802_3, NdisMediumWan, NdisMediumWirelessWan
};
#define IsWAN( p) (NdisMediumWan == s_pMedia[ (p)->MediumIndex] \
  || NdisMediumWirelessWan == s_pMedia[ (p)->MediumIndex] )
#define IsEthernet( p) (NdisMediumDix == s_pMedia[ (p)->MediumIndex] \
  || NdisMedium802_3 == s_pMedia[ (p)->MediumIndex] )

static NDIS_MEDIUM s_aMediaLan[] = {
  NdisMediumDix, NdisMedium802_3
};
static PNDIS_MEDIUM s_pMedia;
static UINT s_uMedia;


/*
 * Install the protocol
 */
#pragma NDIS_INIT_FUNCTION( ProtocalInstall)
int ProtocalInstall( void)
  {
  /* Make sure the protocol name matches the service name under which this
   * protocol is installed. This is needed to ensure that NDIS can correctly
   * determine the binding and bind to miniports below.
   * NB Underscores are removed by NDIS
   */
  const NDIS_STRING snName = NDIS_STRING_CONST( "SwsVpkt");
  NDIS_STATUS status;
  NDIS_PROTOCOL_CHARACTERISTICS PChars;

  TRACE( 9, ("ProtocalInstall()\n"));

  /* NDIS protocol descriptor */
  NdisZeroMemory( &PChars, sizeof(PChars) );
  PChars.MajorNdisVersion = NDIS_MAJOR_VERSION;
  PChars.MinorNdisVersion = NDIS_MINOR_VERSION;
  PChars.OpenAdapterCompleteHandler   = &ProtocolOpenAdapterComplete;
  PChars.CloseAdapterCompleteHandler  = &ProtocolCloseAdapterComplete;
  PChars.SendCompleteHandler          = &ProtocolSendComplete; /* WAN */
  PChars.TransferDataCompleteHandler  = &ProtocolTransferDataComplete; /* WAM */
  PChars.ResetCompleteHandler         = &ProtocolResetComplete;
  PChars.RequestCompleteHandler       = &ProtocolRequestComplete;
  PChars.ReceiveHandler               = &ProtocolReceiveIndicate; /* WAN */
  PChars.ReceiveCompleteHandler       = &ProtocolReceiveComplete;
  PChars.StatusHandler                = &ProtocolStatus;
  PChars.StatusCompleteHandler        = &ProtocolStatusComplete;
  PChars.Name                         = snName;
  /* NDIS4.0 */
#if NDIS_MAJOR_VERSION >= 4
  PChars.ReceivePacketHandler         = &ProtocolReceivePacket;
#endif
  PChars.BindAdapterHandler           = &ProtocolBindAdapter;
  PChars.UnbindAdapterHandler         = &ProtocolUnbindAdapter;
#if NDIS_MAJOR_VERSION >= 4 && DDK_VERSION >= 50
  PChars.PnPEventHandler              = &ProtocolPNPHandler;
#endif
#if NDIS_MAJOR_VERSION >= 4
  PChars.UnloadHandler                = &ProtocolUnload;
#elif NDIS_MAJOR_VERSION == 3 && NDIS_MINOR_VERSION >= 0x0a /* Win98 DDK */
  PChars.UnloadProtocolHandler        = &ProtocolUnload;
#endif

  /* Register the protocol */
  NdisRegisterProtocol( &status, &s_hProtocol, &PChars, sizeof(PChars) );
  if ( NDIS_STATUS_SUCCESS != status)
    {
    TRACE( 0, ("!NdisRegisterProtocol failed %#x\n", status));
    return status;
    }
  ASSERT( NULL != s_hProtocol);

  return NDIS_STATUS_SUCCESS;
  }


/*
 * Uninstall the protocol driver
 *
 * IRQL PASSIVE_LEVEL
 */
void ProtocolUnload( void)
  {
  NDIS_STATUS Status;

  Driver_SetDevice( NULL);
  TRACE( 3, ("ProtocolUnload()\n"));

  if ( NULL != s_hProtocol)
    {
    NDIS_HANDLE hProtocol = s_hProtocol;
    s_hProtocol = NULL;
    NdisDeregisterProtocol( &Status, hProtocol);
    }
  }


/*
 * NDIS protocol callback to bind to an adapter
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma NDIS_PAGEABLE_FUNCTION( ProtocolBindAdapter)
VOID ProtocolBindAdapter(
  OUT PNDIS_STATUS  pStatus,
  IN  NDIS_HANDLE   BindContext,
  IN  PNDIS_STRING  pDeviceName,
  IN  PVOID         SystemSpecific1,
  IN  PVOID         SystemSpecific2
) {
  NDIS_STATUS status, openStatus;
  SBindingInstance* pBinding;
  unsigned long ulVal;
  (void)SystemSpecific1;
  (void)SystemSpecific2;

  ASSERT( NULL != pStatus);
  ASSERT( NULL != pDeviceName);
  ASSERT( NULL != SystemSpecific1);

  Driver_SetDevice( NULL);
  TRACE( 9, ("ProtocolBindAdapter(%ls,%ls,%p)\n",
    pDeviceName->Buffer,
    ((PNDIS_STRING)SystemSpecific1)->Buffer,SystemSpecific2
  ));

  /* Allocate non-paged instance data */
  status = NdisAllocateMemory(
    (PVOID*)&pBinding, sizeof( *pBinding),
    kMemoryType,
    kHighestAcceptableMax
  );
  if ( NDIS_STATUS_SUCCESS != status)
    {
    TRACE( 0, ("!ProtocolBindAdapter out of memory (%#x)\n",status));
    *pStatus = status;
    return;
    }
  NdisZeroMemory( pBinding, sizeof( *pBinding) );
  pBinding->eMagic = kMagic;

  NdisAllocateSpinLock( &pBinding->ClientSpinLock);
  NdisInitializeListHead( &pBinding->ClientList);

  /* Get configured no. packets */
  if ( !Driver_ReadParamDword( kwszPackets, &ulVal) || ulVal < 1)
    ulVal = kPacketPoolSize;

  /* Allocate packet pool for xmit and receive packets */
  NdisAllocatePacketPoolEx(
    &status,
    &pBinding->hPacketPool,
    (UINT)ulVal,
    kPacketPoolMax - (UINT)ulVal,
    sizeof( SPacketReserved)
  );
  if ( NDIS_STATUS_SUCCESS != status)
    {
    TRACE( 0, ("!NdisAllocatePacketPool(%u) failed %#x\n",
      (UINT)ulVal,status));
    *pStatus = status;
    ReleaseResources( pBinding);
    return;
    }

  /* Get configured no. buffers */
  if ( !Driver_ReadParamDword( kwszBuffers, &ulVal) || ulVal < 1)
    ulVal = kBufferPoolSize;

  /* Allocate buffer pool */
  NdisAllocateBufferPool( pStatus, &pBinding->hBufferPool, (UINT)ulVal);
  if ( NDIS_STATUS_SUCCESS != *pStatus)
    {
    TRACE( 0, ("!NdisAllocateBufferPool(%u) failed %#x\n",
      (UINT)ulVal,*pStatus));
    ReleaseResources( pBinding);
    return;
    }

  /* Are we supporting WAN media? */
  ulVal = 0;
  if ( Driver_ReadParamDword( kwszWanMedia, &ulVal)
    && 0 != ulVal
  ) {
    /* WAN supported */
    s_pMedia = s_aMediaWan;
    s_uMedia = lengthof( s_aMediaWan);
    }
  else
    {
    /* LAN only */
    s_pMedia = s_aMediaLan;
    s_uMedia = lengthof( s_aMediaLan);
    }

  /* Open the bound adapter */
  TRACE( 2, ("OpenAdapter %p %ls\n",pBinding,pDeviceName->Buffer));
  pBinding->BindContext = BindContext;
  pBinding->bBinding = TRUE;
  openStatus = NDIS_STATUS_SUCCESS;
  NdisOpenAdapter(
    pStatus,                            /* OUT: Result */
    &openStatus,                        /* OUT: error info */
    &pBinding->hAdapter,                /* OUT: NDIS binding handle */
    &pBinding->MediumIndex,             /* OUT: Index of medium selected */
    s_pMedia, s_uMedia,                 /* IN: Media required */
    s_hProtocol,                        /* IN: Protocol handle */
    pBinding,                           /* IN: protocol binding context */
    pDeviceName,                        /* IN: Adapter name */
    0,                                  /* IN: Open options */
    NULL                                /* IN: PSTRING Addressing info */
  );
  if ( NDIS_STATUS_PENDING != *pStatus)
    {
    pBinding->bBinding = FALSE;
    ProtocolOpenAdapterComplete( pBinding, *pStatus, openStatus);
    }
  }


/*
 * Release resources allocated for a binding
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma NDIS_PAGEABLE_FUNCTION( ReleaseResources)
void ReleaseResources( SBindingInstance* pBinding)
  {
  PLIST_ENTRY ple;

  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);
  TRACE( 9, ("ReleaseResources(%p)\n",pBinding));

  pBinding->eMagic = 0;

  if ( NULL != pBinding->hBufferPool)
    NdisFreeBufferPool( pBinding->hBufferPool);
  
  if ( NULL != pBinding->hPacketPool)
    NdisFreePacketPool( pBinding->hPacketPool);

#if DBG && DDK_VERSION >= 50 && !defined BINARY_COMPATIBLE
  if ( NULL != pBinding->nsAdapterName.Buffer)
    {
    NdisFreeMemory(
      pBinding->nsAdapterName.Buffer,
      pBinding->nsAdapterName.MaximumLength,
      0
    );
    }
#endif

  /* Release any remaining client instances */
  while ( !IsListEmpty( &pBinding->ClientList) )
    {
    SClient* pClient;

    ple = RemoveHeadList( &pBinding->ClientList);
    pClient = CONTAINING_RECORD( ple, SClient, ListElement);
    ReleaseClient( pClient);
    }

  NdisFreeSpinLock( &pBinding->ClientSpinLock);
  NdisFreeMemory( pBinding, sizeof(*pBinding), kMemoryType);
  }


/*
 * NdisOpenAdapter completion call-back
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma NDIS_PAGEABLE_FUNCTION( ProtocolOpenAdapterComplete)
VOID ProtocolOpenAdapterComplete(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN NDIS_STATUS    Status,
  IN NDIS_STATUS    OpenErrorStatus
) {
  SBindingInstance* const pBinding = (SBindingInstance*)ProtocolBindingContext;
  NDIS_HANDLE BindContext;
  BOOLEAN bBinding;

  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);
  TRACE( 9, ("ProtocolOpenAdapterComplete(%p,%#x,%#x)\n",
    ProtocolBindingContext,Status,OpenErrorStatus));

  BindContext = pBinding->BindContext;
  bBinding = pBinding->bBinding;
  pBinding->bBinding = FALSE;

  if ( NDIS_STATUS_SUCCESS != Status)
    {
    switch ( Status)
      {
    case NDIS_STATUS_UNSUPPORTED_MEDIA:
      TRACE( 2, ("Unsupported media\n"));
      break;
    default:
      TRACE( 0, ("!OpenAdapterComplete(%#x,%#x) failed\n",
        Status,OpenErrorStatus));
      break;
      }

    /* Free instance resources */
    ReleaseResources( pBinding);
    }
  else
    {
    SRequest req;
    ULONG ulVal;
    NDIS_STATUS err;

    ASSERT( pBinding->MediumIndex >= 0);
    ASSERT( pBinding->MediumIndex < s_uMedia );

#if DBG && DDK_VERSION >= 50 && !defined BINARY_COMPATIBLE /* Not available before Win2k */
    if ( NDIS_STATUS_SUCCESS == NdisQueryAdapterInstanceName(
        &pBinding->nsAdapterName, pBinding->hAdapter
      )
    ) {
      TRACE( 2, ("Bound %.24ls media:%d\n",
        pBinding->nsAdapterName.Buffer,
        (int)s_pMedia[ pBinding->MediumIndex]
      ));
      }
    else
#endif
    TRACE( 2, ("Bound %p media:%d\n",
      pBinding, (int)s_pMedia[ pBinding->MediumIndex] ));

#ifdef NDIS_PACKET_TYPE_ALL_LOCAL
    if ( IsWAN( pBinding))
      {
      ulVal = 0;
      if ( Driver_ReadParamDword( kwszWanAllLocal, &ulVal) && ulVal)
        pBinding->bWanAllLocal = TRUE;
      }
    else
      {
      ulVal = 0;
      if ( Driver_ReadParamDword( kwszAllLocal, &ulVal) && ulVal)
        pBinding->bAllLocal = TRUE;
      }
#endif

    pBinding->bPowerOn = TRUE;

    /* Tell NDIS that we don't need loopback support */
    ulVal = NDIS_PROT_OPTION_NO_LOOPBACK;
    req.Request.RequestType = NdisRequestSetInformation;
    req.Request.DATA.SET_INFORMATION.Oid = OID_GEN_PROTOCOL_OPTIONS;
    req.Request.DATA.SET_INFORMATION.InformationBuffer = &ulVal;
    req.Request.DATA.SET_INFORMATION.InformationBufferLength = sizeof(ulVal);
    err = SyncNdisRequest( pBinding, &req);
    if ( NDIS_STATUS_SUCCESS != err)
      TRACE( 1, ("*Set OID_GEN_PROTOCOL_OPTIONS failed(%#x)\n",err));

    /* Get connection state */
    ulVal = 0;
    req.Request.RequestType = NdisRequestQueryInformation;
    req.Request.DATA.QUERY_INFORMATION.Oid = OID_GEN_MEDIA_CONNECT_STATUS;
    req.Request.DATA.QUERY_INFORMATION.InformationBuffer = &ulVal;
    req.Request.DATA.QUERY_INFORMATION.InformationBufferLength = sizeof(ulVal);
    err = SyncNdisRequest( pBinding, &req);
    if ( NDIS_STATUS_SUCCESS != err)
      TRACE( 1, ("*Set OID_GEN_MEDIA_CONNECT_STATUS failed(%#x)\n",err));
    else
      {
      pBinding->bMediaDisconnected = (BOOLEAN)(NdisMediaStateConnected != ulVal);
      TRACE( 2, ("Media %p is %sconnected\n",
        pBinding, pBinding->bMediaDisconnected ? "dis" : "" ));
      }

    if ( IsWAN( pBinding))
      {
#if 0 /* RAS port returns NDIS_STATUS_BUFFER_TOO_SHORT */
      UCHAR nlpid = 0x21; /* IP - RFC 1700 p200, PPP RFC 1661 p5 */ 
#else
      UCHAR nlpid[] = { 0x80,0,0,0, 8,0}; /* 0x800 = ethernet type for IPv4 */
#endif

      req.Request.RequestType = NdisRequestSetInformation;
      req.Request.DATA.SET_INFORMATION.Oid = OID_WAN_PROTOCOL_TYPE;
      req.Request.DATA.SET_INFORMATION.InformationBuffer = &nlpid;
      req.Request.DATA.SET_INFORMATION.InformationBufferLength = sizeof(nlpid);
      err = SyncNdisRequest( pBinding, &req);
      if ( NDIS_STATUS_SUCCESS != err)
        TRACE( 1, ("*Set WAN_PROTOCOL_TYPE failed(%#x)\n",err));

      ulVal = NdisWanHeaderEthernet; /*NdisWanHeaderNative*/
      req.Request.RequestType = NdisRequestSetInformation;
      req.Request.DATA.SET_INFORMATION.Oid = OID_WAN_HEADER_FORMAT;
      req.Request.DATA.SET_INFORMATION.InformationBuffer = &ulVal;
      req.Request.DATA.SET_INFORMATION.InformationBufferLength = sizeof(ulVal);
      err = SyncNdisRequest( pBinding, &req);
      if ( NDIS_STATUS_SUCCESS != err)
        {
        TRACE( 1, ("*Set WAN_HEADER_FORMAT failed(%#x)\n",err));
        if ( NDIS_STATUS_INVALID_OID == err)
          Status = err; /* Fatal */
        }
      }

    if ( NDIS_STATUS_SUCCESS == Status)
      {
      /* Add a device binding */
      Driver_AddDevice( &pBinding->pDeviceObject, &s_info, pBinding);
      }
    else
      {
      /* Free instance resources */
      ReleaseResources( pBinding);
      }
    }

  if ( bBinding)
    NdisCompleteBindAdapter( BindContext, Status, OpenErrorStatus);
  }


/*
 * Unbind protocol from an adapter
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma NDIS_PAGEABLE_FUNCTION( ProtocolUnbindAdapter)
VOID ProtocolUnbindAdapter(
  OUT PNDIS_STATUS  pStatus,
  IN  NDIS_HANDLE   ProtocolBindingContext,
  IN  NDIS_HANDLE   UnbindContext
) {
  SBindingInstance* const pBinding = (SBindingInstance*)ProtocolBindingContext;

  ASSERT( NULL != pStatus);
  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);

  Driver_SetDevice( pBinding->pDeviceObject);
  TRACE( 9, ("ProtocolUnbindAdapter(%p,%p)\n",
    ProtocolBindingContext,UnbindContext));

  pBinding->BindContext = UnbindContext;
  pBinding->bBinding = TRUE;

  *pStatus = CloseAdapter( pBinding);
  }


/*
 * Close a binding
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma NDIS_PAGEABLE_FUNCTION( CloseAdapter)
NDIS_STATUS CloseAdapter( SBindingInstance* pBinding)
  {
  NDIS_STATUS status;

  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);

#if DBG && DDK_VERSION >= 50 && !defined BINARY_COMPATIBLE
  TRACE( 2, ("CloseAdapter(%p) %ls\n",
    pBinding, pBinding->nsAdapterName.Buffer));
#else
  TRACE( 2, ("CloseAdapter(%p)\n", pBinding));
#endif

  pBinding->bPowerOn = FALSE;

  /* Remove device binding */
  Driver_RemoveDevice( pBinding->pDeviceObject);
  pBinding->pDeviceObject = NULL;

  /* Close the adapter */
  NdisCloseAdapter( &status, pBinding->hAdapter);
  if ( NDIS_STATUS_PENDING != status)
    {
    pBinding->bBinding = FALSE;
    ProtocolCloseAdapterComplete( pBinding, status);
    }

  return status;
  }


/*
 * NdisCloseAdapter completion call-back
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma NDIS_PAGEABLE_FUNCTION( ProtocolCloseAdapterComplete)
VOID ProtocolCloseAdapterComplete(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN NDIS_STATUS    Status
) {
  SBindingInstance* const pBinding = (SBindingInstance*)ProtocolBindingContext;
  NDIS_HANDLE UnbindAdapterContext;
  BOOLEAN bBinding;

  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);

  Driver_SetDevice( pBinding->pDeviceObject);
  TRACE( 9, ("ProtocolCloseAdapterComplete(%p,%#x)\n",
    ProtocolBindingContext,Status));

  if ( NDIS_STATUS_SUCCESS != Status)
    TRACE( 1, ("*ProtocolCloseAdapterComplete status %#x\n",Status));

  TRACE( 2, ("RxPkt:%lu RxDrp:%lu RxErr:%lu RxByte:%lu\n",
    pBinding->ulRxPackets,
    pBinding->ulRxPacketsDropped,
    pBinding->ulRxErrors,
    pBinding->ulRxBytes
  ));
  TRACE( 2, ("TxPkt:%lu TxDrp:%lu TxErr:%lu TxByte:%lu\n",
    pBinding->ulTxPackets,
    pBinding->ulTxPacketsDropped,
    pBinding->ulTxErrors,
    pBinding->ulTxBytes
  ));

  UnbindAdapterContext = pBinding->BindContext;
  bBinding = pBinding->bBinding;

  /* Free instance resources */
  ReleaseResources( pBinding);

  if ( bBinding)
    NdisCompleteUnbindAdapter( UnbindAdapterContext, Status);
  }


/*
 * NdisReset call-back
 *
 * IRQL DISPATCH_LEVEL
 */
VOID ProtocolResetComplete(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN NDIS_STATUS    Status
) {
  SBindingInstance* const pBinding = (SBindingInstance*)ProtocolBindingContext;
  (void)Status;

  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);

  Driver_SetDevice( pBinding->pDeviceObject);
  TRACE( 3, ("ProtocolResetComplete(%p,%#x)\n",
    ProtocolBindingContext,Status));
  }


/*
 * NdisMIndicateStatus call-back
 *
 * IRQL DISPATCH_LEVEL
 */
VOID ProtocolStatus(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN NDIS_STATUS    Status,
  IN PVOID          StatusBuffer,
  IN UINT           StatusBufferSize
) {
  SBindingInstance* const pBinding = (SBindingInstance*)ProtocolBindingContext;
  (void)StatusBuffer;
  (void)StatusBufferSize;

  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);

  Driver_SetDevice( pBinding->pDeviceObject);
  TRACE( 9, ("ProtocolStatus(%p,%#x,%p,%u)\n",
    ProtocolBindingContext,Status,StatusBuffer,StatusBufferSize));

  switch ( Status)
    {
  default:
    TRACE( 3, ("ProtocolStatus(%p) %#x\n", pBinding,Status));
    break;

  case NDIS_STATUS_RESET_START:
    TRACE( 2, ("ProtocolStatus(%p): ResetStart\n",pBinding));
    pBinding->bResetInProgress = TRUE;
    break;

  case NDIS_STATUS_RESET_END:
    TRACE( 2, ("ProtocolStatus(%p): ResetEnd\n",pBinding));
    pBinding->bResetInProgress = FALSE;
    break;

  case NDIS_STATUS_MEDIA_DISCONNECT:
    TRACE( 2, ("ProtocolStatus(%p): MEDIA_DISCONNECT\n",pBinding));
    pBinding->bMediaDisconnected = TRUE;
    break;

  case NDIS_STATUS_MEDIA_CONNECT:
    TRACE( 2, ("ProtocolStatus(%p): MEDIA_CONNECT\n",pBinding));
    pBinding->bMediaDisconnected = FALSE;
    break;

  case NDIS_STATUS_WAN_LINE_UP:
    TRACE( 2, ("ProtocolStatus(%p): WAN_LINE_UP\n",pBinding));
    pBinding->bWanDown = FALSE;
    break;

  case NDIS_STATUS_WAN_LINE_DOWN:
    TRACE( 2, ("ProtocolStatus(%p): WAN_LINE_DOWN\n",pBinding));
    pBinding->bWanDown = TRUE;
    break;
    }
  }


/*
 * NdisMIndicateStatusComplete call-back
 *
 * IRQL DISPATCH_LEVEL
 */
VOID ProtocolStatusComplete(
  IN NDIS_HANDLE    ProtocolBindingContext
) {
  SBindingInstance* const pBinding = (SBindingInstance*)ProtocolBindingContext;

  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);

  Driver_SetDevice( pBinding->pDeviceObject);
  TRACE( 3, ("ProtocolStatusComplete(%p)\n",ProtocolBindingContext));
  }


#if DDK_VERSION >= 50
/*
 * NDIS Plug'N'Play call-back
 *
 * IRQL Not specified
 */
NDIS_STATUS ProtocolPNPHandler(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN PNET_PNP_EVENT pNetPnPEvent
) {
  SBindingInstance* const pBinding = (SBindingInstance*)ProtocolBindingContext;
  PNDIS_DEVICE_POWER_STATE pState;

  ASSERT( NULL == pBinding || kMagic == pBinding->eMagic);
  ASSERT( NULL != pNetPnPEvent);

  Driver_SetDevice( pBinding ? pBinding->pDeviceObject : NULL);
  TRACE( 9, ("ProtocolPNPHandler(%p,%p)\n",
    ProtocolBindingContext,pNetPnPEvent));

  switch ( pNetPnPEvent->NetEvent)
    {
  case NetEventSetPower:
    /* NB DO NOT CALL TRACE as this can BSOD if called from DriverUnload */
    if ( pNetPnPEvent->BufferLength >= sizeof( *pState)
      && NULL != (pState = (PNDIS_DEVICE_POWER_STATE)pNetPnPEvent->Buffer)
    ) {
      switch ( *pState)
        {
      case NdisDeviceStateD0: /* On */
        if ( NULL != pBinding)
          pBinding->bPowerOn = TRUE;
        break;

      case NdisDeviceStateD1:
      case NdisDeviceStateD2:
      case NdisDeviceStateD3: /* Off */
        if ( NULL != pBinding)
          pBinding->bPowerOn = FALSE;
        break;

      case NdisDeviceStateUnspecified:
      default:
        break;
        }
      }
    break;

  case NetEventQueryPower:
    break;

  case NetEventQueryRemoveDevice:
    if ( NULL != pBinding && pBinding->lRefs > 0)
      {
      TRACE( 1, ("*ProtocolPNPHandler(%p) QueryRemoveDevice in use\n",
        ProtocolBindingContext));
      return NDIS_STATUS_FAILURE;
      }

    TRACE( 2, ("ProtocolPNPHandler(%p) QueryRemoveDevice OK\n",
      ProtocolBindingContext));
    break;

  case NetEventCancelRemoveDevice:
    TRACE( 2, ("ProtocolPNPHandler(%p) CancelRemoveDevice\n",
      ProtocolBindingContext));
    break;

  case NetEventReconfigure:
    /* NB ProtocolBindingContext may be NULL if all interfaces */
    TRACE( 3, ("ProtocolPNPHandler(%p) Reconfigure\n",
      ProtocolBindingContext));
    break;

  case NetEventBindList:
    /* NB ProtocolBindingContext is NULL */
    TRACE( 3, ("ProtocolPNPHandler() BindList\n"));
    break;

  case NetEventBindsComplete:
    /* NB ProtocolBindingContext is NULL */
    TRACE( 3, ("ProtocolPNPHandler() BindsComplete\n"));
    break;

  case NetEventPnPCapabilities:
    TRACE( 3, ("ProtocolPNPHandler() PnPCapabilities\n"));
    break;

  default:
    TRACE( 3, ("ProtocolPNPHandler(%p) event %#x\n",
      ProtocolBindingContext, pNetPnPEvent->NetEvent));
    return NDIS_STATUS_NOT_SUPPORTED;
    }

  return NDIS_STATUS_SUCCESS;
  }
#endif


/*
 * Reference an adapter
 *
 * IRQL PASSIVE_LEVEL
 */
/* NB not pageable cos calls NdisInterlockedInsertTailList */
long DeviceOpen( void** ppvClient, void* pvContext, struct _IRP* pIrp)
  {
  SBindingInstance* const pBinding = (SBindingInstance*)pvContext;
  NDIS_STATUS Status;
  SClient* pClient;
  (void)pIrp;

  TRACE( 9, ("DeviceOpen(%p,%p,%p)\n",ppvClient,pvContext,pIrp));
  ASSERT( NULL != ppvClient);
  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);
  ASSERT( pBinding->lRefs >= 0);

  *ppvClient = NULL;

  /* Allocate non-paged client instance data */
  Status = NdisAllocateMemory(
    (PVOID*)&pClient, sizeof( *pClient),
    kMemoryType,
    kHighestAcceptableMax
  );
  if ( NDIS_STATUS_SUCCESS != Status)
    {
    TRACE( 0, ("!DeviceOpen out of memory (%#x)\n",Status));
    return STATUS_UNSUCCESSFUL;
    }

  NdisZeroMemory( pClient, sizeof( *pClient) );
  pClient->eMagic = kMagic;

  NdisAllocateSpinLock( &pClient->RecvSpinLock);
  NdisInitializeListHead( &pClient->RecvList);

  if ( 1 == NdisInterlockedIncrement( &pBinding->lRefs) )
    {
    SRequest req;
    ULONG ulFilter;

#ifdef NDIS_PACKET_TYPE_ALL_LOCAL
    /* BUGBUG: Win2k dialup won't receive normally if ALL_LOCAL set */
    if ( IsWAN( pBinding))
      {
      ulFilter = pBinding->bWanAllLocal ? NDIS_PACKET_TYPE_ALL_LOCAL : 0;
      }
    else
      {
      ulFilter = pBinding->bAllLocal ? NDIS_PACKET_TYPE_ALL_LOCAL : 0;
      }
#else
    /* DDK_VERSION == 41 */
    ulFilter = 0;
#endif

    /* First open so enable packet reception */
    ulFilter |= NDIS_PACKET_TYPE_DIRECTED | NDIS_PACKET_TYPE_BROADCAST;
    req.Request.RequestType = NdisRequestSetInformation;
    req.Request.DATA.SET_INFORMATION.Oid = OID_GEN_CURRENT_PACKET_FILTER;
    req.Request.DATA.SET_INFORMATION.InformationBuffer = &ulFilter;
    req.Request.DATA.SET_INFORMATION.InformationBufferLength = sizeof(ulFilter);
    Status = SyncNdisRequest( pBinding, &req);
    if ( NDIS_STATUS_SUCCESS != Status)
      {
      TRACE( 1, ("*DeviceOpen() NdisRequest failed(%#x)\n",Status));
      ReleaseClient( pClient);
      NdisInterlockedDecrement( &pBinding->lRefs);
      return STATUS_UNSUCCESSFUL;
      }

    pBinding->ulReceiveFilter = ulFilter;
    }

  /* Add to list of clients */
  NdisInterlockedInsertTailList(
    &pBinding->ClientList,
    &pClient->ListElement,
    &pBinding->ClientSpinLock
  );
  *ppvClient = pClient;

  return STATUS_SUCCESS;
  }


/*
 * Dereference an adapter
 *
 * IRQL PASSIVE_LEVEL
 */
/* NB not pageable cos calls NdisAcquireSpinLock */
long DeviceClose( void* pvContext, void* pvClient, struct _IRP* pIrp)
  {
  SBindingInstance* const pBinding = (SBindingInstance*)pvContext;
  SClient* const pClient = (SClient*)pvClient;
  NDIS_STATUS Status;
  SRequest req;
  ULONG ulFilter;
  (void)pIrp;

  TRACE( 9, ("DeviceClose(%p,%p,%p)\n",pvContext,pvClient,pIrp));
  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);
  ASSERT( pBinding->lRefs > 0);
  ASSERT( NULL != pClient);
  ASSERT( kMagic == pClient->eMagic);

  TRACE( 2, ("RxPkt:%lu RxDrp:%lu RxErr:%lu RxByte:%lu RxRjt:%lu\n",
    pClient->ulRxPackets,
    pClient->ulRxPacketsDropped,
    pClient->ulRxErrors,
    pClient->ulRxBytes,
    pClient->ulRxPacketsRejected
  ));
  TRACE( 2, ("TxPkt:%lu TxDrp:%lu TxErr:%lu TxByte:%lu\n",
    pClient->ulTxPackets,
    pClient->ulTxPacketsDropped,
    pClient->ulTxErrors,
    pClient->ulTxBytes
  ));

  ulFilter = pBinding->ulReceiveFilter;

  if ( pClient->bPromiscuous
    && 0 == NdisInterlockedDecrement( &pBinding->lPromiscuousClients)
  ) {
    ulFilter &= ~(NDIS_PACKET_TYPE_PROMISCUOUS);

#ifdef NDIS_PACKET_TYPE_ALL_LOCAL
    if ( IsWAN( pBinding))
      {
      if ( !pBinding->bWanAllLocal)
        ulFilter &= ~(NDIS_PACKET_TYPE_ALL_LOCAL);
      }
    else if ( !pBinding->bAllLocal)
      {
      ulFilter &= ~(NDIS_PACKET_TYPE_ALL_LOCAL);
      }
#endif
    }

  if ( pClient->bMulticast
    && 0 == NdisInterlockedDecrement( &pBinding->lMulticastClients)
  ) {
    ulFilter &= ~(NDIS_PACKET_TYPE_MULTICAST | NDIS_PACKET_TYPE_ALL_MULTICAST);
    }

  if ( 0 == NdisInterlockedDecrement( &pBinding->lRefs))
    {
    ASSERT( 0 == pBinding->lPromiscuousClients);

    /* Last close so disable packet reception */
    ulFilter = 0;
    }

  Status = STATUS_SUCCESS;
  if ( ulFilter != pBinding->ulReceiveFilter)
    {
    req.Request.RequestType = NdisRequestSetInformation;
    req.Request.DATA.SET_INFORMATION.Oid = OID_GEN_CURRENT_PACKET_FILTER;
    req.Request.DATA.SET_INFORMATION.InformationBuffer = &ulFilter;
    req.Request.DATA.SET_INFORMATION.InformationBufferLength = sizeof(ulFilter);
    Status = SyncNdisRequest( pBinding, &req);
    if ( NDIS_STATUS_SUCCESS != Status)
      {
      TRACE( 1, ("*DeviceClose() NdisRequest failed(%#x)\n",Status));
      Status = STATUS_UNSUCCESSFUL;
      }

    pBinding->ulReceiveFilter = ulFilter;
    }

  /* Remove from list of clients */
  NdisAcquireSpinLock( &pBinding->ClientSpinLock);
  RemoveEntryList( &pClient->ListElement);
  NdisReleaseSpinLock( &pBinding->ClientSpinLock);

  ReleaseClient( pClient);

  return Status;
  }


/*
 * Release resources allocated for a client
 *
 * IRQL PASSIVE_LEVEL
 */
/*#pragma NDIS_PAGEABLE_FUNCTION( ReleaseClient)*/
void ReleaseClient( SClient* pClient)
  {
  ASSERT( NULL != pClient);
  ASSERT( kMagic == pClient->eMagic);
  TRACE( 9, ("ReleaseClient(%p)\n",pClient));

  pClient->eMagic = 0;
  NdisFreeSpinLock( &pClient->RecvSpinLock);
  NdisFreeMemory( pClient, sizeof(*pClient), kMemoryType);
  }

  
/*
 * Make a synchronous NdisRequest
 *
 * IRQL <= DISPATCH_LEVEL
 */
NDIS_STATUS SyncNdisRequest( SBindingInstance* pBinding, SRequest* pRequest)
  {
  NDIS_STATUS Status;

  TRACE( 9, ("SyncNdisRequest(%p,%p)\n",pBinding,pRequest));

  if ( !pBinding->bPowerOn)
    {
    TRACE( 1, ("*SyncNdisRequest(%p) Power down\n",pBinding));
    return STATUS_DEVICE_POWERED_OFF;
    }

  NdisInitializeEvent( &pRequest->Event);

  NdisRequest( &Status, pBinding->hAdapter, &pRequest->Request);
  if ( NDIS_STATUS_PENDING != Status)
    ProtocolRequestComplete( pBinding, &pRequest->Request, Status);

  /* Wait for request to complete */
  NdisWaitEvent( &pRequest->Event, 0);
  return pRequest->Status;
  }


/*
 * NdisRequest completion call-back
 *
 * IRQL DISPATCH_LEVEL
 */
VOID ProtocolRequestComplete(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN PNDIS_REQUEST  Request,
  IN NDIS_STATUS    Status
) {
  SRequest* const pRequest = CONTAINING_RECORD( Request, SRequest, Request);
  (void)ProtocolBindingContext;

  TRACE( 9, ("ProtocolRequestComplete(%p,%p,%#x)\n",
    ProtocolBindingContext,Request,Status));

  pRequest->Status = Status;
  NdisSetEvent( &pRequest->Event);
  }


/*
 * Post a read request
 *
 * IRQL PASSIVE_LEVEL
 */
/* NB not pageable cos calls NdisInterlockedInsertTailList */
long DeviceRead(
  void* pvContext,
  void* pvClient,
  struct _IRP* pIrp,
  void* pvBuf,
  unsigned long* pulBuf
) {
  SBindingInstance* const pBinding = (SBindingInstance*)pvContext;
  SClient* const pClient = (SClient*)pvClient;
  NDIS_STATUS status;
  PNDIS_PACKET pPacket;
  unsigned long ulBuf;

  TRACE( 9, ("DeviceRead(%p,%p,%p,%p,%p)\n",
    pvContext,pvClient,pIrp,pvBuf,pulBuf));
  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);
  ASSERT( pBinding->lRefs > 0);
  ASSERT( NULL != pvBuf);
  ASSERT( NULL != pClient);
  ASSERT( kMagic == pClient->eMagic);

  ulBuf = *pulBuf;
  *pulBuf = 0;
  if ( ulBuf < kEthernetData + kEthernetHeader)
    {
    TRACE( 1, ("*DeviceRead(%p) Buffer too small\n",pvContext));
    return STATUS_BUFFER_TOO_SMALL;
    }

  /* Get a packet header for the buffer */
  NdisAllocatePacket( &status, &pPacket, pBinding->hPacketPool);
  if ( NDIS_STATUS_SUCCESS != status)
    {
    TRACE( 1, ("*DeviceRead(%p) NdisAllocatePacket failed(%#x)\n",
      pvContext,status));
    return STATUS_INSUFFICIENT_RESOURCES;
    }

  RESERVED( pPacket)->pIrp = pIrp;
  RESERVED( pPacket)->pvBuf = pvBuf;
  RESERVED( pPacket)->ulBuf = ulBuf;
  RESERVED( pPacket)->pClient = pClient;

  /* Append packet to list of pending reads */
  TRACE( 4, ("DeviceRead(%p) pend IRP %p\n",pBinding,pIrp));
  NdisInterlockedInsertTailList(
    &pClient->RecvList,
    &(RESERVED( pPacket)->ListElement),
    &pClient->RecvSpinLock
  );

  return STATUS_PENDING;
  }


/*
 * NDIS call-back to indicate received data
 *
 * IRQL DISPATCH_LEVEL
 *
 * NB for WAN parameters are:
  IN NDIS_HANDLE NdisLinkHandle,
  IN PUCHAR Packet,
  IN ULONG PacketSize
 */
NDIS_STATUS ProtocolReceiveIndicate(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN NDIS_HANDLE    MacReceiveContext,
  IN PVOID          HeaderBuffer,
  IN UINT           HeaderBufferSize,
  IN PVOID          LookAheadBuffer,
  IN UINT           LookAheadBufferSize,
  IN UINT           PacketSize
) {
  SBindingInstance* const pBinding = (SBindingInstance*)ProtocolBindingContext;
  NDIS_STATUS ret = NDIS_STATUS_NOT_ACCEPTED;
  PLIST_ENTRY ple;

  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);

  Driver_SetDevice( pBinding->pDeviceObject);
  TRACE( 9, ("ProtocolReceiveIndicate(%p,%p,%p,%u,%p,%u,%u)\n",
    ProtocolBindingContext,MacReceiveContext,HeaderBuffer,HeaderBufferSize,
    LookAheadBuffer,LookAheadBufferSize,PacketSize
  ));

  NdisInterlockedIncrement( &(LONG) pBinding->ulRxPackets);
  pBinding->ulRxBytes += PacketSize;

  /* Lock the client list */
#if OPT_DPR
  NdisDprAcquireSpinLock( &pBinding->ClientSpinLock);
#else
  NdisAcquireSpinLock( &pBinding->ClientSpinLock);
#endif

  if ( IsListEmpty( &pBinding->ClientList))
    {
    TRACE( 0, ("!ProtocolReceiveIndicate(%p) No pending clients, hdr:%u pkt:%u\n",
      pBinding, HeaderBufferSize, PacketSize));
    NdisInterlockedIncrement( &(LONG) pBinding->ulRxPacketsDropped);
    }

  /* Pass data to each client */
  for (
    ple = pBinding->ClientList.Flink;
    ple != &pBinding->ClientList;
    ple = ple->Flink
  ) {
    SClient* const pClient = CONTAINING_RECORD( ple, SClient, ListElement);
    PLIST_ENTRY pListEntry;

    /* Get the first pending receive */
    pListEntry = NdisInterlockedRemoveHeadList(
      &pClient->RecvList,
      &pClient->RecvSpinLock
    );

#if OPT_DPR
    NdisDprReleaseSpinLock( &pBinding->ClientSpinLock);
#else
    NdisReleaseSpinLock( &pBinding->ClientSpinLock);
#endif

    if ( NULL != pListEntry)
      {
      SPacketReserved* const pPacketReserved = CONTAINING_RECORD(
        pListEntry, SPacketReserved, ListElement);
      PNDIS_PACKET const pPacket = CONTAINING_RECORD(
        pPacketReserved, NDIS_PACKET, ProtocolReserved);
      UINT uTransferred;
      NDIS_STATUS err;

      if ( pPacketReserved->ulBuf < HeaderBufferSize + PacketSize)
        {
        NdisInterlockedIncrement( &(LONG) pClient->ulRxPacketsRejected);
        TRACE( 1, ("*ProtocolReceiveIndicate(%p) Packet too big %u\n",
          ProtocolBindingContext, PacketSize));

        uTransferred = 0;
        pPacketReserved->ulBuf = 0;
        err = NDIS_STATUS_INVALID_LENGTH;
        }
      else
        {
        /* Copy the header */
        NdisMoveMappedMemory(
          pPacketReserved->pvBuf,
          HeaderBuffer,
          HeaderBufferSize
        );

        /* Copy the lookahead */
#if DDK_VERSION >= 50 /* Available in Win2k DDK */
        NdisCopyLookaheadData(
          (char*)pPacketReserved->pvBuf + HeaderBufferSize,
          LookAheadBuffer,
          LookAheadBufferSize,
          0
        );
#elif DDK_VERSION == 41 /* Win98 DDK */
        NdisMoveFromMappedMemory(
          (char*)pPacketReserved->pvBuf + HeaderBufferSize,
          LookAheadBuffer,
          LookAheadBufferSize
        );
#elif DDK_VERSION == 40 && !defined BINARY_COMPATIBLE /* NT4 DDK */
        TdiCopyLookaheadData(
          (char*)pPacketReserved->pvBuf + HeaderBufferSize,
          LookAheadBuffer,
          LookAheadBufferSize,
          0
        );
#else
        /* NT4 */
        NdisMoveFromMappedMemory(
          (char*)pPacketReserved->pvBuf + HeaderBufferSize,
          LookAheadBuffer,
          LookAheadBufferSize
        );
#endif

        uTransferred = HeaderBufferSize + LookAheadBufferSize;

        if ( LookAheadBufferSize >= PacketSize)
          {
          pPacketReserved->ulBuf = 0;
          err = ret = NDIS_STATUS_SUCCESS;
          }
        else
          {
          PNDIS_BUFFER pBuffer;

          pPacketReserved->ulBuf = uTransferred;

          /* Get a buffer */
          NdisAllocateBuffer(
            &err,
            &pBuffer,
            pBinding->hBufferPool,
            (char*)pPacketReserved->pvBuf + uTransferred,
            PacketSize - LookAheadBufferSize
          );
          if ( NDIS_STATUS_SUCCESS != err)
            {
            TRACE( 1, ("*ProtocolReceiveIndicate(%p) NdisAllocateBuffer failed(%#x)\n",
              pBinding,err));
            uTransferred = 0;
            }
          else
            {
            NdisChainBufferAtFront( pPacket,pBuffer);

            /* Copy the body */
            NdisTransferData(
              &err,
              pBinding->hAdapter,
              MacReceiveContext,
              LookAheadBufferSize,
              PacketSize - LookAheadBufferSize,
              pPacket,
              &uTransferred
            );
            ret = NDIS_STATUS_SUCCESS;
            }
          }
        }

      if ( NDIS_STATUS_PENDING != err)
        {
        ProtocolTransferDataComplete(
          ProtocolBindingContext,
          pPacket,
          err,
          uTransferred
        );
        }
      }
    else
      {
      TRACE( 3, ("ProtocolReceiveIndicate(%p) No pending read, hdr:%u pkt:%u\n",
        pBinding, HeaderBufferSize, PacketSize));
      NdisInterlockedIncrement( &(LONG) pClient->ulRxPacketsDropped);
      }

#if OPT_DPR
    NdisDprAcquireSpinLock( &pBinding->ClientSpinLock);
#else
    NdisAcquireSpinLock( &pBinding->ClientSpinLock);
#endif
    }

  /* Unlock the client list */
#if OPT_DPR
  NdisDprReleaseSpinLock( &pBinding->ClientSpinLock);
#else
  NdisReleaseSpinLock( &pBinding->ClientSpinLock);
#endif

  return ret;
  }


/*
 * NDIS NdisTransferData call-back
 *
 * IRQL DISPATCH_LEVEL
 * 
 * NB WAN version has NO parameters
 */
VOID ProtocolTransferDataComplete(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN PNDIS_PACKET   pPacket,
  IN NDIS_STATUS    Status,
  IN UINT           BytesTransferred
) {
  SBindingInstance* const pBinding = (SBindingInstance*)ProtocolBindingContext;
  NTSTATUS ntStatus;
  unsigned long len;
  struct _IRP* pIrp;
  SClient* pClient;

  ASSERT( NULL != pPacket);
  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);

  Driver_SetDevice( pBinding->pDeviceObject);
  TRACE( 9, ("ProtocolTransferDataComplete(%p,%p,%#x,%u)\n",
    ProtocolBindingContext,pPacket,Status,BytesTransferred));

  pClient = RESERVED( pPacket)->pClient;
  ASSERT( NULL != pClient);
  ASSERT( kMagic == pClient->eMagic);

  len = RESERVED( pPacket)->ulBuf + BytesTransferred;
  pIrp = RESERVED( pPacket)->pIrp;
  if ( NULL != pIrp)
    {
    ASSERT( pBinding->lRefs > 0);

    /* Free all buffers */
    for ( ;;)
      {
      PNDIS_BUFFER pBuffer;

      NdisUnchainBufferAtFront( pPacket, &pBuffer);
      if ( NULL == pBuffer)
        break;

      NdisFreeBuffer( pBuffer);
      }
#if OPT_DPR && DDK_VERSION >= 50
    NdisDprFreePacket( pPacket);
#else
    NdisFreePacket( pPacket);
#endif

    if ( NDIS_STATUS_SUCCESS == Status)
      {
      NdisInterlockedIncrement( &(LONG) pClient->ulRxPackets);
      pClient->ulRxBytes += len;
      ntStatus = STATUS_SUCCESS;
      }
    else
      {
      NdisInterlockedIncrement( &(LONG) pBinding->ulRxErrors);
      NdisInterlockedIncrement( &(LONG) pClient->ulRxErrors);
      ntStatus = STATUS_UNSUCCESSFUL;
      }

    TRACE( 3, ("RxData IRP:%p %u bytes\n",pIrp,len));
    Driver_CompleteRequest( pIrp, ntStatus, len);
    }
  }


/*
 * NDIS ReceiveIndicate complete call-back
 *
 * Packets previously indicated to ProtocolReceiveIndicate can now be postprocessed. 
 *
 * MSDN says IRQL PASSIVE_LEVEL but on Win2k can be <= DISPATCH_LEVEL
 */
VOID ProtocolReceiveComplete(
  IN NDIS_HANDLE ProtocolBindingContext
) {
  SBindingInstance* const pBinding = (SBindingInstance*)ProtocolBindingContext;
  (void)pBinding;

  TRACE( 9, ("ProtocolReceiveComplete(%p)\n",ProtocolBindingContext));
  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);
  }


/*
 * Cancel a request
 *
 * IRQL PASSIVE_LEVEL & DISPATCH_LEVEL
 */
long DeviceCancel( void* pvContext, void* pvClient, struct _IRP* pIrp)
  {
  SBindingInstance* const pBinding = (SBindingInstance*)pvContext;
  SClient* const pClient = (SClient*)pvClient;

  TRACE( 9, ("DeviceCancel(%p,%p,%p)\n",pvContext,pvClient,pIrp));
  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);

  if ( NULL == pClient)
    {
    /* Iterate over all clients */
    PLIST_ENTRY ple;
    long lRet = STATUS_UNSUCCESSFUL;

    NdisAcquireSpinLock( &pBinding->ClientSpinLock);
    for (
      ple = pBinding->ClientList.Flink;
      ple != &pBinding->ClientList;
      ple = ple->Flink
    ) {
      lRet = DeviceCancel(
        pvContext, CONTAINING_RECORD( ple, SClient, ListElement), pIrp);
      if ( NULL != pIrp && STATUS_SUCCESS == lRet)
        break;
      }

    NdisReleaseSpinLock( &pBinding->ClientSpinLock);
    return lRet;
    }
  ASSERT( kMagic == pClient->eMagic);

  do
    {
    PLIST_ENTRY pEntry;
    SPacketReserved* pRequest;
    PNDIS_PACKET pPacket;

    pRequest = NULL; /* Not found */

    /* Lock the RecvQ */
    NdisAcquireSpinLock( &pClient->RecvSpinLock);

    /* Walk the list of pending IRPs */
    for (
      pEntry = pClient->RecvList.Flink;
      pEntry != &pClient->RecvList;
      pEntry = pEntry->Flink
    ) {
      SPacketReserved* pPacketReserved;

      pPacketReserved = CONTAINING_RECORD(
        pEntry, SPacketReserved, ListElement);
      if ( NULL == pIrp
        || pIrp == pPacketReserved->pIrp
      ) {
        /* Request found */
        pRequest = pPacketReserved;
        RemoveEntryList( pEntry);
        break;
        }
      }
  
    /* Unlock the RecvQ */
    NdisReleaseSpinLock( &pClient->RecvSpinLock);

    if ( NULL == pRequest)
      {
      if ( NULL != pIrp)
        {
        TRACE( 1, ("*DeviceCancel(%p) IRP %p not found\n",pvContext,pIrp));
        return STATUS_UNSUCCESSFUL;
        }
      
      return STATUS_SUCCESS;
      }

    pPacket = CONTAINING_RECORD( pRequest, NDIS_PACKET, ProtocolReserved);
#if 0 && OPT_DPR && DDK_VERSION >= 50 /* This cause NT4 to bugcheck */
    NdisDprFreePacket( pPacket);
#else
    NdisFreePacket( pPacket);
#endif

    /* Cancel the request */
    TRACE( 4, ("DeviceCancel IRP:%p\n",pRequest->pIrp));
    Driver_CompleteRequest(
      pRequest->pIrp,
      STATUS_CANCELLED,
      0
    );
    }
  while ( NULL == pIrp);

  return STATUS_SUCCESS;
  }


#if NDIS_MAJOR_VERSION >= 4
/*
 * NDIS ReceivePacket call-back
 *
 * Receive an array of packets. 
 *
 * IRQL DISPATCH_LEVEL 
 */
INT ProtocolReceivePacket(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN PNDIS_PACKET   Packet
) {
  SBindingInstance* const pBinding = (SBindingInstance*)ProtocolBindingContext;
  UINT bytesTransfered;
  PLIST_ENTRY ple;

  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);

  Driver_SetDevice( pBinding->pDeviceObject);
  TRACE( 2, ("ProtocolReceivePacket(%p,%p)\n",
    ProtocolBindingContext,Packet));

  NdisQueryPacket( Packet, NULL, NULL, NULL, &bytesTransfered);
  NdisInterlockedIncrement( &(LONG) pBinding->ulRxPackets);
  pBinding->ulRxBytes += bytesTransfered;

  /* Lock the client list */
#if OPT_DPR
  NdisDprAcquireSpinLock( &pBinding->ClientSpinLock);
#else
  NdisDprAcquireSpinLock( &pBinding->ClientSpinLock);
#endif
  if ( IsListEmpty( &pBinding->ClientList))
    {
    TRACE( 0, ("!ProtocolReceivePacket(%p) No pending clients\n",pBinding));
    NdisInterlockedIncrement( &(LONG) pBinding->ulRxPacketsDropped);
    }

  /* Pass packet to each client */
  for (
    ple = pBinding->ClientList.Flink;
    ple != &pBinding->ClientList;
    ple = ple->Flink
  ) {
    SClient* const pClient = CONTAINING_RECORD( ple, SClient, ListElement);
    PLIST_ENTRY pListEntry;

    /* Get the first pending receive */
    pListEntry = NdisInterlockedRemoveHeadList(
      &pClient->RecvList,
      &pClient->RecvSpinLock
    );

#if OPT_DPR
    NdisDprReleaseSpinLock( &pBinding->ClientSpinLock);
#else
    NdisReleaseSpinLock( &pBinding->ClientSpinLock);
#endif

    if ( NULL != pListEntry)
      {
      SPacketReserved* const pPacketReserved = CONTAINING_RECORD(
        pListEntry, SPacketReserved, ListElement);
      PNDIS_PACKET const pPacket = CONTAINING_RECORD(
        pPacketReserved, NDIS_PACKET, ProtocolReserved);
      UINT ulBytes;
      struct _IRP* pIrp;
      NDIS_STATUS status;

      if ( pPacketReserved->ulBuf < bytesTransfered)
        {
        NdisInterlockedIncrement( &(LONG) pClient->ulRxPacketsRejected);
        TRACE( 1, ("*ProtocolReceivePacket(%p) Packet too big %u\n",
          ProtocolBindingContext, bytesTransfered));

        ulBytes = 0;
        status = NDIS_STATUS_INVALID_LENGTH;
        }
      else
        {
        PNDIS_BUFFER pBuffer;

        /* Get a buffer */
        NdisAllocateBuffer(
          &status,
          &pBuffer,
          pBinding->hBufferPool,
          (char*)pPacketReserved->pvBuf,
          pPacketReserved->ulBuf
        );
        if ( NDIS_STATUS_SUCCESS != status)
          {
          TRACE( 1, ("*ProtocolReceivePacket(%p) NdisAllocateBuffer failed(%#x)\n",
            pBinding,status));
          NdisInterlockedIncrement( &(LONG) pBinding->ulRxErrors);
          NdisInterlockedIncrement( &(LONG) pClient->ulRxErrors);
          ulBytes = 0;
          }
        else
          {
          NdisInterlockedIncrement( &(LONG) pClient->ulRxPackets);
          pClient->ulRxBytes += bytesTransfered;

          /* Copy the body */
          /* NB must release any spin lock before calling NdisCopyFromPacketToPacket */
          NdisChainBufferAtFront( pPacket,pBuffer);
          NdisCopyFromPacketToPacket(
            pPacket,
            0,
            pPacketReserved->ulBuf,
            Packet,
            0,
            &ulBytes
          );
          }
        }

      /* Free all buffers */
      for ( ;;)
        {
        PNDIS_BUFFER pBuffer;

        NdisUnchainBufferAtFront( pPacket, &pBuffer);
        if ( NULL == pBuffer)
          break;

        NdisFreeBuffer( pBuffer);
        }

#if OPT_DPR && DDK_VERSION >= 50
      NdisDprFreePacket( pPacket);
#else
      NdisFreePacket( pPacket);
#endif

      pIrp = pPacketReserved->pIrp;
      TRACE( 3, ("RxPacket IRP:%p %u bytes\n",pIrp,ulBytes));
      Driver_CompleteRequest(
        pIrp,
        NDIS_STATUS_SUCCESS == status ? STATUS_SUCCESS : STATUS_UNSUCCESSFUL,
        ulBytes
      );
      }
    else
      {
      TRACE( 3, ("ProtocolReceivePacket(%p) No pending reads\n",pBinding));
      NdisInterlockedIncrement( &(LONG) pClient->ulRxPacketsDropped);
      }

#if OPT_DPR
    NdisDprAcquireSpinLock( &pBinding->ClientSpinLock);
#else
    NdisAcquireSpinLock( &pBinding->ClientSpinLock);
#endif
    }

  /* Unlock the client list */
#if OPT_DPR
  NdisDprReleaseSpinLock( &pBinding->ClientSpinLock);
#else
  NdisReleaseSpinLock( &pBinding->ClientSpinLock);
#endif

  return 0; /* 0= won't call NdisReturnPackets */
  }
#endif


/*
 * Send a buffer
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma NDIS_PAGEABLE_FUNCTION( DeviceWrite)
long DeviceWrite(
  void* pvContext,
  void* pvClient,
  struct _IRP* pIrp,
  void* pvBuf,
  unsigned long* pulBuf
) {
  SBindingInstance* const pBinding = (SBindingInstance*)pvContext;
  SClient* const pClient = (SClient*)pvClient;
  NDIS_STATUS status;
  PNDIS_PACKET pPacket;
  PNDIS_BUFFER pBuffer;
  unsigned long ulBuf;

  TRACE( 9, ("DeviceWrite(%p,%p,%p,%p,%p)\n",
    pvContext,pvClient,pIrp,pvBuf,pulBuf));
  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);
  ASSERT( pBinding->lRefs > 0);
  ASSERT( NULL != pvBuf);
  ASSERT( NULL != pClient);
  ASSERT( kMagic == pClient->eMagic);

  ulBuf = *pulBuf;
  *pulBuf = 0;
  if ( ulBuf < kEthernetHeader)
    {
    TRACE( 1, ("*DeviceWrite(%p) Buffer too small\n",pvContext));
    NdisInterlockedIncrement( &(LONG) pBinding->ulTxErrors);
    NdisInterlockedIncrement( &(LONG) pClient->ulTxErrors);
    return STATUS_BUFFER_TOO_SMALL;
    }

  if ( pBinding->bResetInProgress)
    {
    TRACE( 1, ("*DeviceWrite(%p) Reset in progress\n",pvContext));
    NdisInterlockedIncrement( &(LONG) pBinding->ulTxErrors);
    NdisInterlockedIncrement( &(LONG) pClient->ulTxErrors);
    return STATUS_CONNECTION_RESET;
    }

  if ( !pBinding->bPowerOn)
    {
    TRACE( 1, ("*DeviceWrite(%p) Power down\n",pvContext));
    NdisInterlockedIncrement( &(LONG) pBinding->ulTxErrors);
    NdisInterlockedIncrement( &(LONG) pClient->ulTxErrors);
    return STATUS_DEVICE_POWERED_OFF;
    }

#if 0
  if ( pBinding->bMediaDisconnected)
    {
    TRACE( 1, ("*DeviceWrite(%p) Media disconnected\n",pvContext));
    NdisInterlockedIncrement( &(LONG) pBinding->ulTxErrors);
    NdisInterlockedIncrement( &(LONG) pClient->ulTxErrors);
    return STATUS_DEVICE_POWERED_OFF;
    }
#endif

#if 0
  if ( IsWAN( pBinding)
    && pBinding->bWanDown
  ) {
    TRACE( 1, ("*DeviceWrite(%p) WAN down\n",pvContext));
    NdisInterlockedIncrement( &(LONG) pBinding->ulTxErrors);
    NdisInterlockedIncrement( &(LONG) pClient->ulTxErrors);
    return STATUS_PORT_DISCONNECTED;
    }
#endif

  /* Get a packet header for the buffer */
  NdisAllocatePacket( &status, &pPacket, pBinding->hPacketPool);
  if ( NDIS_STATUS_SUCCESS != status)
    {
    TRACE( 1, ("*DeviceWrite(%p) NdisAllocatePacket failed(%#x)\n",
      pvContext,status));
    NdisInterlockedIncrement( &(LONG) pClient->ulTxPacketsDropped);
    NdisInterlockedIncrement( &(LONG) pBinding->ulTxPacketsDropped);
    return STATUS_INSUFFICIENT_RESOURCES;
    }
  RESERVED( pPacket)->pIrp = pIrp;
  RESERVED( pPacket)->pvBuf = pvBuf;
  RESERVED( pPacket)->ulBuf = ulBuf;
  RESERVED( pPacket)->pClient = pClient;

  /* Get a buffer */
  NdisAllocateBuffer(
    &status,
    &pBuffer,
    pBinding->hBufferPool,
    pvBuf,
    ulBuf
  );
  if ( NDIS_STATUS_SUCCESS != status)
    {
    TRACE( 1, ("*DeviceWrite(%p) NdisAllocateBuffer failed(%#x)\n",
      pvContext,status));
    NdisFreePacket( pPacket);
    NdisInterlockedIncrement( &(LONG) pClient->ulTxPacketsDropped);
    NdisInterlockedIncrement( &(LONG) pBinding->ulTxPacketsDropped);
    return STATUS_INSUFFICIENT_RESOURCES;
    }

  NdisChainBufferAtFront( pPacket,pBuffer);

  TRACE( 3, ("DeviceWrite(%p) pend IRP %p\n",pBinding,pIrp));
  NdisSend( &status, pBinding->hAdapter, pPacket);
  if ( NDIS_STATUS_PENDING != status)
    ProtocolSendComplete( pBinding, pPacket, status);

  return STATUS_PENDING;
  }


/*
 * NdisSend completion call-back
 *
 * IRQL DISPATCH_LEVEL
 */
VOID ProtocolSendComplete(
  IN NDIS_HANDLE    ProtocolBindingContext,
  IN PNDIS_PACKET   pPacket, /* WAN: PNDIS_WAN_PACKET */
  IN NDIS_STATUS    Status
) {
  SBindingInstance* const pBinding = (SBindingInstance*)ProtocolBindingContext;
  NTSTATUS ntStatus;
  unsigned long len;
  struct _IRP* pIrp;
  UINT bytesTransfered;
  SClient* pClient;

  Driver_SetDevice( pBinding->pDeviceObject);
  TRACE( 9, ("ProtocolSendComplete(%p,%p,%#x)\n",
    ProtocolBindingContext,pPacket,Status));

  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);
  ASSERT( NULL != pPacket);

  pClient = RESERVED( pPacket)->pClient;
  ASSERT( NULL != pClient);
  ASSERT( kMagic == pClient->eMagic);

  NdisQueryPacket( pPacket, NULL, NULL, NULL, &bytesTransfered);

  pBinding->ulTxBytes += bytesTransfered;
  NdisInterlockedIncrement( &(LONG) pBinding->ulTxPackets);

  pClient->ulTxBytes += bytesTransfered;
  NdisInterlockedIncrement( &(LONG) pClient->ulTxPackets);

  if ( NDIS_STATUS_SUCCESS != Status)
    {
    NdisInterlockedIncrement( &(LONG) pBinding->ulTxErrors);
    NdisInterlockedIncrement( &(LONG) pClient->ulTxErrors);
    }

  len = RESERVED( pPacket)->ulBuf;
  pIrp = RESERVED( pPacket)->pIrp;
  if ( NULL != pIrp)
    {
    ASSERT( pBinding->lRefs > 0);

    /* Free all buffers */
    for ( ;;)
      {
      PNDIS_BUFFER pBuffer;

      NdisUnchainBufferAtFront( pPacket, &pBuffer);
      if ( NULL == pBuffer)
        break;

      NdisFreeBuffer( pBuffer);
      }

#if OPT_DPR && DDK_VERSION >= 50
    NdisDprFreePacket( pPacket);
#else
    NdisFreePacket( pPacket);
#endif

    if ( NDIS_STATUS_SUCCESS == Status)
      {
      TRACE( 3, ("TxComplete IRP:%p %u bytes\n",pIrp,len));
      ntStatus = STATUS_SUCCESS;
      }
    else
      {
      TRACE( 1, ("*TxComplete IRP:%p status:%#lx\n",pIrp,Status));
      ntStatus = STATUS_UNSUCCESSFUL;
      len = 0;
      }

    Driver_CompleteRequest( pIrp, ntStatus, len);
    }
  }


/*
 * Get MAC address
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma NDIS_PAGEABLE_FUNCTION( DeviceGetMacAddr)
long DeviceGetMacAddr( void* pvContext, void* pvClient, void* pvBuf)
  {
  SBindingInstance* const pBinding = (SBindingInstance*)pvContext;
  SClient* const pClient = (SClient*)pvClient;
  NDIS_STATUS Status;
  SRequest req;

  TRACE( 9, ("DeviceGetMacAddr(%p,%p,%p)\n",pvContext,pvClient,pvBuf));
  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);
  ASSERT( pBinding->lRefs > 0);
  ASSERT( NULL != pClient);
  ASSERT( kMagic == pClient->eMagic);
  (void)pClient;
  
  req.Request.RequestType = NdisRequestQueryInformation;
  switch ( s_pMedia[ pBinding->MediumIndex])
    {
  case NdisMediumWan:
    req.Request.DATA.QUERY_INFORMATION.Oid = OID_WAN_CURRENT_ADDRESS;
    break;
  case NdisMediumWirelessWan:
    /*req.Request.DATA.QUERY_INFORMATION.Oid = OID_WW_GEN_CURRENT_ADDRESS;*/
    req.Request.DATA.QUERY_INFORMATION.Oid = OID_WAN_CURRENT_ADDRESS;
    break;
  case NdisMedium802_3:
  case NdisMediumDix:
    req.Request.DATA.QUERY_INFORMATION.Oid = OID_802_3_CURRENT_ADDRESS;
    break;
  default:
    TRACE( 1, ("*DeviceGetMacAddr() bad media\n"));
    return STATUS_UNSUCCESSFUL;
    }
  req.Request.DATA.QUERY_INFORMATION.InformationBuffer = pvBuf;
  req.Request.DATA.QUERY_INFORMATION.InformationBufferLength = 6;

  Status = SyncNdisRequest( pBinding, &req);
  if ( NDIS_STATUS_SUCCESS != Status)
    {
    TRACE( 1, ("*DeviceGetMacAddr() NdisRequest failed(%#x)\n",Status));
    return STATUS_UNSUCCESSFUL;
    }
  
  return STATUS_SUCCESS;
  }


/*
 * Set multicast list
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma NDIS_PAGEABLE_FUNCTION( DeviceSetMulticastList)
long DeviceSetMulticastList(
  void* pvContext,
  void* pvClient,
  const void* pvBuf,
  unsigned len
) {
  SBindingInstance* const pBinding = (SBindingInstance*)pvContext;
  SClient* const pClient = (SClient*)pvClient;
  NDIS_STATUS Status;
  SRequest req;
  ULONG ulFilter;

  TRACE( 9, ("DeviceSetMulticastList(%p,%p,%p,%u)\n",pvContext,pvClient,pvBuf,len));
  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);
  ASSERT( pBinding->lRefs > 0);
  ASSERT( NULL != pClient);
  ASSERT( kMagic == pClient->eMagic);

  ulFilter = pBinding->ulReceiveFilter;

  if ( len > 0)
    {
    if ( IsEthernet( pBinding) )
      {
      LONG lCount;

      if ( !pClient->bMulticast)
        {
        pClient->bMulticast = TRUE;
        lCount = NdisInterlockedIncrement( &pBinding->lMulticastClients);
        }
      else
        {
        lCount = pBinding->lMulticastClients;
        }

      /* Is this the only m/cast client? */
      if ( 1 == lCount
        /* All valid enet m/cast addresses start with 1
         * The SwsVpkt VDD passes a list starting with 0xff for 'all multicast' */
        && 1 == *(const unsigned char*)pvBuf
      ) {
        ulFilter &= ~NDIS_PACKET_TYPE_ALL_MULTICAST;
        ulFilter |= NDIS_PACKET_TYPE_MULTICAST;

        /* Set the multicast list */
        req.Request.RequestType = NdisRequestSetInformation;
        req.Request.DATA.SET_INFORMATION.Oid = OID_802_3_MULTICAST_LIST;
        req.Request.DATA.SET_INFORMATION.InformationBuffer = (PVOID)pvBuf;
        req.Request.DATA.SET_INFORMATION.InformationBufferLength = len;
        Status = SyncNdisRequest( pBinding, &req);
        if ( NDIS_STATUS_SUCCESS == Status)
          {
#if 1 /* BUGBUG: Win2k-SP4 with Intel PRO/100VE only 1st entry is reliable */
          if ( len > 6)
            ulFilter |= NDIS_PACKET_TYPE_ALL_MULTICAST;
#endif
          }
        else if ( NDIS_STATUS_MULTICAST_FULL == Status)
          {
          /* Receive all multicasts */
          ulFilter |= NDIS_PACKET_TYPE_ALL_MULTICAST;
          }
        else
          {
          TRACE( 1, ("*DeviceSetMulticastList() NdisRequest failed(%#x)\n",
            Status));
          return STATUS_UNSUCCESSFUL;
          }
        }
      else
        {
        /* Multiple clients so receive all multicasts */
        ulFilter |= NDIS_PACKET_TYPE_ALL_MULTICAST;
        }
      }
    }
  else if ( pClient->bMulticast)
    {
    pClient->bMulticast = FALSE;

    if ( 0 == NdisInterlockedDecrement( &pBinding->lMulticastClients))
      ulFilter &= ~(NDIS_PACKET_TYPE_MULTICAST | NDIS_PACKET_TYPE_ALL_MULTICAST);
    }

  if ( ulFilter != pBinding->ulReceiveFilter)
    {
    /* Set the packet filter */
    req.Request.RequestType = NdisRequestSetInformation;
    req.Request.DATA.SET_INFORMATION.Oid = OID_GEN_CURRENT_PACKET_FILTER;
    req.Request.DATA.SET_INFORMATION.InformationBuffer = &ulFilter;
    req.Request.DATA.SET_INFORMATION.InformationBufferLength = sizeof(ulFilter);
    Status = SyncNdisRequest( pBinding, &req);
    if ( NDIS_STATUS_SUCCESS != Status)
      {
      TRACE( 1, ("*DeviceSetMulticastList() NdisRequest PACKET_FILTER failed(%#x)\n",
        Status));
      return STATUS_UNSUCCESSFUL;
      }

    pBinding->ulReceiveFilter = ulFilter;
    TRACE( 3, ("DeviceSetMulticastList filter:%#lx\n",ulFilter));
    }
  
  return STATUS_SUCCESS;
  }


/*
 * Get multicast list
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma NDIS_PAGEABLE_FUNCTION( DeviceGetMulticastList)
long DeviceGetMulticastList(
  void* pvContext,
  void* pvClient,
  void* pvBuf,
  unsigned* puLen
) {
  SBindingInstance* const pBinding = (SBindingInstance*)pvContext;
  NDIS_STATUS Status;
  SRequest req;
  (void)pvClient;

  TRACE( 9, ("DeviceGetMulticastList(%p,%p,%p,%p)\n",pvContext,pvClient,pvBuf,puLen));
  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);
  ASSERT( pBinding->lRefs > 0);
  ASSERT( NULL != pvClient);
  ASSERT( NULL != puLen);

  /* Get the multicast list */
  req.Request.RequestType = NdisRequestQueryInformation;
  req.Request.DATA.QUERY_INFORMATION.Oid = OID_802_3_MULTICAST_LIST;
  req.Request.DATA.QUERY_INFORMATION.InformationBuffer = (PVOID)pvBuf;
  req.Request.DATA.QUERY_INFORMATION.InformationBufferLength = *puLen;
  req.Request.DATA.QUERY_INFORMATION.BytesWritten = 0;
  Status = SyncNdisRequest( pBinding, &req);
  if ( NDIS_STATUS_SUCCESS != Status)
    {
    TRACE( 1, ("*DeviceGetMulticastList() NdisRequest failed(%#x)\n",
      Status));
    return NDIS_STATUS_INVALID_LENGTH == Status ? STATUS_BUFFER_TOO_SMALL : STATUS_UNSUCCESSFUL;
    }

  *puLen = req.Request.DATA.QUERY_INFORMATION.BytesWritten;

  return STATUS_SUCCESS;
  }

  
/*
 * Set promiscuity
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma NDIS_PAGEABLE_FUNCTION( DeviceSetPromiscuity)
long DeviceSetPromiscuity( void* pvContext, void* pvClient, int mode)
  {
  SBindingInstance* const pBinding = (SBindingInstance*)pvContext;
  SClient* const pClient = (SClient*)pvClient;
  NDIS_STATUS Status;
  SRequest req;
  ULONG ulFilter;
  BOOLEAN bPromiscuous;

  TRACE( 9, ("DeviceSetPromiscuity(%p,%p,%d)\n",pvContext,pvClient,mode));
  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);
  ASSERT( pBinding->lRefs > 0);
  ASSERT( NULL != pClient);
  ASSERT( kMagic == pClient->eMagic);

  ulFilter = pBinding->ulReceiveFilter;

  bPromiscuous = (BOOLEAN)(mode ? TRUE : FALSE);
  if ( pClient->bPromiscuous != bPromiscuous)
    {
    LONG lCount;

    pClient->bPromiscuous = bPromiscuous;
    if ( bPromiscuous)
      lCount = NdisInterlockedIncrement( &pBinding->lPromiscuousClients);
    else
      lCount = NdisInterlockedDecrement( &pBinding->lPromiscuousClients);

    if ( lCount > 0)
      {
#ifdef NDIS_PACKET_TYPE_ALL_LOCAL
      ulFilter |= NDIS_PACKET_TYPE_PROMISCUOUS | NDIS_PACKET_TYPE_ALL_LOCAL;
#else
      ulFilter |= NDIS_PACKET_TYPE_PROMISCUOUS;
#endif
      }
    else
      {
      ulFilter &= ~(NDIS_PACKET_TYPE_PROMISCUOUS);
      }
    }

  if ( ulFilter != pBinding->ulReceiveFilter)
    {
    req.Request.RequestType = NdisRequestSetInformation;
    req.Request.DATA.SET_INFORMATION.Oid = OID_GEN_CURRENT_PACKET_FILTER;
    req.Request.DATA.SET_INFORMATION.InformationBuffer = &ulFilter;
    req.Request.DATA.SET_INFORMATION.InformationBufferLength = sizeof(ulFilter);
    Status = SyncNdisRequest( pBinding, &req);
    if ( NDIS_STATUS_SUCCESS != Status)
      {
      TRACE( 1, ("*DeviceSetPromiscuity(%d) NdisRequest failed(%#x)\n",
        mode,Status));
      return STATUS_UNSUCCESSFUL;
      }
  
    pBinding->ulReceiveFilter = ulFilter;
    TRACE( 3, ("DeviceSetPromiscuity filter:%#lx\n",ulFilter));
    }

  return STATUS_SUCCESS;
  }


/*
 * Get adapter info
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma NDIS_PAGEABLE_FUNCTION( DeviceGetInfo)
long DeviceGetInfo( void* pvContext, void* pvBuf)
  {
  SBindingInstance* const pBinding = (SBindingInstance*)pvContext;
  IOCTL_INFO* const pInfo = (IOCTL_INFO*)pvBuf;

  TRACE( 9, ("DeviceGetInfo(%p,%p)\n",pvContext,pvBuf));
  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);
  ASSERT( pBinding->lRefs > 0);

  pInfo->bPowerOn = pBinding->bPowerOn;
  pInfo->bMediaDisconnected = pBinding->bMediaDisconnected;
  pInfo->bWan = (BOOLEAN) IsWAN( pBinding);
  pInfo->bWanDown = pBinding->bWanDown;
  
  return STATUS_SUCCESS;
  }


/*
 * Get adapter description
 *
 * IRQL PASSIVE_LEVEL
 */
#pragma NDIS_PAGEABLE_FUNCTION( DeviceGetDesc)
long DeviceGetDesc( void* pvContext, void* pvBuf, unsigned* puLen)
  {
  SBindingInstance* const pBinding = (SBindingInstance*)pvContext;
  NDIS_STATUS Status;
  SRequest req;

  TRACE( 9, ("DeviceGetDesc(%p,%p,%p)\n",pvContext,pvBuf,puLen));
  ASSERT( NULL != pBinding);
  ASSERT( kMagic == pBinding->eMagic);
  ASSERT( pBinding->lRefs > 0);
  ASSERT( NULL != puLen);

  req.Request.RequestType = NdisRequestQueryInformation;
  req.Request.DATA.QUERY_INFORMATION.Oid = OID_GEN_VENDOR_DESCRIPTION;
  req.Request.DATA.QUERY_INFORMATION.InformationBuffer = (PVOID)pvBuf;
  req.Request.DATA.QUERY_INFORMATION.InformationBufferLength = *puLen;
  req.Request.DATA.QUERY_INFORMATION.BytesWritten = 0;
  Status = SyncNdisRequest( pBinding, &req);
  if ( NDIS_STATUS_SUCCESS != Status)
    {
    TRACE( 1, ("*DeviceGetDesc() NdisRequest failed(%#x)\n",Status));
    return NDIS_STATUS_INVALID_LENGTH == Status ? STATUS_BUFFER_TOO_SMALL : STATUS_UNSUCCESSFUL;
    }
  
  *puLen = req.Request.DATA.QUERY_INFORMATION.BytesWritten;
  
  return STATUS_SUCCESS;
  }

/* End of file */
