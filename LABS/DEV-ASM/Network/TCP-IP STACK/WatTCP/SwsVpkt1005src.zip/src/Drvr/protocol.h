/****************************************************************************
 * protocol.h                                                               *
 * Purpose:     NDIS protocol driver module                                 *
 *                                                                          *
 * Created by Lawrence Rust, Software Systems Consultants               .   *
 * lvr@softsystem.co.uk. Tel/Fax +33 5 49 72 79 63                          *
 *__________________________________________________________________________*
 *                                                                          *
 * Revision History:                                                        *
 *                                                                          *
 * No.   Date     By   Reason                                               *
 *--------------------------------------------------------------------------*
 * 100 21 Mar 03  lvr  Created                                              *
 *__________________________________________________________________________*/

#ifndef PROTOCOL_H
#define PROTOCOL_H

#ifdef __cplusplus
extern "C" {
#endif

/* Install the protocol. Returns 0 on success */
extern int ProtocalInstall( void);

/* Remove the protocol */
extern void ProtocolUnload( void);

#ifdef __cplusplus
}
#endif
#endif /*ndef PROTOCOL_H*/
/* End of file */
