/****************************************************************************
 * SWSVPKT.C                                                                *
 * Application: DOS16 packet driver TSR                                     *
 *                                                                          *
 * Copyright (c)2005 Lawrence Rust                                          *
 * Created by Lawrence Rust, Software Systems Consultants.                  *
 * lvr@softsystem.co.uk. Tel/Fax +33 549 727963                             *
 *                                                                          *
 * Runtime:     Windows NT 4.0, 2000, XP                                    *
 *                                                                          *
 * Build:       Microsoft Visual C++ 1.52c, BorlandC 3.1                    *
 *__________________________________________________________________________*
 *                                                                          *
 * Revision History:                                                        *
 *                                                                          *
 * No.   Date     By   Reason                                               *
 *--------------------------------------------------------------------------*
 * 100 27 May 05  lvr  Created                                              *
 * 105 18 May 06  lvr  Added adapter name display and default adapter       *
 *__________________________________________________________________________*/

#define VER_MAJOR 1
#define VER_MINOR 05
#define kszApp "Packet driver for Windows VDM"
#define kszCopyright "Copyright (C)2005,2006 Lawrence Rust. All rights reserved."

/* Compilation options */
#ifdef _MSC_VER
#pragma warning ( disable : 4704) /* in-line assembler precludes global optimizations */
#pragma warning ( disable : 4705) /* statement has no effect */
#endif


/* Exports */


/* Imports */
/* ANSI */
#include <stdlib.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>

/* DOS */
#include <process.h>
#include <conio.h>
#include <dos.h>

/* NT DDK, DOS16 VDD support */
#include "isvbop.h"


/*
 * Macro definitions
 */
#define _STR(s) #s
#define STRING(s) _STR(s)

#ifdef __TIMESTAMP__
 #define TIMESTAMP "updated " __TIMESTAMP__
#else
 #define TIMESTAMP "built at " __TIME__ " on " __DATE__
#endif

#define kszVer STRING( VER_MAJOR) "." STRING( VER_MINOR)
#define kszInfo kszApp " version " kszVer ", " TIMESTAMP "\n" kszCopyright

#define kszModule "swsvpkt.dll" /* VDD filename */

/* Common buffer size */
#define BUFFER_LEN 256  /* was (8*4) */

/* Min/max values for SWI to hook */
#define MIN_PKT_INTR 0x60
#define MAX_PKT_INTR 0x80

/* Min/max values for h/w IRQ */
#define MIN_INTR 3
#define MAX_INTR 15

#define IRQBASE   0x08       /* IRQ0 vector */
#define IRQBASE8  0x70       /* IRQ8 vector */

/* 8259 PIC register addresses */
#define PIC_OCR     0x20    /* Master Operation control register */
#define PIC_IMR     0x21    /* Master Interrupt mask */
#define PICS_OCR    0xA0    /* Slave Operation control register */
#define PICS_IMR    0xA1    /* Slave Interrupt mask */

/* 8259 register contents */
#define EOI_NS      0x20    /* Non-specific end of interrupt */

#define C_FLAG 1 /* flags register */

/* Packet driver function call numbers */
#define DRIVER_INFO        1
#define ACCESS_TYPE        2
#define RELEASE_TYPE       3
#define SEND_PKT           4
#define TERMINATE          5
#define GET_ADDRESS        6
#define RESET_INTERFACE    7
/* Optional high performance functions */
#define GET_PARAMETERS     10
#define AS_SEND_PKT        11
/* Optional extended functions */
#define SET_RCV_MODE       20
#define GET_RCV_MODE       21
#define SET_MULTICAST_LIST 22
#define GET_MULTICAST_LIST 23
#define GET_STATISTICS     24
#define SET_ADDRESS        25

/* Packet driver error return codes. From Appendix C. */
#define BAD_HANDLE     1  /* invalid handle number */
#define NO_CLASS       2  /* no interfaces of specified class found */
#define NO_TYPE        3  /* no interfaces of specified type found */
#define NO_NUMBER      4  /* no interfaces of specified number found */
#define BAD_TYPE       5  /* bad packet type specified */
#define NO_MULTICAST   6  /* this interface does not support multicast */
#define CANT_TERMINATE 7  /* this packet driver cannot terminate */
#define BAD_MODE       8  /* an invalid receiver mode was specified */
#define NO_SPACE       9  /* operation failed because of insufficient space */
#define TYPE_INUSE     10 /* the type had previously been accessed, and not released */
#define BAD_COMMAND    11 /* the command was out of range, or not implemented */
#define CANT_SEND      12 /* the packet couldn't be sent (usually hardware error) */
#define CANT_SET       13 /* hardware address couldn't be changed (> 1 handle open) */
#define BAD_ADDRESS    14 /* hardware address has bad length or format */
#define CANT_RESET     15 /* couldn't reset interface (> 1 handle open) */

#if defined __BORLANDC__
/* From isvbop.h */
#ifndef BOP_3RDPARTY
#define BOP_3RDPARTY 0x58
#endif
#ifndef BOP_UNSIMULATE
#define BOP_UNSIMULATE 0xFE
#endif

#undef RegisterModule
#define RegisterModule()   _asm db 0xC4, 0xC4, BOP_3RDPARTY, 0x0

#undef UnRegisterModule
#define UnRegisterModule() _asm db 0xC4, 0xC4, BOP_3RDPARTY, 0x1

#undef DispatchCall
#define DispatchCall()     _asm db 0xC4, 0xC4, BOP_3RDPARTY, 0x2

#undef VDDUnSimulate16
#define VDDUnSimulate16()  _asm db 0xC4, 0xC4, BOP_UNSIMULATE

#endif /* defined __BORLANDC__ */

#ifdef __BORLANDC__
#define OUTPB( p, v) outp( p, v)
#define INPB( p) ((unsigned char)inp( p))
#else
#define OUTPB( p, v) _outp( p, v)
#define INPB( p) ((unsigned char)_inp( p))
#endif


/***************************************************************************
 * Data types
 ***************************************************************************/

/* Command line parameters */
typedef struct SConfig
  {
  int iVerbosity;
  unsigned uSwi;
  unsigned uHwIrq;
  int iUnload;
  int iEnum;
  } SConfig;

/* Packet driver request passed to VDD DispatchCall() with dx=1 */
typedef struct SPktRegs
  {
  unsigned AX;
  unsigned BX;
  unsigned CX;
  unsigned DX;
  unsigned DI;
  unsigned SI;
  unsigned DS;
  unsigned ES;
  } SPktRegs;

typedef void __interrupt __far Fisr();


/***************************************************************************
 * Function prototypes
 ***************************************************************************/
static int ParseArgs( SConfig* const, int, const char* const []);
static void Banner( FILE*);
static void Help( const char* const pszArg);

static int FindPacketDrvr( void);
static int FindFreeInterrupt( void);
static int EnumInterfaces( unsigned);
static Fisr __far * GetEntryPoint( void);
static void __interrupt __far PacketIntr();
static void __interrupt __far Callback();
static void __interrupt __far InterruptHandler();

static unsigned LoadVdd(            /* OUT !0 on error */
  unsigned short*,                  /* OUT: VDD handle */
  unsigned short*,                  /* OUT: DX from init */
  char const __far*,                /* IN: Module name, required */
  char const __far*,                /* IN: Init fn name, optional */
  char const __far*,                /* IN: Dispatch fn name, required */
  unsigned short,                   /* AX to init */
  unsigned short                    /* DX to init */
);


/***************************************************************************
 * Module data
 ***************************************************************************/
extern int iEndOfData; /* End of data for keep() */

static unsigned s_uSwi;   /* SWI hooked */
static unsigned s_uHwIrq; /* H/w interrupt hooked */
static unsigned s_uImr, s_uIrqMask; /* 8259 i/o base & IRQ mask */

static  Fisr __far * s_pfnIrqHandler;
static unsigned short s_uHandle; /*  VDD handle */
static unsigned char s_ucDefaultAdapter; /* Default adapter */

static char s_buffer[ BUFFER_LEN]; /* Buffer used by VDD to pass data to client */


/***************************************************************************
 * Functions
 ***************************************************************************/

/*
 * Show command line syntax
 */
static void Help( const char* const pszArg)
  {
  const char* pszCmd;
  const char* pszDot;
  size_t c;

  Banner( stderr);
  
  /* Get command name without path */
  if ( NULL != pszArg)
    {
    pszCmd = strrchr( pszArg, '/');
    if ( NULL != pszCmd)
      ++pszCmd;
    else
      {
      pszCmd = strrchr( pszArg, '\\');
      if ( NULL != pszCmd)
        ++pszCmd;
      else
        pszCmd = pszArg;
      }
    }
  else
    {
    pszCmd = kszInfo;
    }

  /* Count command name length less any '.' extension */
  pszDot = strrchr( pszCmd, '.');
  if ( NULL != pszDot)
    c = (size_t)(pszDot - pszCmd);
  else
    c = strlen( pszCmd);

  fprintf( stderr,
    "Syntax: %.*s [options] [SWI]\n"
    "-i<u> : Hardware IRQ\n"
    "-l    : List adapters\n"
    "-a<u> : Select adapter\n"
    "-u    : Unload driver\n"
    "-t    : Quiet mode\n"
    "-h    : Help\n",
    (int)c, pszCmd
  );
  }


/*
 * M A I N
 */
int main( int const argc, const char* const argv[] )
  {
  SConfig cfg;
  int iRet;

  /* Check we're running on NT */
  if ( NULL == getenv( "PROCESSOR_ARCHITECTURE"))
    {
    Banner( stderr);
    fputs( "This program requires Windows NT, 2000, XP or later.\n", stderr);
    return EXIT_FAILURE;
    }

  /* Set default options */
  cfg.iVerbosity = 1;
  cfg.uSwi = 0;
  cfg.uHwIrq = 0;
  cfg.iUnload = 0;
  cfg.iEnum = 0;

  /* Parse args */
  iRet = ParseArgs( &cfg, argc, argv );
  if ( EXIT_SUCCESS != iRet)
    return iRet;

  if ( cfg.iVerbosity > 0)
    Banner( stderr);
    
  /* Loading the driver? */
  if ( !cfg.iUnload)
    {
    /* Yes */
    unsigned short unInterfaces;
    void __far* pv;

    iRet = FindPacketDrvr();
    if ( iRet)
      {
      if ( 0 == cfg.uSwi || (unsigned)iRet == cfg.uSwi)
        {
        if ( cfg.iVerbosity > 0)
          fprintf( stderr, "Driver already resident on SWI %#x.\n", iRet);
        return EXIT_FAILURE;
        }
      }

    if ( cfg.uSwi)
      s_uSwi = cfg.uSwi;
    else
      s_uSwi = FindFreeInterrupt();

    if ( _dos_getvect( s_uSwi))
      {
      if ( cfg.iVerbosity > 0)
        fprintf( stderr, "SWI %#x is in use.\n", s_uSwi);
      return EXIT_FAILURE;
      }

    if ( 0 == cfg.uHwIrq)
      cfg.uHwIrq = 7;
      
    if ( cfg.uHwIrq <= 7)
      s_uHwIrq = cfg.uHwIrq + IRQBASE;
    else
      s_uHwIrq = cfg.uHwIrq + (IRQBASE8 - 8);
    
    /* Ensure h/w irq's are disabled */
    s_uIrqMask = ~(1U << (cfg.uHwIrq % 8));
    s_uImr = cfg.uHwIrq <= 7 ? PIC_IMR : PICS_IMR;
    OUTPB( s_uImr, INPB( s_uImr ) | ~s_uIrqMask );

    /* Load the VDD */
    iRet = LoadVdd(
      &s_uHandle,
      &unInterfaces,
      kszModule, "VDDRegister", "VDDDispatch",
      (unsigned short)cfg.uHwIrq, 0
    );
    switch ( iRet)
      {
    case 0:
      break;

    case 1: /* DLL not found */
    case 2: /* Dispatch not found */
    case 3: /* Init not found */
      if ( cfg.iVerbosity > 0)
        fprintf( stderr,
          "Failed to load the virtual device driver (code %d).\n"
          "Please ensure that " kszModule " is in the local directory or on your PATH\n",
          iRet
        );
      return EXIT_FAILURE;

    case 4: /* Out of mem */
      if ( cfg.iVerbosity > 0)
        fputs(
          "Failed to load virtual device driver.\n"
          "Out of memory\n",
          stderr
        );
      return EXIT_FAILURE;

    default:
      if ( cfg.iVerbosity > 0)
        fprintf( stderr,
          "Failed to load virtual device driver.\n"
          "Error %d\n", iRet
        );
      return EXIT_FAILURE;
      }

    if ( 0 == unInterfaces)
      {
      if ( cfg.iVerbosity > 0)
        fputs( "No adapters found.\n", stderr);
      iRet = EXIT_FAILURE;
      goto unload;
      }
      
    if ( s_ucDefaultAdapter >= unInterfaces)
      {
      if ( cfg.iVerbosity > 0)
        fputs( "Selected adapter out of range.\n", stderr);
      iRet = EXIT_FAILURE;
      goto unload;
      }
     
    /* List available interfaces */
    if ( cfg.iVerbosity > 0)
      EnumInterfaces( unInterfaces);
    
    iRet = EXIT_SUCCESS;
    if ( !cfg.iEnum)
      {
      /* Install h/w irq handler */
      s_pfnIrqHandler = _dos_getvect( s_uHwIrq);
      _dos_setvect( s_uHwIrq, &InterruptHandler);
    
      /* Enable h/w irq's */
      OUTPB( s_uImr, INPB( s_uImr) & s_uIrqMask);
      if ( cfg.uHwIrq >= 8)
        OUTPB( PIC_IMR, INPB( PIC_IMR) & ~(1U << 2));
    
      /* Install swi handler */
      if ( cfg.iVerbosity > 0)
        fprintf( stderr, "\nInstalled on SWI %#x, using IRQ %u.\n", s_uSwi, cfg.uHwIrq);
      _dos_setvect( s_uSwi, GetEntryPoint());
    
      /* Release DOS environment block */
      _dos_freemem( *((unsigned __far *) MK_FP( _psp, 0x2c)));
    
      /* TSR: return unused memory !! AND STACK !! */
      pv = &iEndOfData;
      _dos_keep( 0, FP_SEG( pv) + FP_OFF( pv)/16 - _psp + 4);
      }
      
  unload:
    /* Unload VDD */
    _asm mov ax, [s_uHandle]
    UnRegisterModule();
    s_uHandle = 0;
    }
  else
    {
    /* Unload resident driver */
    iRet = FindPacketDrvr();
    if ( 0 == iRet)
      {
      if ( cfg.iVerbosity > 0)
        fputs( "Driver is not resident.\n", stderr);
      iRet = EXIT_FAILURE;
      }
    else
      {
      union REGS regs;

      regs.h.ah = TERMINATE;
      regs.x.bx = 0;
      regs.x.cflag = 1;
      int86( iRet, &regs, &regs);
      if ( C_FLAG & regs.x.cflag)
        {
        if ( cfg.iVerbosity > 0)
          fputs( "Driver unable to terminate.\n", stderr);
        iRet = EXIT_FAILURE;
        }
      else
        {
        if ( cfg.iVerbosity > 0)
          fputs( "Driver successfully unloaded.\n", stderr);
        iRet = 0;
        }
      }
    }

  return iRet;
  }


/*
 * Get the address of the packet driver header
 */
Fisr __far * GetEntryPoint( void)
  {
  Fisr __far * p;

  _asm jmp short end

  /* The packet driver header - 12 bytes long */
#ifdef _MSC_VER
hdr:
  _asm jmp NEAR PTR PacketIntr
  _asm _emit 'P'
  _asm _emit 'K'
  _asm _emit 'T'
  _asm _emit ' '
  _asm _emit 'D'
  _asm _emit 'R'
  _asm _emit 'V'
  _asm _emit 'R'
  _asm _emit 0
#elif defined __BORLANDC__
  /* NB THIS MUST BE COMPILED VIA ASSEMBLER (-B option) */
  _asm db 0xe9 /* jmp */
  _asm dw (PacketIntr - $) - 2
  _asm db 'PKT DRVR', 0
#else
#error
#endif

end:;

  /* Load AX with address of header (in CS) */
#ifdef _MSC_VER
  _asm mov ax, OFFSET hdr
#elif defined __BORLANDC__
  _asm mov ax, OFFSET ($ - 12)
#else
#error
#endif

  _asm mov [WORD PTR p], ax
  _asm mov [WORD PTR p + 2], cs

  return p;
  }


/*
 * Packet driver SWI handler
 */
#ifdef __BORLANDC__
#pragma option -r. /* Don't use SI & DI for register vars */
#pragma option -N- /* No stack checking */
#endif
#ifdef _MSC_VER
#pragma check_stack(off)
#endif

void __interrupt __far PacketIntr(
#ifdef __BORLANDC__
  unsigned regBP, unsigned regDI, unsigned regSI,
  unsigned regDS, unsigned regES, unsigned regDX,
  unsigned regCX, unsigned regBX, unsigned regAX,
  unsigned regIP, unsigned regCS, unsigned regF
#else
  unsigned regES, unsigned regDS,
  unsigned regDI, unsigned regSI,
  unsigned regBP, unsigned regSP,
  unsigned regBX, unsigned regDX,
  unsigned regCX, unsigned regAX,
  unsigned regIP, unsigned regCS, unsigned regF
#endif
) {
  SPktRegs regs;
  int iTerminate = 0;
  (void)regBP;
  (void)regCS;
  (void)regIP;
#ifndef __BORLANDC__
  (void)regSP;
#endif

  /* Ensure irq's are enabled */
  _enable();

  /* Assume failure */
  regF |= C_FLAG;

  /* Dispatch request in ah */
  switch ( regAX >> 8)
    {
  case ACCESS_TYPE:
    if ( s_ucDefaultAdapter > 0)
      {
      if ( 0 == (regDX & 0xff))
        regDX |= s_ucDefaultAdapter;
      else if ( s_ucDefaultAdapter == (regDX & 0xff))
        regDX &= 0xff00;
      }
      
    goto common;
    
  case TERMINATE:
    if ( GetEntryPoint() != _dos_getvect( s_uSwi))
      {
      regDX = (regDX & 0xff) | (CANT_TERMINATE << 8);
      break;
      }
    if ( &InterruptHandler != _dos_getvect( s_uHwIrq))
      {
      regDX = (regDX & 0xff) | (CANT_TERMINATE << 8);
      break;
      }

    iTerminate = 1;
    if ( s_uHwIrq >= IRQBASE8)
      regCX = s_uHwIrq - (IRQBASE8 + 8);
    else
      regCX = s_uHwIrq - IRQBASE;
    
    /* Fall thru */
  default:
  common:
    /* Pack caller's regs */
    regs.AX = regAX;
    regs.BX = regBX;
    regs.CX = regCX;
    regs.DX = regDX;
    regs.DI = regDI;
    regs.SI = regSI;
    regs.DS = regDS;
    regs.ES = regES;

    /* Reflect to VDD with DX=1, ES:BX -> regs, DS:SI -> buffer len CX */
    _asm lea bx, [regs]
    _asm push ss
    _asm pop es
    _asm lea si, [s_buffer]
    _asm mov cx, BUFFER_LEN
    _asm mov dx, 1
    _asm mov ax, [s_uHandle]
    _asm stc
    DispatchCall();
    _asm jc cset /* Jump on error */

    regF &= ~C_FLAG; /* Success */

  cset:
    /* Unpack caller's regs */
    regAX = regs.AX;
    regBX = regs.BX;
    regCX = regs.CX;
    regDX = regs.DX;
    regDI = regs.DI;
    regSI = regs.SI;
    regDS = regs.DS;
    regES = regs.ES;
    break;
    }

  if ( iTerminate && !(regF & C_FLAG))
    {
    /* Disable h/w interrupts */
    OUTPB( s_uImr, INPB( s_uImr ) | ~s_uIrqMask );

    /* Restore vectors */
    _dos_setvect( s_uHwIrq, s_pfnIrqHandler);
    _dos_setvect( s_uSwi, 0);
    s_uSwi = 0;

    /* Unload the VDD */
    _asm mov ax, [s_uHandle]
    UnRegisterModule();
    s_uHandle = 0;

    /* Release memory */
    _dos_freemem( _psp);
    }
  }


/*
 * Hardware IRQ handler
 *
 * CAUTION IRQ TIME
 */
void __interrupt __far InterruptHandler( void)
  {
#if 0 /* Enable interrupts from higher priority sources */
  _enable();
#endif

  /* Reflect to VDD with DX=2, ES:DI -> callback */
  _asm mov di, SEG Callback
  _asm mov es, di
  _asm mov di, OFFSET Callback
  _asm mov dx, 2
  _asm mov ax, [s_uHandle]
  DispatchCall();

#if 0
  _disable();
#endif

  if ( s_uHwIrq >= IRQBASE8)
    OUTPB( PICS_OCR, EOI_NS); /* Non-specific EOI */
  OUTPB( PIC_OCR, EOI_NS); /* Non-specific EOI */

  if ( s_pfnIrqHandler)
    _chain_intr( s_pfnIrqHandler);

  _enable();
  }


/*
 * Callback from VDD. ES:DI -> far proc to call
 *
 * CAUTION IRQ TIME
 */
void __interrupt __far Callback(
#ifdef __BORLANDC__
  unsigned regBP, unsigned regDI, unsigned regSI,
  unsigned regDS, unsigned regES, unsigned regDX,
  unsigned regCX, unsigned regBX, unsigned regAX
#else
  unsigned regES, unsigned regDS,
  unsigned regDI, unsigned regSI,
  unsigned regBP, unsigned regSP,
  unsigned regBX, unsigned regDX,
  unsigned regCX, unsigned regAX
#endif
) {
  void __far * pv;
  (void)regBP;
#ifndef __BORLANDC__
  (void)regSP;
#endif

  pv = MK_FP( regES, regDI);

  _asm mov ax, regAX
  _asm mov bx, regBX
  _asm mov cx, regCX
  _asm mov dx, regDX
  _asm mov si, regSI
  _asm mov ds, regDS
  _asm mov di, regSI
  _asm mov es, regDS
  _asm call [DWORD PTR pv]

  _asm mov dx, 1
  VDDUnSimulate16();
  /* Never get here */
  }

#ifdef __BORLANDC__
#pragma option -r.
#pragma option -N.
#endif
#ifdef _MSC_VER
#pragma check_stack()
#endif


/*
 * Load a VDD
 */
static unsigned LoadVdd(
  unsigned short* punHandle,
  unsigned short* punDX,
  char const __far* lpszModule,         /* Required */
  char const __far* lpszInit,           /* Optional */
  char const __far* lpszDispatch,       /* Required */
  unsigned short unAX,
  unsigned short unDX
) {
  _asm push ds
  _asm push si
  _asm push di

  /* ds:si -> module name */
  _asm mov si, [WORD ptr lpszModule]

  /* es:di -> initialisation fn. name, 0:0 => none */
  _asm les di, [lpszInit]

  /* ds:bx -> dispatch fn. name */
  _asm lds bx, [lpszDispatch]

  /* Load the module, ax & dx are passed to any init fn. */
  _asm mov ax, [unAX]
  _asm mov dx, [unDX]
  RegisterModule();

  _asm mov [unAX], ax
  _asm mov [unDX], dx
  _asm pop di
  _asm pop si
  _asm pop ds
  _asm jc error

  *punHandle = unAX;
  *punDX = unDX;

  return 0;

error:
  return unAX;
  }


/*
 * Search for packet driver
 */
int FindPacketDrvr( void)
  {
  int i;

  for ( i = MIN_PKT_INTR; i <= MAX_PKT_INTR; ++i)
    {
    char __far * addr;

    /* Get -> INT handler */
    addr = (char __far*)(unsigned long)_dos_getvect( i);
    if ( addr)
      {
      if ( !_fstrcmp( addr + 3, "PKT DRVR"))
        {
        /* Packet driver found */
        return i;
        }
      }
    }

  return 0;
  }


/*
 * Search for vacant interrupt
 */
int FindFreeInterrupt( void)
  {
  int i;

  for ( i = MIN_PKT_INTR; i <= MAX_PKT_INTR; ++i)
    {
    char __far * addr;

    /* Get -> INT handler */
    addr = (char __far*)(unsigned long)_dos_getvect( i);
    if ( !addr)
      return i;
    }

  return 0;
  }


/*
 * List available interfaces
 */
static int EnumInterfaces( unsigned uNum)
  {
  unsigned u;

  fputs( "Found interface:\n", stderr);
  
  for ( u = 0; u < uNum;  ++u)
    {
    _asm push si
    _asm lea si, [s_buffer]
    _asm mov cx, BUFFER_LEN
    _asm mov bx, [u]
    _asm mov dx, 3
    _asm mov ax, [s_uHandle]
    _asm stc
    DispatchCall();
    _asm pop si
    _asm jc cset /* Jump on error */

    fprintf( stderr, "%u: %s\n", u, s_buffer);

  cset:;
    }

  return 0;
  }


/*
 * Scan the command line for options
 */
int ParseArgs(                          /* Returns !0 on error */
  SConfig* const pCfg,                  /* OUT: Updated parameters */
  int iArgc,                            /* IN: No. args */
  const char* const pszArgvArray[]      /* IN: Array of arg strings */
) {
  int i;
  int bHelp = 0;
  int iArgs = 0;

  /* Scan args */
  for ( i = 1; i < iArgc; ++i)
    {
    char c;
    const char* pszArg;
    char* pszEnd;
    long lVal;
    
    pszArg = pszArgvArray[i];

    /* Check for switch options ('-' or '/' prefix) */
    #define isswitch( _c) ('-' == _c || '/' == _c)
    c = *pszArg++;
    if ( isswitch( c) )
      {
      /* Option found */
      do
        {
        #define GetArg() \
          ('\0' != *pszArg \
            || i + 1 >= iArgc \
            || isswitch( pszArgvArray[ i + 1][ 0] ) \
          ) ? pszArg : pszArgvArray[ ++i]

        switch ( *pszArg++)
          {
        case 'h':
        case '?':
          bHelp = !0;
          break;
            
        case 'I':
        case 'i':
          /* Interrupt */
          pszArg = GetArg();
          lVal = strtol( pszArg, &pszEnd, 0);
          if ( *pszEnd || lVal < MIN_INTR || lVal > MAX_INTR)
            {
            Banner( stderr);
            fprintf( stderr, "Invalid interrupt %s\n", pszArg);
            return EXIT_FAILURE;
            }

          pszArg = NULL;
          pCfg->uHwIrq = (unsigned)lVal;
          break;

        case 'T':
        case 't':
          pCfg->iVerbosity--;
          break;

        case 'U':
        case 'u':
          pCfg->iUnload = 1;
          break;
          
        case 'L':
        case 'l':
          pCfg->iEnum = 1;
          break;

        case 'A':
        case 'a':
          /* Default adapter */
          pszArg = GetArg();
          lVal = strtol( pszArg, &pszEnd, 0);
          if ( *pszEnd || lVal < 0 || lVal > 255)
            {
            Banner( stderr);
            fprintf( stderr, "Invalid adapter %s\n", pszArg);
            return EXIT_FAILURE;
            }

          pszArg = NULL;
          s_ucDefaultAdapter = (unsigned char)lVal;
          break;

        default:
          Banner( stderr);
          fprintf( stderr, "Invalid switch: '%s'\n", pszArgvArray[i] );
          return EXIT_FAILURE;
          }
        }
      while ( NULL != pszArg && '\0' != *pszArg);
      }
    else
      {
      /* Non-switch argument */
      switch ( iArgs)
        {
      case 0:
        /* SWI */
        lVal = strtol( pszArgvArray[i], &pszEnd, 0);
        if ( *pszEnd || lVal < MIN_PKT_INTR || lVal > MAX_PKT_INTR)
          {
          Banner( stderr);
          fprintf( stderr, "Invalid interrupt %s\n", pszArg);
          return EXIT_FAILURE;
          }

        pCfg->uSwi = (unsigned)lVal;
        ++iArgs;
        break;

      default:
        Banner( stderr);
        fprintf( stderr, "Excess argument: '%s'\n", pszArgvArray[i] );
        return EXIT_FAILURE;
        }
      }
    }

  if ( bHelp)
    {
    Help( pszArgvArray[0] );
    return EXIT_FAILURE;
    }

  return EXIT_SUCCESS;
  }


/*
 * Show program headline
 */
static void Banner( FILE* file)
  {
  fputs( "\n" kszInfo "\n\n", file);
  }


/* This must be last */
int iEndOfData;

/* End of file */
