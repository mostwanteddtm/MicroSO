/****************************************************************************
 * File Name  : SwsVdd.h                                                   *
 * Function   : Virtual device driver                                        *.
 * Project    : SwsVpkt                                                     *
 * Systems    : ANSI C, Win32                                               *
 *                                                                          *
 * Created by Lawrence Rust, Software Systems Consultants               .   *
 * lvr@softsystem.co.uk. Tel/Fax +33 5 49 72 79 63                          *
 *__________________________________________________________________________*
 *                                                                          *
 * Revision History:                                                        *
 *                                                                          *
 * No.   Date     By   Reason                                               *
 *--------------------------------------------------------------------------*
 * 100  30 May 05  lvr  Creation                                            *
 *__________________________________________________________________________*/

#ifndef SWSVDD_H
#define SWSVDD_H 0x100

/* Dependencies */
#include <stdlib.h>

#pragma warning ( disable : 4201) /* nonstandard extension used : nameless struct/union */
#include <windows.h>
#pragma warning ( default : 4201)


/* Macros & constants */
#ifdef __cplusplus
 #define EXTERNC extern "C"
 #define EXPORT extern "C" __declspec( dllexport)
 #define IMPORT extern "C" __declspec( dllimport)
#else
 #define EXTERNC extern
 #define EXPORT extern __declspec( dllexport)
 #define IMPORT extern __declspec( dllimport)
#endif


/* Data types */
enum EBtn
  {
  kBtnOk = 1,
  kBtnCancel = 2,
  kBtnYes = 3,
  kBtnNo = 4,
  kBtnRetry = 5,
  kBtnAbort = 6,
  kBtnIgnore = 7,
  kBtnClose = 8,
  kBtnHelp = 9
  };


/* Global data */
extern HANDLE g_hVDD;                          /* VDD module handle */


/* Functions */
#ifdef __cplusplus
extern "C" {
#endif

/* Undoc'd NTVDM */
IMPORT ULONG WOWSysErrorBox(
  LPCSTR lpszTitle,
  LPCSTR lpszText,
  ULONG ulBtn1,
  ULONG ulBtn2,
  ULONG ulBtn3
);
IMPORT VOID SuspendTimerThread( VOID);
IMPORT VOID ResumeTimerThread( VOID);
IMPORT VOID DispatchInterrupts( VOID);
IMPORT ULONG* getIntelRegistersPointer( VOID);

/* Configuration data access */
EXTERNC BOOL VddReadRegValue(
  const char*,                        /* IN: value name */
  DWORD,                              /* IN: value type, REG_DWORD,REG_BINARY,REG_SZ  etc */
  size_t,                             /* IN: data buffer size */
  void*                               /* OUT: data */
);

#ifdef __cplusplus
}
#endif
#endif /* ndef SWSVDD_H */
/* End of file */
