/****************************************************************************
 * File Name  : vpacket.c                                                   *
 * Function   : Virtual packet driver                                       *.
 * Project    : SwsVpkt                                                     *
 * Systems    : ANSI C, Win32 (NT4,2000,XP)                                 *
 *                                                                          *
 * Created by Lawrence Rust, Software Systems Consultants               .   *
 * lvr@softsystem.co.uk. Tel/Fax +33 5 49 72 79 63                          *
 *__________________________________________________________________________*
 *                                                                          *
 * Revision History:                                                        *
 *                                                                          *
 * No.   Date     By   Reason                                               *
 *--------------------------------------------------------------------------*
 * 100  29 May 05  lvr  Creation                                            *
 * 101  18 Jul 05  lvr  Increased OPT_BUFFERS from 16 to 48                 *
 * 102  13 Oct 05  lvr  Fix SetMulticastList                                *
 *                      RxMode 5 (all multicast) implemented                *
 *                      Fix signed/uns bug in packet type filter            *
 * 105  18 May 06  lvr  Added GetAdapterName                                *
 *__________________________________________________________________________*/
#define VER_MAJOR 1
#define VER_MINOR 05

/* Compilation options */
#ifndef OPT_PACKET_ADAPTERS
#define OPT_PACKET_ADAPTERS 4   /* Max no. NIC's */
#endif

#ifndef OPT_HANDLES
#define OPT_HANDLES (OPT_PACKET_ADAPTERS * 4) /* Max no. clients */
#endif

#ifndef OPT_BUFFERS
#define OPT_BUFFERS 48 /* Default no. buffers per NIC */
#endif

#pragma warning ( disable : 4711) /* function selected for automatic inline expansion */
#pragma warning ( disable : 4505) /* unreferenced local function has been removed */


/* Exports */
#include "vpacket.h"

/* Imports */
#include <stddef.h>
#include <stdlib.h>

/* Win32 SDK */
#pragma warning ( disable : 4201) /* nonstandard extension used : nameless struct/union */
#include <windows.h>

/* Private interface to the NDIS protocol driver */
#include "ioctls.h"
#pragma warning ( default : 4201)

/* VDD services */
#ifdef __cplusplus
extern "C" {
#endif
#include <vddsvc.h>
#ifdef __cplusplus
}
#endif

#include "SwsVdd.h"
#include "debug.h"


/***************************************************************************
 * Macro definitions
 ***************************************************************************/
#define SWS_SERVICE IOCTL_DEVICE /* NDIS protocol driver service name */

/* Get a ptr to the start of a struct given a ptr to a field within it */
#define SWS_CONTAINER( ptr, type, field) \
  (type*)( (char*)(ptr) - offsetof( type, field) )

#define REGW( p, r, v) ((p)->r = (v))
#define MAKEADDR( seg, off) ((((ULONG)seg)<<16) | (off))

#define MAX_FRAME_SIZE 1514 /* Ethernet MTU=1500 (+14 byte MAC hdr), no FCS */

/* Packet driver interface classes */
#define CL_NONE         0
#define CL_ETHERNET     1
#define CL_PRONET_10    2
#define CL_IEEE8025     3
#define CL_OMNINET      4
#define CL_APPLETALK    5
#define CL_SERIAL_LINE  6
#define CL_STARLAN      7
#define CL_ARCNET       8
#define CL_AX25         9
#define CL_KISS         10
#define CL_IEEE8023     11
#define CL_FDDI         12
#define CL_INTERNET_X25 13
#define CL_LANSTAR      14
#define CL_SLFP         15
#define CL_NETROM       16
#define CL_PPP          17
#define CL_QTSO         18
#define NCLASS          19

/* Packet driver interface types (not a complete list) */
#define TC500           1U /* 3c500/501 */
#define PC2000          10
#define WD8003          14
#define PC8250          15
#define ANYTYPE         0xffff

/* Packet driver function call numbers */
#define DRIVER_INFO        1
#define ACCESS_TYPE        2
#define RELEASE_TYPE       3
#define SEND_PKT           4
#define TERMINATE          5
#define GET_ADDRESS        6
#define RESET_INTERFACE    7
/* Optional high performance functions */
#define GET_PARAMETERS     10
#define AS_SEND_PKT        11
/* Optional extended functions */
#define SET_RCV_MODE       20
#define GET_RCV_MODE       21
#define SET_MULTICAST_LIST 22
#define GET_MULTICAST_LIST 23
#define GET_STATISTICS     24
#define SET_ADDRESS        25

/* Packet driver error return codes. From Appendix C. */
#define BAD_HANDLE     1  /* invalid handle number */
#define NO_CLASS       2  /* no interfaces of specified class found */
#define NO_TYPE        3  /* no interfaces of specified type found */
#define NO_NUMBER      4  /* no interfaces of specified number found */
#define BAD_TYPE       5  /* bad packet type specified */
#define NO_MULTICAST   6  /* this interface does not support multicast */
#define CANT_TERMINATE 7  /* this packet driver cannot terminate */
#define BAD_MODE       8  /* an invalid receiver mode was specified */
#define NO_SPACE       9  /* operation failed because of insufficient space */
#define TYPE_INUSE     10 /* the type had previously been accessed, and not released */
#define BAD_COMMAND    11 /* the command was out of range, or not implemented */
#define CANT_SEND      12 /* the packet couldn't be sent (usually hardware error) */
#define CANT_SET       13 /* hardware address couldn't be changed (> 1 handle open) */
#define BAD_ADDRESS    14 /* hardware address has bad length or format */
#define CANT_RESET     15 /* couldn't reset interface (> 1 handle open) */


/***************************************************************************
 * Data types
 ***************************************************************************/

/* Double ended queue */
typedef struct SDeque 
  {
  struct SDeque* head;
  struct SDeque* tail;
  } SDeque;


/* DispatchCall(dx=1) client packet driver request */
#pragma pack(2)
typedef struct SPktRegs
  {
  USHORT AX;
  USHORT BX;
  USHORT CX;
  USHORT DX;
  USHORT DI;
  USHORT SI;
  USHORT DS;
  USHORT ES;
  } SPktRegs;
#pragma pack()
COMPILATION_REQUIRES( sizeof(SPktRegs) == 8*2);


/* Ethernet header */
#pragma pack(1)
typedef struct EnetMacAddress
  {
  UCHAR addr[6];                      /* A MAC address */
  } EnetMacAddress;
#pragma pack()
COMPILATION_REQUIRES( sizeof(EnetMacAddress) == 6);


/* Receive buffer */
typedef struct SRxBuffer
  {
  SDeque list;                        /* List of buffers */
#define LIST2RXBUF( p) SWS_CONTAINER( p, SRxBuffer, list)

  OVERLAPPED overlap;
#define OVL2RXBUF( p) SWS_CONTAINER( p, SRxBuffer, overlap)

  DWORD dwBytes;
  unsigned char buffer[ MAX_FRAME_SIZE];
  } SRxBuffer;


/* Transmit buffer */
typedef struct STxBuffer
  {
  SDeque list;                        /* List of buffers */
#define LIST2TXBUF( p) SWS_CONTAINER( p, STxBuffer, list)

  OVERLAPPED overlap;
#define OVL2TXBUF( p) SWS_CONTAINER( p, STxBuffer, overlap)

  struct SPacketDriver* pPacket;
  DWORD dwBytes;
  LPCVOID pvBuffer;                   /* -> mapped buffer */
  USHORT regDS, regSI;                /* Client buffer */
  USHORT regES, regDI;                /* Client completion routine */
  USHORT err;
  } STxBuffer;


/* Receive mode */
typedef enum ERxMode
  {
  kRxModeDisable = 0,
  kRxModeEnable,
  kRxModePromiscuous
  } ERxMode;


/* Interface instance */
typedef struct SPacketDriver
  {
  unsigned uMagic;
#define PACKET_MAGIC 'pkt2'

  HANDLE hDevice;                     /* Packet protocol driver */
  OVERLAPPED txOverlap;               /* For write requests */

  EnetMacAddress mac;                 /* Cached MAC address */
  int macAddrIsValid;                 /* !0 if cache is valid */
  ERxMode eRxMode;                    /* Receive mode */

  SDeque clientQ;                     /* Client list */

  HANDLE hWorker;                     /* Worker thread handle */
  int iWorkerExit;                    /* Worker thread is exiting */

  SRxBuffer rxBuffer[1];              /* VLA of Rx buffers */
  } SPacketDriver;


/* Client instance */
typedef struct SInstance
  {
  SDeque list;
#define LIST2INST( p) SWS_CONTAINER( p, SInstance, list)

  SPacketDriver* pPacket;
  USHORT h;                           /* Client handle */
  USHORT unType;                      /* Packet type */
  USHORT regES, regDI;                /* Client rx callback */
  USHORT uRxMode;                     /* Client Rx mode */
  } SInstance;

typedef USHORT HCLIENT;


/***************************************************************************
 * Function prototypes
 ***************************************************************************/

/* VDD operation */
static int PacketDriverRqst( SPktRegs*);
static int PacketDriverIack( void);
static void ClientRx( SPacketDriver*, SRxBuffer*, DWORD);
static void ClientTx( STxBuffer*);
static int SetRxMode( SPacketDriver* const);
static int GetAdapterName( unsigned, LPVOID, unsigned);

/* Process event callbacks */
static VOID ProcessBlock( VOID);
static VOID ProcessResume( VOID);
static VOID ProcessTerminate( USHORT DosPDB);
static VOID ProcessCreate( USHORT DosPDB);

/* Packet driver requests */
static int DriverInfo( SPktRegs*, LPVOID, unsigned);
static int AccessType( PUSHORT, unsigned, unsigned, unsigned, USHORT, USHORT, LPCVOID, unsigned);
static int ReleaseType( HCLIENT);
static int SendPkt( LPCVOID, unsigned);
static int GetAddress( PUSHORT, HCLIENT, LPVOID, unsigned);
static int ResetInterface( HCLIENT);
static int GetParameters( LPVOID, unsigned);
static int AsSendPkt( const SPktRegs* const, LPCVOID, unsigned);
static int SetRcvMode( HCLIENT, unsigned);
static int GetRcvMode( PUSHORT, HCLIENT);
static int SetMcastList( LPCVOID, unsigned);
static int GetMcastList( PUSHORT, LPVOID, unsigned);
static int GetStatistics( LPVOID, unsigned);
static int SetAddress( LPCVOID, unsigned);

static int SpecialOp1( PUSHORT, unsigned, unsigned, unsigned, USHORT, USHORT, LPCVOID, unsigned);

/* Protocol driver management */
static BOOL StartAService( const char*);
static BOOL AddPacketDriver( int, int);
static void FreePacketDriver( SPacketDriver*);
static BOOL OverlappedDeviceIoControl( HANDLE, DWORD, LPCVOID, DWORD, LPVOID, DWORD, LPDWORD);
static int PacketGetMacAddr( SPacketDriver* const, EnetMacAddress*);
static int SetPromiscuity( SPacketDriver* const, unsigned mode);
static int SetMulticastList( SPacketDriver* const, const void*, size_t);

/* Handle management */
static HCLIENT AllocHandle( void*);
static void* FreeHandle( HCLIENT);
static void* GetHandle( HCLIENT);

/* Worker thread */
static DWORD WINAPI Worker( LPVOID);
static VOID WINAPI StartReceivingApc( ULONG_PTR);
static VOID WINAPI StopReceivingApc( ULONG_PTR);
static BOOL QueueBuffer( SPacketDriver*, SRxBuffer*);
static VOID WINAPI ReceiveComplete( DWORD, DWORD, LPOVERLAPPED);
static VOID WINAPI ResubmitRxBufferApc( ULONG_PTR);
static VOID WINAPI SendBufferApc( ULONG_PTR);
static VOID WINAPI SendComplete( DWORD, DWORD, LPOVERLAPPED);

/* Double ended queue */
static SDeque* DequeRemove( SDeque* const);
static void DequeAppend( SDeque* const pDeque, SDeque* const pItem);
#define DEQUE_INIT( p)     ((p)->tail = (p)->head = (p))
#define DEQUE_IS_EMPTY( p) ((p)->tail == (p))
#define DEQUE_FIRST( p)    ((p)->tail)
#define DEQUE_LAST( p)     ((p)->head)


/***************************************************************************
 * Module data
 ***************************************************************************/
static size_t s_bufferCount = OPT_BUFFERS;

static HANDLE s_hHeap;
static BOOL s_bUserHook;      /* TRUE if user hook installed */
static BOOL s_bSuspended;     /* Process is suspened */
static CRITICAL_SECTION s_csIackQ; /* s_qIack protection */
static SDeque s_qIack;        /* List of completed buffers */

static int s_iClients;        /* No. registerd clients */
static UCHAR s_ucIrq;         /* H/w IRQ used by client */
static LONG s_lIrqPending;    /* No. pending IRQ's */

static unsigned s_uAdapters;
static SPacketDriver* s_apPacketDrivers[ OPT_PACKET_ADAPTERS];

/* Multicast list */
static unsigned char s_aucMcast[ sizeof(EnetMacAddress) * 8];
static unsigned s_uMcastLen;

/* Data for GET_STATISTICS */
#pragma pack(4)
static struct
  {
  unsigned long	packets_in;	  /* Totals across all handles */
  unsigned long	packets_out;
  unsigned long	bytes_in;	  /* Including MAC headers */
  unsigned long	bytes_out;
  unsigned long	errors_in;	  /* Totals across all error types */
  unsigned long	errors_out;
  unsigned long	packets_lost; /* No buffer from receiver(), card */
  } s_stats;
#pragma pack()

/* Data for GET_PARAMETERS */
#pragma pack(1)
static struct
  {
  unsigned char major_rev;  /* Revision of Packet Driver spec */
  unsigned char minor_rev;  /*  this driver conforms to. */
  unsigned char length;     /* Length of structure in bytes */
  unsigned char addr_len;   /* Length of a MAC-layer address */
  unsigned short mtu;       /* MTU, including MAC headers */
  unsigned short multicast_aval; /* Buffer size for multicast addr */
  unsigned short rcv_bufs;  /* (# of back-to-back MTU rcvs) - 1 */
  unsigned short xmt_bufs;  /* (# of successive xmits) - 1 */
  unsigned short int_num;   /* Interrupt # to hook for post-EOI processing, 0 == none */
  } s_params = {
    1, 9,
    sizeof( s_params),
    sizeof( EnetMacAddress),
    MAX_FRAME_SIZE,
    sizeof( s_aucMcast),
    OPT_BUFFERS - 1,
    4 - 1,
    0
  };
#pragma pack()

 
/***************************************************************************
 * Functions
 ***************************************************************************/
/*
 * Process attaching
 */
EXTERNC int PktAttach( HANDLE h)
  {
  int i;
  DWORD dwValue;
  BOOL bWanEnable = FALSE;

  TRACE( 9, ("PktAttach(0x%p)\n", h));

  /* Read config options */
  if ( VddReadRegValue( "Buffers", REG_DWORD, sizeof( dwValue), &dwValue)
    && dwValue > 1
  ) {
    s_bufferCount = (size_t)dwValue;
    }
  TRACE( 2, ("PktAttach() %u buffers\n", s_bufferCount));

  if ( VddReadRegValue( "WanEnable", REG_DWORD, sizeof( dwValue), &dwValue))
    bWanEnable = 0 != dwValue;
  TRACE( 2, ("PktAttach() WanEnable:%d\n", (int)bWanEnable));

  /* Create a heap */
  ASSERT( NULL == s_hHeap);
  s_hHeap = HeapCreate( 0, 0, 0);
  if ( NULL == s_hHeap)
    {
    TRACE( 0, ("!!! PktAttach() HeapCreate failed %#lx\n", GetLastError()));
    return FALSE;
    }

  InitializeCriticalSection( &s_csIackQ);
  DEQUE_INIT( &s_qIack);

  // Install user hook
  s_bUserHook = VDDInstallUserHook(
    h,
    &ProcessCreate,
    &ProcessTerminate,
    &ProcessBlock,
    &ProcessResume
  );
  if ( !s_bUserHook)
    TRACE( 0, ("!!! PktAttach() StartAService VDDInstallUserHook failed\n"));

  /* Start the protocol driver service */
  if ( !StartAService( SWS_SERVICE))
    TRACE( 1, ("*** PktAttach() StartAService(" SWS_SERVICE ") failed\n"));

  /* Search for packet drivers */
  for ( i = 0; i < OPT_PACKET_ADAPTERS; ++i)
    AddPacketDriver( i, bWanEnable);

  return TRUE;
  }


/*
 * Process detaching
 */
EXTERNC void PktDetach( HANDLE h)
  {
  unsigned u;

  TRACE( 9, ("PktDetach(0x%p)\n", h));

  /* Close all SwsVpkt devices */
  for ( u = 0; u < s_uAdapters; ++u)
    {
    SPacketDriver* const pPacket = s_apPacketDrivers[ u];
    ASSERT( NULL != pPacket);
    ASSERT( PACKET_MAGIC == pPacket->uMagic);
    
    s_apPacketDrivers[ u] = NULL;
    FreePacketDriver( pPacket);
    }
  s_uAdapters = 0;

  if ( s_bUserHook)
    {
    s_bUserHook = FALSE;
    VDDDeInstallUserHook( h);
    }

  /* Deallocate local heap */
  if ( NULL != s_hHeap)
    {
    HeapDestroy( s_hHeap);
    s_hHeap = NULL;
    }

  DeleteCriticalSection( &s_csIackQ);
  }


/*
 * UserHook callbacks
 */
VOID ProcessCreate( USHORT uDosPDB)
  {
  (void)uDosPDB;
  TRACE( 2, ("ProcessCreate(%#04x)\n",uDosPDB));
  }

VOID ProcessTerminate( USHORT uDosPDB)
  {
  (void)uDosPDB;
  TRACE( 2, ("ProcessTerminate(%#04x)\n",uDosPDB));
  }

VOID ProcessBlock( VOID)
  {
  unsigned u;

  TRACE( 2, ("ProcessBlock()\n"));
  ASSERT( !s_bSuspended);
  s_bSuspended = TRUE;

  for ( u = 0; u < s_uAdapters; ++u)
    {
    SPacketDriver* const pPacket = s_apPacketDrivers[ u];
    ASSERT( NULL != pPacket);
    ASSERT( PACKET_MAGIC == pPacket->uMagic);

    if ( kRxModeDisable != pPacket->eRxMode)
      VERIFY( QueueUserAPC( &StopReceivingApc, pPacket->hWorker, (ULONG_PTR)pPacket));
    }
  }

VOID ProcessResume( VOID)
  {
  unsigned u;

  TRACE( 2, ("ProcessResume()\n"));
  ASSERT( s_bSuspended);
  s_bSuspended = FALSE;

  for ( u = 0; u < s_uAdapters; ++u)
    {
    SPacketDriver* const pPacket = s_apPacketDrivers[ u];
    ASSERT( NULL != pPacket);
    ASSERT( PACKET_MAGIC == pPacket->uMagic);

    if ( kRxModeDisable != pPacket->eRxMode)
      VERIFY( QueueUserAPC( &StartReceivingApc, pPacket->hWorker, (ULONG_PTR)pPacket));
    }
  }


/*
 * Client registering
 */
EXTERNC int PktRegister( USHORT ax, USHORT dx)
  {
  (void)dx;
  TRACE( 2, ("PktRegister(IRQ=%u,dx=%u) => %u adapters\n", ax, dx, s_uAdapters));
  ASSERT( s_iClients >= 0); 

  if ( ++s_iClients > 1 && s_ucIrq != ax)
    {
    TRACE( 1, ("*** PktRegister(IRQ=%u) already using %u\n", ax, s_ucIrq));
    return FALSE;
    }

  s_params.int_num = s_ucIrq = (UCHAR)ax;
  s_params.rcv_bufs = (unsigned short)(s_bufferCount - 1);

  /* Return no. adapters in DX */
  setDX( (USHORT)s_uAdapters);
  return TRUE;
  }


/*
 * Client DispatchCall
 */
EXTERNC int PktDispatch( void)
  {
  int iRet = 0;
  SPktRegs* p;
  LPVOID pv;

  TRACE( 9, ("PktDispatch()\n"));
  ASSERT( s_iClients > 0);

  switch ( getDX())
    {
  case 1:
    /* ES:BX -> SPktRegs, DS:SI -> buffer len CX */
    #if DDK_VERSION >= 50
    p = (SPktRegs*) VdmMapFlat( getES(), getBX(), VDM_V86);
    #else
    p = (SPktRegs*) GetVDMPointer( MAKEADDR( getES(), getBX()), sizeof(*p), 0);
    #endif

    iRet = PacketDriverRqst( p);

    #if DDK_VERSION >= 50
    VdmUnmapFlat( getES(), getBX(), p, VDM_V86);
    #else
    FreeVDMPointer( MAKEADDR( getES(), getBX()), sizeof(*p), p, 0);
    #endif
    break;

  case 2:
    /* ES:DI -> callback */
    iRet = PacketDriverIack();
    break;

  case 3: /* Get adapter description */
    /* DS:SI -> buffer, len CX, BX= interface */
    #if DDK_VERSION >= 50
    pv = VdmMapFlat( getDS(), getSI(), VDM_V86);
    #else
    pv = GetVDMPointer( MAKEADDR( getDS(), getSI()), getCX(), 0);
    #endif

    iRet = GetAdapterName( getBX(), pv, getCX());

    #if DDK_VERSION >= 50
    VdmUnmapFlat( getDS(), getSI(), pv, VDM_V86);
    #else
    FreeVDMPointer( MAKEADDR( getDS(), getSI()), getCX(), pv, 0);
    #endif
    break;

  default:
    TRACE( 1, ("*** PktDispatch(DX=%u)\n", getDX()));
    iRet = 0;
    break;
    }

  return iRet;
  }


/*
 * Handle reflected packet driver requests
 * DS:SI -> buffer len CX
 */
int PacketDriverRqst( SPktRegs* pRegs)
  {
  USHORT const regDS = getDS(), regSI = getSI();
  USHORT const regCX = getCX();
  LPVOID pv, pvComm;
  unsigned uLen;
  int iErr;

  TRACE( 9, ("PacketDriverRqst(0x%p)\n", pRegs));
  ASSERT( NULL != pRegs);

  /* Map the common buffer */
  #if DDK_VERSION >= 50
  pvComm = VdmMapFlat( regDS, regSI, VDM_V86);
  #else
  pvComm = GetVDMPointer( MAKEADDR( regDS, regSI), regCX, 0);
  #endif

  /* PacketDriverRqst request in AH */
  switch ( pRegs->AX >> 8)
    {
  case DRIVER_INFO:
    TRACE( 2, ("PacketDriverRqst(DRIVER_INFO)\n"));
    iErr = DriverInfo( pRegs, pvComm, regCX);
    if ( 0 == iErr)
      pRegs->DS = regDS, pRegs->SI = regSI;
    break;

  case ACCESS_TYPE:
    TRACE( 2, ("PacketDriverRqst(ACCESS_TYPE)\n"));
    uLen = pRegs->CX;
    if ( uLen)
      {
      #if DDK_VERSION >= 50
      pv = VdmMapFlat( pRegs->DS, pRegs->SI, VDM_V86);
      #else
      pv = GetVDMPointer( MAKEADDR( pRegs->DS, pRegs->SI), uLen, 0);
      #endif
      }
    else
      pv = NULL;

    iErr = AccessType( &pRegs->AX,
      pRegs->AX & 0xff, pRegs->BX, pRegs->DX & 0xff,
      pRegs->ES, pRegs->DI,
      pv, uLen
    );
    if ( 0 == iErr)
      TRACE( 2, ("PacketDriverRqst(ACCESS_TYPE) %04x:%04x => handle %u\n",pRegs->ES,pRegs->DI,pRegs->AX));

    if ( uLen)
      {
      #if DDK_VERSION >= 50
      VdmUnmapFlat( pRegs->DS, pRegs->SI, pv, VDM_V86);
      #else
      FreeVDMPointer( MAKEADDR( pRegs->DS, pRegs->SI), uLen, pv, 0);
      #endif
      }

    break;

  case RELEASE_TYPE:
    TRACE( 2, ("PacketDriverRqst(RELEASE_TYPE) handle %u\n", pRegs->BX));
    iErr = ReleaseType( pRegs->BX);
    break;

  case SEND_PKT:
    uLen = pRegs->CX;
    TRACE( 3, ("PacketDriverRqst(SEND_PKT) %u bytes\n", uLen));

    #if DDK_VERSION >= 50
    pv = VdmMapFlat( pRegs->DS, pRegs->SI, VDM_V86);
    #else
    pv = GetVDMPointer( MAKEADDR( pRegs->DS, pRegs->SI), uLen, 0);
    #endif

    iErr = SendPkt( pv, uLen);

    #if DDK_VERSION >= 50
    VdmUnmapFlat( pRegs->DS, pRegs->SI, pv, VDM_V86);
    #else
    FreeVDMPointer( MAKEADDR( pRegs->DS, pRegs->SI), uLen, pv, 0);
    #endif
    break;

  case TERMINATE:
    TRACE( 2, ("PacketDriverRqst(TERMINATE) handle %u, CX=%u\n",
      pRegs->BX,pRegs->CX));
    ASSERT( s_iClients > 0);

    if ( pRegs->CX == s_ucIrq
      && 0 == --s_iClients
    ) {
      s_ucIrq = 0;
      }

    iErr = 0;
    break;

  case GET_ADDRESS:
    TRACE( 2, ("PacketDriverRqst(GET_ADDRESS) handle %u\n",pRegs->BX));
    uLen = pRegs->CX;
    #if DDK_VERSION >= 50
    pv = VdmMapFlat( pRegs->ES, pRegs->DI, VDM_V86);
    #else
    pv = GetVDMPointer( MAKEADDR( pRegs->ES, pRegs->DI), uLen, 0);
    #endif

    iErr = GetAddress( &pRegs->CX, pRegs->BX, pv, uLen);

    #if DDK_VERSION >= 50
    VdmUnmapFlat( pRegs->ES, pRegs->DI, pv, VDM_V86);
    #else
    FreeVDMPointer( MAKEADDR( pRegs->ES, pRegs->DI), uLen, pv, 0);
    #endif
    break;

  case RESET_INTERFACE:
    TRACE( 2, ("PacketDriverRqst(RESET_INTERFACE) handle %u\n", pRegs->BX));
    iErr = ResetInterface( pRegs->BX);
    break;

    /* Optional high performance functions */
  case GET_PARAMETERS:
    TRACE( 2, ("PacketDriverRqst(GET_PARAMETERS)\n"));
    iErr = GetParameters( pvComm, regCX);
    if ( 0 == iErr)
      pRegs->ES = regDS, pRegs->DI = regSI;
    break;

  case AS_SEND_PKT:
    uLen = pRegs->CX;
    TRACE( 3, ("PacketDriverRqst(AS_SEND_PKT) %u bytes\n", uLen));

    #if DDK_VERSION >= 50
    pv = VdmMapFlat( pRegs->DS, pRegs->SI, VDM_V86);
    #else
    pv = GetVDMPointer( MAKEADDR( pRegs->DS, pRegs->SI), uLen, 0);
    #endif

    iErr = AsSendPkt( pRegs, pv, uLen);
    if ( iErr)
      {
      #if DDK_VERSION >= 50
      VdmUnmapFlat( pRegs->DS, pRegs->SI, pv, VDM_V86);
      #else
      FreeVDMPointer( MAKEADDR( pRegs->DS, pRegs->SI), uLen, pv, 0);
      #endif
      }
    break;

    /* Extended functions */
  case SET_RCV_MODE:
    TRACE( 2, ("PacketDriverRqst(SET_RCV_MODE,%u) handle %u\n",
      pRegs->CX,pRegs->BX));
    iErr = SetRcvMode( pRegs->BX, pRegs->CX);
    break;

  case GET_RCV_MODE:
    TRACE( 2, ("PacketDriverRqst(GET_RCV_MODE) handle %u\n",pRegs->BX));
    iErr = GetRcvMode( &pRegs->AX, pRegs->BX);
    break;

  case SET_MULTICAST_LIST:
    TRACE( 2, ("PacketDriverRqst(SET_MULTICAST_LIST) len %u\n",pRegs->CX));
    uLen = pRegs->CX;
    if ( uLen)
      {
      #if DDK_VERSION >= 50
      pv = VdmMapFlat( pRegs->ES, pRegs->DI, VDM_V86);
      #else
      pv = GetVDMPointer( MAKEADDR( pRegs->ES, pRegs->DI), uLen, 0);
      #endif
      }
    else
      pv = NULL;

    iErr = SetMcastList( pv, uLen);

    if ( uLen)
      {
      #if DDK_VERSION >= 50
      VdmUnmapFlat( pRegs->ES, pRegs->DI, pv, VDM_V86);
      #else
      FreeVDMPointer( MAKEADDR( pRegs->ES, pRegs->DI), uLen, pv, 0);
      #endif
      }
    break;

  case GET_MULTICAST_LIST:
    TRACE( 2, ("PacketDriverRqst(GET_MULTICAST_LIST)\n"));
    iErr = GetMcastList( &pRegs->CX, pvComm, regCX);
    if ( 0 == iErr)
      pRegs->ES = regDS, pRegs->DI = regSI;
    break;

  case GET_STATISTICS:
    TRACE( 2, ("PacketDriverRqst(GET_STATISTICS)\n"));
    iErr = GetStatistics( pvComm, regCX);
    if ( 0 == iErr)
      pRegs->DS = regDS, pRegs->SI = regSI;
    break;

  case SET_ADDRESS:
    TRACE( 2, ("PacketDriverRqst(SET_ADDRESS)\n"));

    uLen = pRegs->CX;
    #if DDK_VERSION >= 50
    pv = VdmMapFlat( pRegs->ES, pRegs->DI, VDM_V86);
    #else
    pv = GetVDMPointer( MAKEADDR( pRegs->ES, pRegs->DI), uLen, 0);
    #endif

    iErr = SetAddress( pv, uLen);

    #if DDK_VERSION >= 50
    VdmUnmapFlat( pRegs->ES, pRegs->DI, pv, VDM_V86);
    #else
    FreeVDMPointer( MAKEADDR( pRegs->ES, pRegs->DI), uLen, pv, 0);
    #endif
    break;

  case 0x80:
    TRACE( 2, ("PacketDriverRqst(SpecialOp1)\n"));
    uLen = pRegs->CX;
    if ( uLen)
      {
      #if DDK_VERSION >= 50
      pv = VdmMapFlat( pRegs->DS, pRegs->SI, VDM_V86);
      #else
      pv = GetVDMPointer( MAKEADDR( pRegs->DS, pRegs->SI), uLen, 0);
      #endif
      }
    else
      pv = NULL;

    iErr = SpecialOp1( &pRegs->AX,
      pRegs->AX & 0xff, pRegs->BX, pRegs->DX & 0xff,
      pRegs->ES, pRegs->DI,
      pv, uLen
    );
    if ( 0 == iErr)
      TRACE( 2, ("PacketDriverRqst(SpecialOp1) %04x:%04x => handle %u\n",pRegs->ES,pRegs->DI,pRegs->AX));

    if ( uLen)
      {
      #if DDK_VERSION >= 50
      VdmUnmapFlat( pRegs->DS, pRegs->SI, pv, VDM_V86);
      #else
      FreeVDMPointer( MAKEADDR( pRegs->DS, pRegs->SI), uLen, pv, 0);
      #endif
      }
    break;

  default:
    TRACE( 1, ("*** PacketDriverRqst(Func %u) Not implemented\n",
      pRegs->AX >> 8));
    iErr = BAD_COMMAND;
    break;
    }

  /* Un-map the common buffer */
  #if DDK_VERSION >= 50
  VdmUnmapFlat( regDS, regSI, pvComm, VDM_V86);
  #else
  FreeVDMPointer( MAKEADDR( regDS, regSI), regCX, pvComm, 0);
  #endif

  if ( 0 == iErr)
    return TRUE;

  /* Error return */
  pRegs->DX = (USHORT)((pRegs->DX & 0xff) | (iErr << 8));
  return FALSE;
  }


/*
 * Handle DRIVER_INFO
 */
int DriverInfo( SPktRegs* pRegs, LPVOID pvComm, unsigned uLen)
  {
  TRACE( 9, ("DriverInfo(%p,%p,%u)\n", pRegs,pvComm,uLen));

  if ( s_uAdapters > 0)
    {
    static const char kszName[] = SWS_SERVICE;

    if ( uLen >= sizeof( kszName))
      {
      RtlCopyMemory( pvComm, kszName, sizeof( kszName));
      }
    else
      {
      TRACE( 1, ("*** DriverInfo buffer is %u bytes, need %u bytes\n",
        uLen, sizeof( kszName) ));
      if ( uLen)
        *(char*)pvComm = '\0';
      }

    REGW( pRegs, AX, (DRIVER_INFO << 8) | 6); /* 6= basic, hi-perf & extended */
    REGW( pRegs, BX, (VER_MAJOR << 8) | VER_MINOR);
    REGW( pRegs, CX, (USHORT)((CL_ETHERNET << 8) | (s_uAdapters - 1)));
    REGW( pRegs, DX, TC500);
    }
  else
    {
    TRACE( 1, ("*** DriverInfo no adapters\n"));
    }

  return 0;
  }


/*
 * Handle ACCESS_TYPE
 */
int AccessType(
  PUSHORT punH,
  unsigned uClass, unsigned uType, unsigned uNum,
  USHORT regES, USHORT regDI,
  LPCVOID pv, unsigned uLen
) {
  SPacketDriver* pPacket;
  SInstance* pInstance;
  HCLIENT h;

  TRACE( 9, ("AccessType(%p,%u,%u,%u,%u,%u,%p,%u)\n",
    punH,uClass,uType,uNum,regES,regDI,pv,uLen));
  ASSERT( NULL != punH);
  ASSERT( s_iClients > 0);

  if ( uClass != CL_ETHERNET)
    {
    TRACE( 1, ("*** AccessType unsupported class %u\n", uClass));
    return NO_CLASS;
    }

  if ( uType != ANYTYPE
    && uType != TC500
  ) {
    TRACE( 1, ("*** AccessType unsupported type %u\n", uType));
    return NO_TYPE;
    }

  /* Check if interface is available */
  if ( uNum >= s_uAdapters)
    {
    TRACE( 1, ("*** AccessType unsupported iface %u\n", uNum));
    return NO_NUMBER;
    }
  pPacket = s_apPacketDrivers[ uNum];
  ASSERT( NULL != pPacket);
  ASSERT( PACKET_MAGIC == pPacket->uMagic);

  /* Alloc instance data */
  pInstance = (SInstance*) HeapAlloc(
    s_hHeap, HEAP_ZERO_MEMORY, sizeof(*pInstance));
  if ( NULL == pInstance)
    {
    TRACE( 0, ("!!! AccessType Out of memory\n"));
    return NO_SPACE;
    }

  /* Get a handle */
  h = AllocHandle( pInstance);
  if ( 0 == h)
    {
    TRACE( 1, ("*** AccessType) Out of handles\n"));
    HeapFree( s_hHeap, 0, pInstance);
    return NO_SPACE;
    }

  /* Is packet type specified? */
  if ( 0 == uLen)
    {
    /* No, any type */
    pInstance->unType = 0;
    }
  /* Or ethernet type? */
  else if ( 2 == uLen)
    {
    /* NB the type is in network byte order (MSB first) */
    pInstance->unType = (USHORT)( (((const UCHAR*)pv)[0] << 8) + ((const UCHAR*)pv)[1]);
    TRACE( 2, ("AccessType pkt type %#04x\n", pInstance->unType));
    }
  else
    {
    TRACE( 1, ("*** AccessType invalid type length %u\n", uLen));
    HeapFree( s_hHeap, 0, FreeHandle( h));
    return BAD_TYPE;
    }

  pInstance->pPacket = pPacket;
  pInstance->h = h;
  pInstance->regES = regES;
  pInstance->regDI = regDI;
  pInstance->uRxMode = 3;

  /* Add to list of clients */
  DEQUE_INIT( &pInstance->list);
  DequeAppend( &pPacket->clientQ, &pInstance->list);
  SetRxMode( pPacket);

  *punH = h;
  return 0;
  }


/*
 * Handle SpecialOp1
 */
int SpecialOp1(
  PUSHORT punH,
  unsigned uClass, unsigned uType, unsigned uNum,
  USHORT regES, USHORT regDI,
  LPCVOID pv, unsigned uLen
) {
  static const char kszIdent[] = IOCTL_DEVICE;

  TRACE( 9, ("SpecialOp1(%p,%u,%u,%u,%u,%u,%p,%u)\n",
    punH,uClass,uType,uNum,regES,regDI,pv,uLen));
  ASSERT( NULL != punH);
  ASSERT( s_iClients > 0);

  if ( uClass != 'S')
    {
    TRACE( 1, ("*** SpecialOp1 unsupported class %u\n", uClass));
    return NO_CLASS;
    }

  if ( uType != 0x1234)
    {
    TRACE( 1, ("*** SpecialOp1 unsupported type %u\n", uType));
    return NO_TYPE;
    }

  if ( uLen != sizeof( kszIdent) - 1)
    {
    TRACE( 1, ("*** SpecialOp1 invalid typelen %u\n", uLen));
    return BAD_TYPE;
    }

  if ( memcmp( pv, kszIdent, sizeof( kszIdent) - 1))
    {
    TRACE( 1, ("*** SpecialOp1 invalid packet type\n"));
#if 0 /* DJGPP DEBUG build has problems here so disable */
    return TYPE_INUSE;
#endif
    }

  return AccessType(
    punH, CL_ETHERNET, ANYTYPE, uNum, regES, regDI, NULL, 0);
  }

  
/*
 * Handle RELEASE_TYPE
 */
int ReleaseType( USHORT h)
  {
  SPacketDriver* pPacket;
  SInstance* pInstance;

  TRACE( 9, ("ReleaseType(%u)\n", h));

  pInstance = (SInstance*) FreeHandle( h);
  if ( NULL == pInstance)
    {
    TRACE( 1, ("ReleaseType bad handle %u\n", h));
    return BAD_HANDLE;
    }

  pPacket = pInstance->pPacket;
  ASSERT( NULL != pPacket);
  ASSERT( PACKET_MAGIC == pPacket->uMagic);

  DequeRemove( &pInstance->list);
  SetRxMode( pPacket);

  HeapFree( s_hHeap, 0, pInstance);
  return 0;
  }


/*
 * Handle SEND_PKT
 */
int SendPkt( LPCVOID pv, unsigned uLen)
  {
  SPacketDriver* pPacket;
  unsigned u;
  BOOL bRet;
  DWORD dwWritten;

  TRACE( 9, ("SendPkt(%p,%u)\n",pv,uLen));

  /* Find matching interface */
  pPacket = NULL;
  for ( u = 0; u < s_uAdapters; ++u)
    {
    ASSERT( PACKET_MAGIC == s_apPacketDrivers[ u]->uMagic);
    if ( RtlEqualMemory(
      &(s_apPacketDrivers[ u]->mac), ((EnetMacAddress*)pv) + 1, sizeof( EnetMacAddress)
      )
    ) {
      pPacket = s_apPacketDrivers[ u];
      break;
      }
    }

  if ( NULL == pPacket)
    {
    TRACE( 1, ("SendPkt invalid source address\n"));
    return CANT_SEND;
    }

  pPacket->txOverlap.Offset = 0;
  pPacket->txOverlap.OffsetHigh = 0;
  bRet = WriteFile(
    pPacket->hDevice,
    pv,
    uLen,
    &dwWritten,
    &pPacket->txOverlap
  );
  if ( !bRet && ERROR_IO_PENDING == GetLastError())
    {
    /* Wait for completion */
    bRet = GetOverlappedResult(
      pPacket->hDevice, &pPacket->txOverlap, &dwWritten, TRUE);
    }

  if ( bRet)
    {
    s_stats.packets_out++;
    s_stats.bytes_out += dwWritten;
    }
  else
    {
    TRACE( 1, ("*** SendPkt WriteFile error %#lx\n",GetLastError() ));
    s_stats.errors_out++;
    return CANT_SEND;
    }

  return 0;
  }


/*
 * Handle GET_ADDRESS
 */
int GetAddress( PUSHORT punSize, HCLIENT h, LPVOID pv, unsigned uLen)
  {
  SPacketDriver* pPacket;
  SInstance* pInstance;

  TRACE( 9, ("GetAddress(%p,%u,%p,%u)\n", punSize,h,pv,uLen));
  ASSERT( NULL != punSize);

  pInstance = (SInstance*) GetHandle( h);
  if ( NULL == pInstance)
    {
    TRACE( 1, ("*** GetAddress bad handle %u\n",h));
    return BAD_HANDLE;
    }

  if ( uLen < sizeof( EnetMacAddress))
    {
    TRACE( 1, ("*** GetAddress buffer too small\n"));
    return NO_SPACE;
    }

  pPacket = pInstance->pPacket;
  ASSERT( NULL != pPacket);
  ASSERT( PACKET_MAGIC == pPacket->uMagic);

  if ( PacketGetMacAddr( pPacket, (EnetMacAddress*)pv))
    {
    TRACE( 1, ("*** GetAddress system error\n"));
    return BAD_ADDRESS;
    }

  *punSize = sizeof( EnetMacAddress);
  return 0;
  }


/*
 * Handle RESET_INTERFACE
 */
int ResetInterface( HCLIENT h)
  {
  SPacketDriver* pPacket;
  SInstance* pInstance;

  TRACE( 9, ("ResetInterface(%u)\n",h));

  pInstance = (SInstance*) GetHandle( h);
  if ( NULL == pInstance)
    {
    TRACE( 1, ("*** ResetInterface bad handle %u\n", h));
    return BAD_HANDLE;
    }

  pPacket = pInstance->pPacket;
  ASSERT( NULL != pPacket);
  ASSERT( PACKET_MAGIC == pPacket->uMagic);

  pInstance->uRxMode = 3;
  SetRxMode( pPacket);

  return 0;
  }


/*
 * Handle GET_PARAMETERS
 */
int GetParameters( LPVOID pvComm, unsigned uLen)
  {
  TRACE( 9, ("GetParameters(%p,%u)\n", pvComm,uLen));

  if ( uLen < sizeof( s_params))
    {
    TRACE( 1, ("*** ResetInterface buffer too small\n"));
    return NO_SPACE;
    }

  RtlCopyMemory( pvComm, &s_params, sizeof( s_params));
  return 0;
  }


/*
 * Handle AS_SEND_PKT
 */
int AsSendPkt( const SPktRegs* const pRegs, LPCVOID pv, unsigned uLen)
  {
  SPacketDriver* pPacket;
  STxBuffer* pBuffer;
  unsigned u;

  TRACE( 9, ("AsSendPkt(0x%p,%p,%u)\n", pRegs,pv,uLen));

  /* Alloc a Tx context */
  pBuffer = (STxBuffer*) HeapAlloc( s_hHeap, HEAP_ZERO_MEMORY, sizeof(*pBuffer));
  if ( NULL == pBuffer)
    {
    TRACE( 0, ("!!! AsSendPkt Out of memory\n"));
    return CANT_SEND;
    }

  /* Find matching interface */
  pPacket = NULL;
  for ( u = 0; u < s_uAdapters; ++u)
    {
    ASSERT( PACKET_MAGIC == s_apPacketDrivers[ u]->uMagic);
    if ( RtlEqualMemory(
      &(s_apPacketDrivers[ u]->mac), ((EnetMacAddress*)pv) + 1, sizeof( EnetMacAddress)
      )
    ) {
      /* Matched */
      pPacket = s_apPacketDrivers[ u];
      break;
      }
    }

  if ( NULL == pPacket)
    {
    TRACE( 1, ("*** AsSendPkt invalid source address\n"));
    HeapFree( s_hHeap, 0, pBuffer);
    return CANT_SEND;
    }

  TRACE( 3, ("AsSendPkt buffer %p\n",pBuffer));
  pBuffer->pPacket = pPacket;
  pBuffer->dwBytes = uLen;
  pBuffer->pvBuffer = pv;
  pBuffer->regDS = pRegs->DS, pBuffer->regSI = pRegs->SI;
  pBuffer->regES = pRegs->ES, pBuffer->regDI = pRegs->DI; /* Callback */

  /* Request worker thread to send it */
  VERIFY( QueueUserAPC( &SendBufferApc, pPacket->hWorker, (ULONG_PTR)pBuffer));
  return 0;
  }


/*
 * Handle SET_RCV_MODE
 */
int SetRcvMode( HCLIENT h, unsigned uMode)
  {
  SPacketDriver* pPacket;
  SInstance* pInstance;

  TRACE( 9, ("SetRcvMode(%u,%u)\n",h,uMode));

  pInstance = (SInstance*) GetHandle( h);
  if ( NULL == pInstance)
    {
    TRACE( 1, ("*** SetRcvMode bad handle %u\n",h));
    return BAD_HANDLE;
    }

  pPacket = pInstance->pPacket;
  ASSERT( NULL != pPacket);
  ASSERT( PACKET_MAGIC == pPacket->uMagic);

  switch ( uMode)
    {
  case 1: /* Disable Rx */
  case 2: /* Rx all packets sent to this interface */
  case 3: /* Mode 2 + broadcasts */
  case 4: /* Mode 2 + limited multicasts */
  case 5: /* Mode 2 + all multicasts */
  case 6: /* All packets */
    pInstance->uRxMode = (USHORT)uMode;
    break;

  default:
    TRACE( 1, ("*** SetRcvMode invalid value %u\n", uMode));
    return BAD_MODE;
    }

  if ( 0 != SetRxMode( pPacket))
    {
    TRACE( 1, ("*** SetRcvMode system error\n"));
    return BAD_MODE;
    }

  return 0;
  }


/*
 * Handle GET_RCV_MODE
 */
int GetRcvMode( PUSHORT punMode, HCLIENT h)
  {
  SInstance* pInstance;

  TRACE( 9, ("GetRcvMode(%p,%u)\n", punMode, h));
  ASSERT( NULL != punMode);

  pInstance = (SInstance*) GetHandle( h);
  if ( NULL == pInstance)
    {
    TRACE( 1, ("*** GetRcvMode bad handle %u\n",h));
    return BAD_HANDLE;
    }

  *punMode = pInstance->uRxMode;
  return 0;
  }



/*
 * Handle SET_MULTICAST_LIST
 */
static int SetMcastList( LPCVOID pv, unsigned uLen)
  {
  int iRet = 0;
  unsigned u;

  TRACE( 9, ("SetMcastList(%p,%u)\n",pv,uLen));

  if ( uLen > sizeof( s_aucMcast))
    {
    TRACE( 1, ("*** SetMcastList too big\n"));
    return NO_SPACE;
    }

  /* All interfaces */
  for ( u = 0; u < s_uAdapters; ++u)
    {
    if ( SetMulticastList( s_apPacketDrivers[ u], pv, uLen))
      iRet = NO_MULTICAST;
    }

  if ( 0 == iRet)
    {
    /* Save the list */
    RtlCopyMemory( s_aucMcast, pv, uLen);
    s_uMcastLen = uLen;
    }

  return iRet;
  }


/*
 * Handle GET_MULTICAST_LIST
 */
int GetMcastList( PUSHORT punLen, LPVOID pvComm, unsigned uLen)
  {
  TRACE( 9, ("GetMcastList(%p,%u)\n", pvComm,uLen));

  if ( uLen < s_uMcastLen)
    {
    TRACE( 1, ("*** GetMcastList buffer too small\n"));
    return NO_SPACE;
    }

  RtlCopyMemory( pvComm, s_aucMcast, s_uMcastLen);
  *punLen = (USHORT)s_uMcastLen;

  return 0;
  }


/*
 * Handle GET_STATISTICS
 */
int GetStatistics( LPVOID pvComm, unsigned uLen)
  {
  TRACE( 9, ("GetStatistics(%p,%u)\n",pvComm,uLen));

  if ( uLen < sizeof( s_stats))
    {
    TRACE( 1, ("*** GetStatistics buffer too small\n"));
    return NO_SPACE;
    }

  RtlCopyMemory( pvComm, &s_stats, sizeof( s_stats));
  return 0;
  }


/*
 * Handle SET_ADDRESS
 */
int SetAddress( LPCVOID pv, unsigned uLen)
  {
  (void)pv;
  TRACE( 9, ("SetAddress(%p,%u)\n",pv,uLen));

  if ( uLen != sizeof( EnetMacAddress))
    {
    TRACE( 1, ("*** SetAddress invalid size %u\n",uLen));
    return BAD_ADDRESS;
    }

  TRACE( 1, ("*** SetAddress not implementd\n"));
  return CANT_SET;
  }


/*
 * DOS client interrupt ack
 * ES:DI -> callback
 */
int PacketDriverIack( void)
  {
  TRACE( 3, ("PacketDriverIack()\n"));

  InterlockedExchange( &s_lIrqPending, 0);

  /* Process completed buffers */
  EnterCriticalSection( &s_csIackQ);
  while ( !DEQUE_IS_EMPTY( &s_qIack))
    {
    SRxBuffer* const pBuffer = LIST2RXBUF( DequeRemove( DEQUE_FIRST( &s_qIack)));
    LeaveCriticalSection( &s_csIackQ);

    if ( pBuffer->overlap.hEvent)
      {
      SPacketDriver* const pPacket = (SPacketDriver*)pBuffer->overlap.hEvent;
      ASSERT( PACKET_MAGIC == pPacket->uMagic);

      ClientRx( pPacket, pBuffer, pBuffer->dwBytes);

      /* Resubmit the buffer if worker is running */
      if ( !pPacket->iWorkerExit)
        VERIFY( QueueUserAPC( &ResubmitRxBufferApc, pPacket->hWorker, (ULONG_PTR)pBuffer));
      }
    else
      {
      ClientTx( (STxBuffer*)pBuffer);
      }

    EnterCriticalSection( &s_csIackQ);
    }
  LeaveCriticalSection( &s_csIackQ);

  return TRUE;
  }


/*
 * Make a receive indication to each client
 * ES:DI -> callback
 */
void ClientRx( SPacketDriver* pPacket, SRxBuffer* pBuffer, DWORD dwBytes)
  {
  SDeque* pDeque, *pNext;
  USHORT const regDS = getDS(), regSI = getSI();
  USHORT const regES = getES(), regDI = getDI();
  USHORT const regCS = getCS(), regIP = getIP();
  USHORT const regSP = getSP(), regBP = getBP();

  TRACE( 9, ("ClientRx(%p,%p,%lu)\n",pPacket, pBuffer, dwBytes));

  pNext = NULL;
  for (
    pDeque = DEQUE_FIRST( &pPacket->clientQ);
    pDeque != &pPacket->clientQ;
    pDeque = pNext
  ) {
    USHORT clientES, clientDI;
    SInstance* const pInst = LIST2INST( pDeque);

    pNext = DEQUE_FIRST( pDeque);

#if 0 /* RxMode filtering */
    {
    /* MAC broadcast address */
    static const EnetMacAddress kMacBroadcast = {
      {0xff, 0xff, 0xff, 0xff, 0xff, 0xff}
    };
    /* Check for broadcast - look at the multicast bit */
    int const isMulticast = pBuffer->buffer[0] & 1;

    switch ( pInst->uRxMode)
      {
    case 0:
    case 1:
      /* Rx disabled */
      continue;

    case 2:
      /* Directed only */
      if ( isMulticast)
        {
        TRACE( 3, ("ClientRx() Directed only\n"));
        continue;
        }
      break;

    case 3:
      /* Directed + broadcast */
      if ( isMulticast
        && !RtlCompareMemory( pBuffer->buffer, (const void*)&kMacBroadcast, sizeof( EnetMacAddress))
      ) {
        /* No multicast */
        TRACE( 3, ("ClientRx() No multicast\n"));
        continue;
        }
      break;

    case 4:
    case 5:
      /* Directed + multicast */
      if ( !isMulticast
        && pPacket->macAddrIsValid
        && !RtlCompareMemory( pBuffer->buffer, (const void*)&pPacket->mac, sizeof( EnetMacAddress))
      ) {
        /* Not this MAC */
        TRACE( 3, ("ClientRx() Not promiscuous\n"));
        continue;
        }
      break;

    default:
      ASSERT( !"Invalid Rx mode");
      /* Fall thru */
    case 6:
      /* All */
      break;
      }
    }
#endif

    /* Type filtering */
    if ( pInst->unType)
      {
      unsigned const uType = 256U * pBuffer->buffer[ 12] + pBuffer->buffer[ 13];

      if ( pInst->unType != uType)
        {
        TRACE( 3, ("ClientRx() Type %#04x != client %#04x\n",
          uType, pInst->unType));
        continue;
        }
      }

    /* Callback client with AX=0 to get client buffer */
    setAX( 0);
    setBX( pInst->h);
    setCX( (USHORT)dwBytes);
    setDX( 0);
    setDS( 0), setSI( 0);
    setES( pInst->regES), setDI( pInst->regDI); /* Callback */
    setSP( regSP);
    setCS( regES), setIP( regDI);
    TRACE( 4, ("ClientRx() callback %04x:%04x AX=%u, CX=%u\n",
      getES(), getDI(), getAX(), getCX()));
    VDDSimulate16();
    ASSERT( 1 == getDX()); /* DOS16 callback sets DX=1 */

    /* Client buffer is returned in ES:DI */
    clientES = getES(), clientDI = getDI();
    if ( 0 != clientES || 0 != clientDI)
      {
      LPVOID p;

      TRACE( 3, ("ClientRx() Copy %lu bytes from buffer %p to client %04x:%04x\n",
        dwBytes,pBuffer,clientES,clientDI));

      /* Move data to client buffer */
      #if DDK_VERSION >= 50
      p = VdmMapFlat( clientES, clientDI, VDM_V86);
      #else
      p = GetVDMPointer( MAKEADDR( clientES, clientDI), dwBytes, 0);
      #endif

      RtlCopyMemory( p, pBuffer->buffer, dwBytes);

      #if DDK_VERSION >= 50
      VdmUnmapFlat( clientES, clientDI, p, VDM_V86);
      #else
      FreeVDMPointer( MAKEADDR( clientES, clientDI), dwBytes, p, 0);
      #endif

      /* Callback client with AX=1 to indicate data received */
      setAX( 1);
      setBX( pInst->h);
      setCX( (USHORT)dwBytes);
      setDS( clientES), setSI( clientDI);
      setES( pInst->regES), setDI( pInst->regDI); /* Callback */
      setSP( regSP);
      setCS( regES), setIP( regDI);
      VDDSimulate16();
      }
    else
      {
      TRACE( 3, ("ClientRx() No client buffer for %lu bytes\n",dwBytes));
      s_stats.packets_lost++;
      }
    }

  setDS( regDS), setSI( regSI);
  setES( regES), setDI( regDI);
  setBP( regBP), setSP( regSP);
  setCS( regCS), setIP( regIP);
  }


/*
 * Make a transmit completion callback
 * ES:DI -> callback
 */
void ClientTx( STxBuffer* pBuffer)
  {
  USHORT const regDS = getDS(), regSI = getSI();
  USHORT const regES = getES(), regDI = getDI();
  USHORT const regCS = getCS(), regIP = getIP();
  USHORT const regSP = getSP(), regBP = getBP();

  TRACE( 3, ("ClientTx(%p)\n",pBuffer));

  /* Release buffer mapping */
  #if DDK_VERSION >= 50
  VdmUnmapFlat( pBuffer->regDS, pBuffer->regSI, pBuffer->pvBuffer, VDM_V86);
  #else
  FreeVDMPointer( MAKEADDR( pBuffer->regDS, pBuffer->regSI), pBuffer->dwBytes, pBuffer->pvBuffer, 0);
  #endif

  /* Callback client */
  setAX( pBuffer->err); /* 0= success */
  setDS( pBuffer->regDS), setSI( pBuffer->regSI); /* Buffer */
  setES( pBuffer->regES), setDI( pBuffer->regDI); /* Callback */
  setSP( regSP);
  setCS( regES), setIP( regDI);
  VDDSimulate16();
  ASSERT( 1 == getDX()); /* DOS16 callback sets DX=1 */

  setDS( regDS), setSI( regSI);
  setES( regES), setDI( regDI);
  setBP( regBP), setSP( regSP);
  setCS( regCS), setIP( regIP);

  HeapFree( s_hHeap, 0, pBuffer);
  }


/*
 * DOS client wants interface name
 */
static int GetAdapterName( unsigned uNum, LPVOID pv, unsigned uLen)
  {
  SPacketDriver* pPacket;
  DWORD dwOutputByteCount;

  /* Check if interface is available */
  if ( uNum >= s_uAdapters)
    {
    TRACE( 1, ("*** GetAdapterName unsupported iface %u\n", uNum));
    return FALSE;
    }

  pPacket = s_apPacketDrivers[ uNum];
  ASSERT( PACKET_MAGIC == pPacket->uMagic);

  /* Get adapter description */
  if ( OverlappedDeviceIoControl(
    pPacket->hDevice,               /* Device handle */
    (DWORD)IOCTL_GETDESC,           /* IOCTL code */
    NULL, 0,                        /* -> input buffer & size */
    pv,                             /* -> output buffer */
    uLen,                           /* output buffer size */
    &dwOutputByteCount              /* Bytes returned */
  )){
    return TRUE;
    }

  TRACE( 1, ("*** GetAdapterName OverlappedDeviceIoControl failed\n"));
  return FALSE;
  }


/*
 * Start a service
 */
BOOL StartAService( const char* pszService)
  {
  SC_HANDLE schSCManager;
  SC_HANDLE schService;
  SERVICE_STATUS status;
  BOOL bRet = TRUE;

  TRACE( 9, ("StartAService(%s)\n", pszService));
  ASSERT( NULL != pszService);

  schSCManager = OpenSCManager( NULL, NULL, SC_MANAGER_CONNECT);
  if ( NULL == schSCManager)
    {
    TRACE( 1, ("*** StartAService() OpenSCManager error %#lx\n", GetLastError() ));
    return FALSE;
    }

  schService = OpenService(
    schSCManager, pszService, SERVICE_START | SERVICE_QUERY_STATUS);
  if ( NULL != schService)
    {
    if ( !StartService( schService, 0, NULL))
      {
      /* Find the reason the service wasn't started */
      DWORD dwError = GetLastError();
      /* It's ok if the service was already running */
      if ( ERROR_SERVICE_ALREADY_RUNNING != dwError)
        {
        TRACE( 1, ("*** StartAService() Can't start the '%s' service, error %#lx\n",
          pszService, dwError ));
        bRet = FALSE;
        }
      }
    else
      {
      /* Wait until started */
      DWORD dwMaxWait = 3000, dwInterval = 200;
      do
        {
        if ( !QueryServiceStatus( schService, &status))
          {
          TRACE( 2, ("StartAService() Can't query the '%s' service, error %#lx\n",
            pszService, GetLastError() ));
          bRet = FALSE;
          break;
          }

        if ( dwMaxWait < dwInterval)
          {
          bRet = FALSE;
          break;
          }
        dwMaxWait -= dwInterval;

        SleepEx( dwInterval, TRUE);
        }
      while ( SERVICE_RUNNING != status.dwCurrentState);
      }

    CloseServiceHandle( schService);
    }
  else if ( NULL != (schService = OpenService(
      schSCManager, pszService, SERVICE_QUERY_STATUS))
  ) {
    bRet = QueryServiceStatus( schService, &status);
    if ( bRet)
      {
      bRet = SERVICE_RUNNING == status.dwCurrentState;
      }
    else
      {
      TRACE( 2, ("StartAService() Can't query the '%s' service, error %#lx\n",
        pszService, GetLastError() ));
      }

    CloseServiceHandle( schService);
    }
  else
    {
    /* Probably ERROR_ACCESS_DENIED - user doesn't have administrative privilege */
    TRACE( 2, ("StartAService() Can't open the '%s' service, error %#lx\n",
      pszService, GetLastError() ));
    bRet = FALSE;
    }

  CloseServiceHandle( schSCManager);
  return bRet;
  }


/*
 * Create an interface for a packet driver
 */
BOOL AddPacketDriver( int if_num, int bWanEnable)
  {
  SPacketDriver* pPacket;
  char szName[ sizeof( "\\\\.\\" IOCTL_DEVICE) + 4];
  size_t size;
  IOCTL_INFO info;
  DWORD dwOutputByteCount;

  TRACE( 9, ("AddPacketDriver(%d)\n", if_num));

  /* Allocate instance data */
  size = sizeof(*pPacket) + s_bufferCount * sizeof(pPacket->rxBuffer[0]);
  pPacket = (SPacketDriver*) HeapAlloc( s_hHeap, HEAP_ZERO_MEMORY, size);
  if ( NULL == pPacket)
    {
    TRACE( 0, ("!!! AddPacketDriver() Out of memory, %u buffers, %u bytes\n",
      s_bufferCount, size));
    return FALSE;
    }

  pPacket->hDevice = INVALID_HANDLE_VALUE;
  DEQUE_INIT( &pPacket->clientQ);

  /* Create overlapped Tx done event */
  pPacket->txOverlap.hEvent = CreateEvent( NULL, TRUE, FALSE, NULL);
  if ( NULL == pPacket->txOverlap.hEvent)
    {
    TRACE( 0, ("!!! AddPacketDriver() CreateEvent failed(%#lx)\n",GetLastError() ));
    FreePacketDriver( pPacket);
    return FALSE;
    }

  /* Attach to packet driver */
  wsprintf( szName, "\\\\.\\" IOCTL_DEVICE "%d", if_num);
  pPacket->hDevice = CreateFile(
    szName,
    GENERIC_READ | GENERIC_WRITE,
    (1 * FILE_SHARE_READ) | (1 * FILE_SHARE_WRITE),
    NULL, /* Security */
    OPEN_EXISTING,
    (1 * FILE_FLAG_OVERLAPPED) | FILE_ATTRIBUTE_NORMAL,
    NULL /* Template file */
  );
  if ( INVALID_HANDLE_VALUE == pPacket->hDevice)
    {
    DWORD dwErr = GetLastError();
    switch ( dwErr)
      {
    case ERROR_FILE_NOT_FOUND:
      /* Device not present */
      break;

    case ERROR_ACCESS_DENIED:
      /* Device already in use */
      TRACE( 2, ("AddPacketDriver() Access denied to %s \n",szName));
      break;

    default:
      TRACE( 1, ("*** AddPacketDriver() CreateFile %s failed (%#lx)\n",
        szName,dwErr));
      break;
      }
    FreePacketDriver( pPacket);
    return FALSE;
    }
  TRACE( 2, ("AddPacketDriver(%s) => i/f %p\n",szName, pPacket));

  pPacket->uMagic = PACKET_MAGIC;

  /* Get adapter type */
  info.bWan = FALSE;
  if ( OverlappedDeviceIoControl(
      pPacket->hDevice,               /* Device handle */
      (DWORD)IOCTL_GETINFO,           /* IOCTL code */
      NULL, 0,                        /* -> input buffer & size */
      &info,                          /* -> output buffer */
      sizeof( info),                  /* output buffer size */
      &dwOutputByteCount              /* Bytes returned */
    )
  ) {
    /* Don't attach to WAN's */
    if ( info.bWan && !bWanEnable)
      {
      FreePacketDriver( pPacket);
      return FALSE;
      }
    }

  /* Start the worker thread */
  pPacket->hWorker = CreateThread(
    NULL, 0, &Worker, pPacket, CREATE_SUSPENDED, NULL);
  if ( NULL == pPacket->hWorker)
    {
    TRACE( 1, ("*** AddPacketDriver() CreateThread failed(%lx)\n",GetLastError() ));
    FreePacketDriver( pPacket);
    return FALSE;
    }

  SetThreadPriority( pPacket->hWorker, THREAD_PRIORITY_ABOVE_NORMAL);
  ResumeThread( pPacket->hWorker);

  /* Add to list of drivers */
  s_apPacketDrivers[ s_uAdapters++] = pPacket;

  return TRUE;
  }

  
/*
 * Release packet driver resources
 */
void FreePacketDriver( SPacketDriver* pPacket)
  {
  SDeque* pDeque, *pNext;

  TRACE( 9, ("FreePacketDriver(%p)\n", pPacket));
  ASSERT( NULL != pPacket);

  /* Signal the worker thread to exit */
  pPacket->iWorkerExit = 1;
  if ( NULL != pPacket->hWorker)
    {
    switch ( WaitForSingleObject( pPacket->hWorker, 300))
      {
    case WAIT_OBJECT_0:
      break;

    case WAIT_TIMEOUT:
      /* This will occur if the thread is waiting in a critical section */
      TRACE( 3, ("FreePacketDriver() WaitForSingleObject timed out\n"));

      /* Resolve the deadlock by killing the thread */
      if ( !TerminateThread( pPacket->hWorker, 1))
        {
        TRACE( 1, ("*** FreePacketDriver() TerminateThread failed %#lx\n",
          GetLastError() ));
        }
      break;

    case WAIT_FAILED:
    default:
      /* This normally mean that the thread has exited and the handle is invalid */
      TRACE( 3, ("FreePacketDriver() WaitForSingleObject failed %#lx\n",
        GetLastError() ));
      break;
      }

    CloseHandle( pPacket->hWorker);
    }

  if ( INVALID_HANDLE_VALUE != pPacket->hDevice)
    {
    CloseHandle( pPacket->hDevice);
    pPacket->hDevice = INVALID_HANDLE_VALUE;
    }

  if ( NULL != pPacket->txOverlap.hEvent )
    CloseHandle( pPacket->txOverlap.hEvent );

  /* Free client instances */
  pNext = NULL;
  for (
    pDeque = DEQUE_FIRST( &pPacket->clientQ);
    pDeque != &pPacket->clientQ;
    pDeque = pNext
  ) {
    pNext = DEQUE_FIRST( pDeque);
    HeapFree( s_hHeap, 0, LIST2INST( pDeque) );
    }

  HeapFree( s_hHeap, 0, pPacket);
  }


/*
 * Update receiver mode
 */
int SetRxMode( SPacketDriver* const pPacket)
  {
  int iRet = 0; /* Assume success */
  SDeque* pDeque, *pNext;
  unsigned u;
  static const EnetMacAddress allmcast = {0xff,0,0,0,0,0};

  TRACE( 9, ("SetRxMode(%p)\n",pPacket));
  ASSERT( NULL != pPacket);
  ASSERT( PACKET_MAGIC == pPacket->uMagic);

  /* Get the max receive mode of all clients */
  u = 0;
  pNext = NULL;
  for (
    pDeque = DEQUE_FIRST( &pPacket->clientQ);
    pDeque != &pPacket->clientQ;
    pDeque = pNext
  ) {
    SInstance* pInst = LIST2INST( pDeque);
    if ( pInst->uRxMode > u)
      u = pInst->uRxMode;

    pNext = DEQUE_FIRST( pDeque);
    }

  switch ( u)
    {
  case 0:
  case 1:
    TRACE( 2, ("SetRxMode(%p) disable\n",pPacket));
    if ( kRxModeDisable != pPacket->eRxMode)
      {
      pPacket->eRxMode = kRxModeDisable;
      SetPromiscuity( pPacket, 0);
      VERIFY( QueueUserAPC( &StopReceivingApc, pPacket->hWorker, (ULONG_PTR)pPacket));
      }
    break;

  case 2:
  case 3:
  case 4:
    TRACE( 2, ("SetRxMode(%p) enable %u\n",pPacket,u));
    switch ( pPacket->eRxMode)
      {
    case kRxModeDisable:
      pPacket->eRxMode = kRxModeEnable;
      VERIFY( QueueUserAPC( &StartReceivingApc, pPacket->hWorker, (ULONG_PTR)pPacket));
      break;

    case kRxModeEnable:
      break;

    case kRxModePromiscuous:
      pPacket->eRxMode = kRxModeEnable;
      SetPromiscuity( pPacket, 0);
      break;
      }
    break;

  case 5:
    TRACE( 2, ("SetRxMode(%p) all multicast\n",pPacket));
    switch ( pPacket->eRxMode)
      {
    case kRxModeDisable:
      pPacket->eRxMode = kRxModeEnable;
      VERIFY( QueueUserAPC(
        &StartReceivingApc, pPacket->hWorker, (ULONG_PTR)pPacket));
      /* Fall thru */
    case kRxModeEnable:
      iRet = SetMulticastList( pPacket, &allmcast, sizeof(allmcast));
      break;

    case kRxModePromiscuous:
      pPacket->eRxMode = kRxModeEnable;
      SetPromiscuity( pPacket, 0);
      iRet = SetMulticastList( pPacket, &allmcast, sizeof(allmcast));
      break;
      }
    break;

  case 6:
    TRACE( 2, ("SetRxMode(%p) promiscuous\n",pPacket));
    switch ( pPacket->eRxMode)
      {
    case kRxModeDisable:
      VERIFY( QueueUserAPC(
        &StartReceivingApc, pPacket->hWorker, (ULONG_PTR)pPacket));
      /* Fall thru */
    case kRxModeEnable:
      pPacket->eRxMode = kRxModePromiscuous;
      iRet = SetPromiscuity( pPacket, 1);
      break;

    case kRxModePromiscuous:
      break;
      }
    break;

  default:
    ASSERT( !"Invalid mode");;
    iRet = 1;
    }

  return iRet;
  }


/*
 * Worker thread
 */
DWORD WINAPI Worker( LPVOID pv)
  {
  SPacketDriver* const pPacket = (SPacketDriver*)pv;
  ASSERT( PACKET_MAGIC == pPacket->uMagic);

  TRACE( 2, ("Worker(%p) starting\n",pPacket));

  /* Execute IO completion callbacks and APC's until exit */
  while ( !pPacket->iWorkerExit)
    SleepEx( 100, TRUE);

  /* Cancel all pending reads */
  CancelIo( pPacket->hDevice);
  SleepEx( 10, TRUE);

  TRACE( 2, ("Worker(%p) exiting\n",pPacket));
  return 0;
  }


/*
 * APC to start receiving
 */
VOID WINAPI StartReceivingApc( ULONG_PTR ulContext)
  {
  SPacketDriver* const pPacket = (SPacketDriver*)ulContext;
  size_t u;

  TRACE( 3, ("StartReceivingApc(%p)\n",pPacket));
  ASSERT( NULL != pPacket);
  ASSERT( PACKET_MAGIC == pPacket->uMagic);
  ASSERT( !s_bSuspended);
  ASSERT( kRxModeDisable != pPacket->eRxMode);

  /* Submit all read buffers */
  for ( u = 0; u < s_bufferCount; ++u)
    QueueBuffer( pPacket, &pPacket->rxBuffer[ u]);
  }

  
/*
 * APC to stop receiving
 */
VOID WINAPI StopReceivingApc( ULONG_PTR ulContext)
  {
  SPacketDriver* const pPacket = (SPacketDriver*)ulContext;

  TRACE( 3, ("StopReceivingApc(%p)\n",pPacket));
  ASSERT( NULL != pPacket);
  ASSERT( PACKET_MAGIC == pPacket->uMagic);

  /* Cancel all pending reads */
  CancelIo( pPacket->hDevice);
  }


/*
 * Post a receive buffer
 */
BOOL QueueBuffer(
  SPacketDriver* pPacket,
  SRxBuffer* pBuffer
) {
  TRACE( 9, ("QueueBuffer(%p,%p)\n",pPacket,pBuffer));
  ASSERT( NULL != pPacket);
  ASSERT( PACKET_MAGIC == pPacket->uMagic);
  ASSERT( NULL != pBuffer);

  if ( s_bSuspended)
    {
    TRACE( 3, ("QueueBuffer suspened\n"));
    return FALSE;
    }
  if ( kRxModeDisable == pPacket->eRxMode)
    {
    TRACE( 3, ("QueueBuffer(%p) rx disabled\n",pPacket));
    return FALSE;
    }
  if ( pPacket->iWorkerExit)
    {
    TRACE( 3, ("QueueBuffer(%p) worker exiting\n",pPacket));
    return FALSE;
    }

  TRACE( 3, ("QueueBuffer(%p,%p)\n",pPacket,pBuffer));

  ZeroMemory( &pBuffer->overlap, sizeof(pBuffer->overlap) );
  pBuffer->overlap.hEvent = (HANDLE)pPacket;
  pBuffer->dwBytes = 0;

  if ( !ReadFileEx(
      pPacket->hDevice,
      pBuffer->buffer,
      sizeof( pBuffer->buffer),
      &pBuffer->overlap,
      &ReceiveComplete
    )
  ) {
    DWORD dwErr = GetLastError();
    switch ( dwErr)
      {
    case ERROR_OPERATION_ABORTED:
      TRACE( 3, ("QueueBuffer() i/f %p, buffer %p aborted\n",pPacket,pBuffer));
      break;

    default:
      TRACE( 1, ("*** QueueBuffer ReadFileEx error %#08lx\n",dwErr ));
      /* Retry later */
      VERIFY( QueueUserAPC(
        &ResubmitRxBufferApc, pPacket->hWorker, (ULONG_PTR)pBuffer));
      break;
      }
    return FALSE;
    }

  return TRUE;
  }


/*
 * APC to resubmit an RxBuffer
 */
VOID WINAPI ResubmitRxBufferApc( ULONG_PTR ulContext)
  {
  SRxBuffer* const pBuffer = (SRxBuffer*)ulContext;
  SPacketDriver* pPacket;

  TRACE( 9, ("ResubmitRxBufferApc(%p)\n",pBuffer));
  ASSERT( NULL != pBuffer);

  pPacket = (SPacketDriver*)pBuffer->overlap.hEvent;
  ASSERT( NULL != pPacket);
  ASSERT( PACKET_MAGIC == pPacket->uMagic);
  TRACE( 4, ("ResubmitRxBufferApc() i/f %p buffer %p\n",pPacket,pBuffer));

  /* Resubmit the bufferg */
  QueueBuffer( pPacket, pBuffer);
  }


/*
 * ReadFileEx completion routine
 */
VOID WINAPI ReceiveComplete(
  DWORD dwErr,                        /* completion code */
  DWORD dwBytes,                      /* number of bytes transferred */
  LPOVERLAPPED lpOverlapped           /* I/O information buffer */
) {
  SRxBuffer* const pBuffer = OVL2RXBUF( lpOverlapped);
  SPacketDriver* pPacket;

  TRACE( 9, ("ReceiveComplete(%#lx,%lu,%p)\n",dwErr,dwBytes,lpOverlapped));
  ASSERT( NULL != lpOverlapped);

  pPacket = (SPacketDriver*)pBuffer->overlap.hEvent;
  ASSERT( NULL != pPacket);
  ASSERT( PACKET_MAGIC == pPacket->uMagic);

  pBuffer->dwBytes = dwBytes;
  switch ( dwErr)
    {
  case 0:
    TRACE( 3, ("ReceiveComplete() i/f %p, buffer %p, %lu bytes\n",
      pPacket,pBuffer,dwBytes));

    if ( DEQUE_IS_EMPTY( &pPacket->clientQ))
      break;

    s_stats.packets_in++;
    s_stats.bytes_in += dwBytes;

    /* Queue buffer for processing by VDM thread */
    /* NB QueueUserAPC to VDM thread can cause it to abort */
    DEQUE_INIT( &pBuffer->list);
    EnterCriticalSection( &s_csIackQ);
    DequeAppend( &s_qIack, &pBuffer->list);
    LeaveCriticalSection( &s_csIackQ);

    /* Interrupt VDM */
    if ( 0 == InterlockedExchange( &s_lIrqPending, 1))
      {
      VDDSimulateInterrupt(
        s_ucIrq <= 7 ? ICA_MASTER : ICA_SLAVE, (BYTE)(s_ucIrq & 7), 1);
      TRACE( 4, ("ReceiveComplete() Delivered IRQ\n"));
      }
    else
      {
      TRACE( 3, ("ReceiveComplete() Interrupt pending\n"));
      }
    return;

  case ERROR_OPERATION_ABORTED:
    TRACE( 3, ("ReceiveComplete() i/f %p, buffer %p aborted\n",pPacket,pBuffer));
    break;

  default:
    TRACE( 2, ("ReceiveComplete() i/f %p, buffer %p error %#lx)\n",
      pPacket,pBuffer,dwErr));
    s_stats.errors_in++;
    break;
    }

  /* Resubmit the buffer */
  QueueBuffer( pPacket, pBuffer);
  }


/*
 * APC to transmit a buffer
 */
VOID WINAPI SendBufferApc( ULONG_PTR ulContext)
  {
  STxBuffer* const pBuffer = (STxBuffer*)ulContext;
  SPacketDriver* pPacket;

  TRACE( 3, ("SendBufferApc(%p)\n",pBuffer));
  ASSERT( NULL != pBuffer);

  pPacket = pBuffer->pPacket;
  ASSERT( NULL != pPacket);
  ASSERT( PACKET_MAGIC == pPacket->uMagic);

  ZeroMemory( &pBuffer->overlap, sizeof(pBuffer->overlap) );

  if ( !WriteFileEx(
      pPacket->hDevice,
      pBuffer->pvBuffer, pBuffer->dwBytes,
      &pBuffer->overlap,
      &SendComplete
    )
  ) {
    SendComplete( GetLastError(), 0, &pBuffer->overlap);
    }
  }


/*
 * WriteFileEx completion routine
 */
VOID WINAPI SendComplete(
  DWORD dwErr,                        /* completion code */
  DWORD dwBytes,                      /* number of bytes transferred */
  LPOVERLAPPED lpOverlapped           /* I/O information buffer */
) {
  STxBuffer* const pBuffer = OVL2TXBUF( lpOverlapped);

  TRACE( 9, ("SendComplete(%#lx,%lu,%p)\n",dwErr,dwBytes,lpOverlapped));
  ASSERT( NULL != lpOverlapped);

  switch ( dwErr)
    {
  case 0:
    TRACE( 3, ("SendComplete(%p)\n",pBuffer));
    s_stats.packets_out++;
    s_stats.bytes_out += dwBytes;
    break;

  case ERROR_OPERATION_ABORTED:
    TRACE( 3, ("SendComplete() aborted\n"));
    pBuffer->err = 1;
    break;

  default:
    TRACE( 2, ("SendComplete() error %#lx)\n",dwErr));
    s_stats.errors_out++;
    pBuffer->err = 1;
    break;
    }

  /* Queue buffer for processing by VDM thread */
  /* NB QueueUserAPC to VDM thread can cause it to abort */
  DEQUE_INIT( &pBuffer->list);
  EnterCriticalSection( &s_csIackQ);
  DequeAppend( &s_qIack, &pBuffer->list);
  LeaveCriticalSection( &s_csIackQ);

  /* Interrupt VDM */
  if ( 0 == InterlockedExchange( &s_lIrqPending, 1))
    {
    VDDSimulateInterrupt(
      s_ucIrq <= 7 ? ICA_MASTER : ICA_SLAVE, (BYTE)(s_ucIrq & 7), 1);
    TRACE( 4, ("SendComplete() Delivered IRQ\n"));
    }
  else
    {
    TRACE( 3, ("SendComplete() Interrupt pending\n"));
    }
  }
 

/*
 * Make a synchronous DeviceIoControl call to a handle opened using FILE_FLAG_OVERLAPPED
 */
BOOL OverlappedDeviceIoControl(
  HANDLE hDevice,
  DWORD dwIoControlCode,
  LPCVOID lpInBuffer,
  DWORD nInBufferSize,
  LPVOID lpOutBuffer,
  DWORD nOutBufferSize,
  LPDWORD lpBytesReturned
) {
  BOOL bResult;
  HANDLE hEvent;
  OVERLAPPED overlap;

  TRACE( 9, ("OverlappedDeviceIoControl(%p)\n",hDevice));

  /* Create a manual reset event for overlapped wait */
  hEvent = CreateEvent( NULL, TRUE, FALSE, NULL);
  if ( NULL == hEvent)
    return FALSE;

  ZeroMemory( &overlap, sizeof( overlap) );
  overlap.hEvent = hEvent;

  bResult = DeviceIoControl(
    hDevice,
    dwIoControlCode,
    (LPVOID)lpInBuffer,
    nInBufferSize,
    lpOutBuffer,
    nOutBufferSize,
    lpBytesReturned,
    &overlap
  );
  if ( !bResult
    && ERROR_IO_PENDING == GetLastError()
  ) {
    /* Wait for completion */
    bResult = GetOverlappedResult( hDevice, &overlap, lpBytesReturned, TRUE);
    }

  CloseHandle( hEvent);

  return bResult;
  }


/*
 * Get the adapter's MAC address
 */
int PacketGetMacAddr(                 /* Return !0 on error */
  SPacketDriver* const pPacket,
  EnetMacAddress* pMac                /* OUT: Mac address */
) {
  TRACE( 9, ("PacketGetMacAddr(%p,%p)\n",pPacket,pMac));
  ASSERT( NULL != pPacket);
  ASSERT( PACKET_MAGIC == pPacket->uMagic);
  ASSERT( NULL != pMac);

  if ( !pPacket->macAddrIsValid)
    {
    BOOL bResult;
    DWORD dwOutputByteCount;

    /* Get the device type etc */
    bResult = OverlappedDeviceIoControl(
      pPacket->hDevice,               /* Device handle */
      (DWORD)IOCTL_GETMACADDR,        /* IOCTL code */
      NULL, 0,                        /* -> input buffer & size */
      &pPacket->mac.addr,             /* -> output buffer */
      sizeof( pPacket->mac.addr),     /* output buffer size */
      &dwOutputByteCount              /* Bytes returned */
    );
    if ( !bResult)
      {
      TRACE( 1, ("*** PacketGetMacAddr DeviceIoControl error %#lx\n",
        GetLastError() ));
      return 1;
      }

    /* Cache the address for later */
    pPacket->macAddrIsValid = 1;
    }

  *pMac = pPacket->mac;

  return 0;
  }


/* 
 * Set receive promiscuity
 */
int SetPromiscuity(
  SPacketDriver* const pPacket,
  unsigned mode
) {
  BOOL bResult;
  DWORD dwOutputByteCount;
  BYTE bMode;

  TRACE( 9, ("SetPromiscuity(%p,%u)\n",pPacket,mode));
  ASSERT( NULL != pPacket);
  ASSERT( PACKET_MAGIC == pPacket->uMagic);

  bMode = (BYTE)mode;
  bResult = OverlappedDeviceIoControl(
    pPacket->hDevice,               /* Device handle */
    (DWORD)IOCTL_SETPROMISCUITY,    /* IOCTL code */
    &bMode,                         /* -> input buffer */
    sizeof( bMode),                 /* input buffer size */
    NULL, 0,                        /* -> output buffer & size */
    &dwOutputByteCount              /* Bytes returned */
  );
  if ( !bResult)
    {
    TRACE( 1, ("*** SetPromiscuity DeviceIoControl error %#lx\n",GetLastError() ));
    return 1;
    }

  return 0;
  }


/* 
 * Set multicast list
 */
int SetMulticastList(
  SPacketDriver* const pPacket,
  const void* pv,
  size_t size
) {
  BOOL bResult;
  DWORD dwOutputByteCount;

  TRACE( 9, ("SetMulticastList(%p,%p,%u)\n",pPacket,pv,size));
  ASSERT( NULL != pPacket);
  ASSERT( PACKET_MAGIC == pPacket->uMagic);

  bResult = OverlappedDeviceIoControl(
    pPacket->hDevice,               /* Device handle */
    (DWORD)IOCTL_SETMULTICASTLIST,  /* IOCTL code */
    pv,                             /* -> input buffer */
    size,                           /* input buffer size */
    NULL, 0,                        /* -> output buffer & size */
    &dwOutputByteCount              /* Bytes returned */
  );
  if ( !bResult)
    {
    TRACE( 1, ("*** SetMulticastList DeviceIoControl error %#lx\n",GetLastError() ));
    return 1;
    }

  return 0;
  }


/*
 * Handle management
 */
static void* s_apHandles[ OPT_HANDLES];

HCLIENT AllocHandle( void* pv)
  {
  unsigned u;

  TRACE( 9, ("AllocHandle(%p)\n", pv));
  ASSERT( NULL != pv);

  for ( u = 1; u < OPT_HANDLES; ++u)
    {
    if ( NULL == s_apHandles[u])
      {
      s_apHandles[u] = pv;
      return (USHORT)u;
      }
    }

  TRACE( 1, ("*** AllocHandle(%p) All handles in use\n", pv));
  return 0;
  }


void* FreeHandle( HCLIENT h)
  {
  void* pv;

  TRACE( 9, ("FreeHandle(%u)\n", h));

  if ( h < 1 || h >= OPT_HANDLES)
    {
    TRACE( 1, ("*** FreeHandle(%u) Invalid handle\n", h));
    return NULL;
    }

  pv = s_apHandles[ h];
  s_apHandles[ h] = NULL;

  return pv;
  }


void* GetHandle( HCLIENT h)
  {
  TRACE( 9, ("GetHandle(%u)\n", h));

  if ( h < 1 || h >= OPT_HANDLES)
    {
    TRACE( 1, ("*** GetHandle(%u) Invalid handle\n", h));
    return NULL;
    }

  return s_apHandles[ h];
  }


/*
 * Add an item to the tail of a deque
 */
void DequeAppend( SDeque* const pDeque, SDeque* const pItem)
  {
  pItem->tail = pDeque;
  pItem->head = pDeque->head;

  pDeque->head->tail = pItem;
  pDeque->head = pItem;
  }

  
/*
 * Remove an item from a deque
 */
SDeque* DequeRemove( SDeque* const pItem)
  {
  pItem->head->tail = pItem->tail;
  pItem->tail->head = pItem->head;

  DEQUE_INIT( pItem);

  return pItem;
  }

/* End of file */
