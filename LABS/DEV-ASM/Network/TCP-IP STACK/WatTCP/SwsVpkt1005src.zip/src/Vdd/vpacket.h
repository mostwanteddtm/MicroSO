/****************************************************************************
 * File Name  : vpacket.h                                                   *
 * Function   : Virtual packet driver                                       *.
 * Project    : SwsVpkt                                                     *
 * Systems    : ANSI C, Win32                                               *
 *                                                                          *
 * Created by Lawrence Rust, Software Systems Consultants               .   *
 * lvr@softsystem.co.uk. Tel/Fax +33 5 49 72 79 63                          *
 *__________________________________________________________________________*
 *                                                                          *
 * Revision History:                                                        *
 *                                                                          *
 * No.   Date     By   Reason                                               *
 *--------------------------------------------------------------------------*
 * 100  29 May 05  lvr  Creation                                            *
 *__________________________________________________________________________*/

#ifndef VPACKET_H
#define VPACKET_H 0x100

/* Dependencies */
#pragma warning ( disable : 4201) /* nonstandard extension used : nameless struct/union */
#include <windows.h>
#pragma warning ( default : 4201)


/* Data types */

/* Functions */
#ifdef __cplusplus
extern "C" {
#endif

/* Process attaching/detaching */
extern int PktAttach( HANDLE);
extern void PktDetach( HANDLE);

/* DOS client called RegisterModule */
extern int PktRegister( USHORT ax, USHORT dx);

/* DOS client called DispatchCall */
extern int PktDispatch( void);

#ifdef __cplusplus
}
#endif
#endif /* ndef VPACKET_H */
/* End of file */
