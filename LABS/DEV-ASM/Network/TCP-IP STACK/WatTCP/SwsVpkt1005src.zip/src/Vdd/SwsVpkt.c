/****************************************************************************
 *
 * File name   : SwsVpkt.c
 * Function    : SwsVpkt VDD packet driver
 * Project     : SwsVpkt
 * Authors     : Lawrence Rust
 * Systems     : ANSI C Win32, NTVDM
 *
 ****************************************************************************
 *
 * Created by Lawrence Rust, Software Systems Consultants
 * lvr@softsystem.co.uk. Tel/Fax +33 5 49 72 79 63
 *
 * 27-May-05, LVR, Created.
 *
 * Comments:
 * --------
 * This file provides the external entry points required of an NT VDD.
 * On entry it registers with the NTVDM to provide a virtual DOS packet driver.
 *
 ****************************************************************************
 */

/* Compilation options */
#ifndef OPT_CATCH_EXCEPTIONS
 #define OPT_CATCH_EXCEPTIONS 1
#endif

#define kszProduct "SWSVPKT"


/* Exports */
#include "SwsVdd.h"

/* Imports */
#include <stdlib.h>

/* Win32 SDK */
#pragma warning ( disable : 4201) /* nonstandard extension used : nameless struct/union */
#pragma warning ( disable : 4214) /* nonstandard extension used : bit field types other than int */
#include <windows.h>
#include <mmsystem.h>                   /* timeBegin/EndPeriod */
#pragma warning ( default : 4201)
#pragma warning ( default : 4214)
#pragma warning ( disable : 4702) /* unreachable code */
#pragma warning ( disable : 4711) /* function selected for automatic inline expansion */

/* NT DDK */
#ifdef __cplusplus
extern "C" {
#endif
#include <vddsvc.h>                     /* VDD services */
#ifdef __cplusplus
}
#endif

/* Application */
#include "vpacket.h"

#define DEBUG_EXPORT(_f) _f
#define DEBUG_EXTERN(_f) extern _f
#include "debug.h"


/***************************************************************************
 * Macro definitions
 ***************************************************************************/


/***************************************************************************
 * Data types
 ***************************************************************************/



/***************************************************************************
 * Function prototypes
 ***************************************************************************/


/***************************************************************************
 * Module data
 ***************************************************************************/
HANDLE g_hVDD;                          /* VDD module handle */

/* Debugging */
#ifdef DEBUG_TRACE_LEVEL
  static void DebugTrace( const char*);
#else
  #define DebugTrace 0
#endif
DEBUG_TRACE( 1, &DebugTrace)

#ifdef ALERT_FN
  static ALERT_FMessageBox DebugAlert;
#endif
ALERT_DEFINE_HANDLER( DebugAlert)


/***************************************************************************
 * This is defined in SOURCES as the DLLENTRY
 ***************************************************************************/
EXTERNC BOOL WINAPI VDDInitialize( /* Return FALSE if dwReason == DLL_PROCESS_ATTACH & failed */
  IN HANDLE hVdd,                 /* Handle to VDD */
  IN DWORD dwReason,              /* flag word that indicates why called */
  LPVOID lpReserved               /* Unused */
) {
  (void)lpReserved;

#if OPT_CATCH_EXCEPTIONS
  { unsigned long ulExcept = 0; __try {
#endif

  switch ( dwReason)
    {
  case DLL_PROCESS_ATTACH:
    g_hVDD = hVdd;
#if DBG
    {
    DWORD dwValue;
    /* Increase timeGetTime() resolution for DebugTrace */
    timeBeginPeriod( 1);
    /* Set trace level from configuration */
    if ( VddReadRegValue( "Trace", REG_DWORD, sizeof( dwValue), &dwValue))
      DEBUG_SET_TRACE_LEVEL( dwValue);
    }
#endif
    TRACE( 2, ("VDDInitialize() Attaching process %p, trace level %u\n",
      hVdd, DEBUG_TRACE_LEVEL));

    /* Initialise */
    if ( !PktAttach( hVdd))
      {
      TRACE( 1, ("*** VDDInitialize() PktAttach() failed\n"));
#if DBG
      timeEndPeriod( 1);
#endif
      return FALSE;
      }
    break;

  case DLL_PROCESS_DETACH:
    TRACE( 2, ("VDDInitialize() Detaching process 0x%08lx\n", hVdd));
    ASSERT( g_hVDD == hVdd);

    /* Finalise */
    PktDetach( hVdd);
    g_hVDD = NULL;

    TRACE( 2, ("VDDInitialize() Detach complete\n"));
#if DBG
    timeEndPeriod( 1);
#endif
    break;

  case DLL_THREAD_ATTACH:
    TRACE( 3, ("VDDInitialize() Attaching thread 0x%p\n", lpReserved));
    break;

  case DLL_THREAD_DETACH:
    TRACE( 3, ("VDDInitialize() Detaching thread 0x%p\n", lpReserved));
    break;

  default:
    TRACE( 3, ("VDDInitialize(0x%p,%u,0x%p)\n", hVdd, dwReason, lpReserved));
    break;
    }

#if OPT_CATCH_EXCEPTIONS
  } __except( ulExcept = GetExceptionCode(), EXCEPTION_EXECUTE_HANDLER) {
    TRACE( -1, (">>> VDDInitialize() exception 0x%lx, reason %lu\n",
      ulExcept, dwReason));
  } }
#endif

  return TRUE;
  }

/*
 * Initialisation routine optionally called from 16-bit code's RegisterModule
 * On entry:
 * Client (DX)
 * Client (AX)
 */
EXPORT VOID VDDRegister( VOID)
  {
#if OPT_CATCH_EXCEPTIONS
  { unsigned long ulExcept = 0; __try {
#endif

  TRACE( 2, ("VDDRegister()\n"));

  setCF( PktRegister( getAX(), getDX()) ? 0 : 1);

#if OPT_CATCH_EXCEPTIONS
  } __except( ulExcept = GetExceptionCode(), EXCEPTION_EXECUTE_HANDLER) {
    TRACE( -1, (">>> VDDRegister() exception 0x%lx\n", ulExcept));
  } }
#endif
  }


/*
 * Dispatch routine called from 16-bit DispatchCall
 *
 * On entry:
 * Client (ES:BX) -> SPktRegs
 *
 * Return Value:
 *   SUCCESS - Client Carry Clear
 *   FAILURE - Client Carry Set
 */
EXPORT VOID VDDDispatch( VOID)
  {
#if OPT_CATCH_EXCEPTIONS
  { unsigned long ulExcept = 0; __try {
#endif
  TRACE( 9, ("VDDDispatch()\n"));

  setCF( PktDispatch() ? 0 : 1);

#if OPT_CATCH_EXCEPTIONS
  } __except( ulExcept = GetExceptionCode(), EXCEPTION_EXECUTE_HANDLER) {
    TRACE( -1, (">>> VDDDispatch() exception 0x%lx\n", ulExcept));
  } }
#endif
  }


/*
 * Read registry value
 */
EXTERNC BOOL VddReadRegValue(
  const char* pszValue,                 // IN: value name
  DWORD dwTypeRequired,                 // IN: value type
  size_t size,                          // IN: data buffer size
  void* pvData                          // OUT: data
) {
  HKEY hKey;
  LONG lResult;
  DWORD dwType, dwSize;

  TRACE( 9, ("VddReadRegValue(%lu,%u,0x%p)\n", dwTypeRequired, size, pvData));
  ASSERT( NULL != pszValue && NULL != pvData);

  /* Open the configuration key */
  lResult = RegOpenKeyEx( HKEY_CURRENT_USER, "Software\\Software Systems\\" kszProduct, 0, KEY_READ, &hKey);
  if ( ERROR_SUCCESS != lResult)
    {
    lResult = RegOpenKeyEx( HKEY_LOCAL_MACHINE, "Software\\Software Systems\\" kszProduct, 0, KEY_READ, &hKey);
    if ( ERROR_SUCCESS != lResult)
      {
      TRACE( 1, ("*** VddReadRegValue() RegOpenKeyEx returned %lu\n", lResult));
      return FALSE;
      }
    }

  /* Read the value */
  dwSize = size;
  lResult = RegQueryValueEx(
    hKey,
    pszValue,
    NULL,
    &dwType,
    (BYTE*)pvData,
    &dwSize
  );

  // Close the key
  VERIFY( !RegCloseKey( hKey));

  // Check for errors and type match
  if ( ERROR_SUCCESS != lResult)
    {
    if ( ERROR_FILE_NOT_FOUND != lResult)
      TRACE( 3, ("VddReadRegValue() RegQueryValueEx() returned %lu\n", lResult));
    return FALSE;
    }

  if ( dwTypeRequired != dwType)
    {
    TRACE( 1, ("*** VddReadRegValue() type %lu != %lu\n",
      dwType, dwTypeRequired));
    return FALSE;
    }

  return TRUE;
  }

  
/***************************************************************************
 * Debug functions
 ***************************************************************************/

#ifdef DEBUG_TRACE_LEVEL
/*
 * Debug trace handler
 */
void DebugTrace( const char* psz)
  {
  static HANDLE s_hTraceFile = INVALID_HANDLE_VALUE;
  char szBuf[256];
  DWORD dwLen;

  if ( NULL == psz)
    {
    if ( INVALID_HANDLE_VALUE != s_hTraceFile)
      {
      CloseHandle( s_hTraceFile);
      s_hTraceFile = INVALID_HANDLE_VALUE;
      }
    return;
    }

  /* Add the threadID and a timestamp to trace output */
  dwLen = wsprintf( szBuf, "%lu:%lu %.240s",
    GetCurrentThreadId(), timeGetTime(), psz);

  /* Send to debugger or log */
  if ( IsDebuggerPresent())
    {
    OutputDebugString( szBuf);
    }
  else
    {
    if ( INVALID_HANDLE_VALUE == s_hTraceFile)
      {
      s_hTraceFile = CreateFile(
        kszProduct ".LOG",
        GENERIC_WRITE,
        FILE_SHARE_READ,
        NULL,
        OPEN_ALWAYS,
        (0*FILE_FLAG_WRITE_THROUGH),
        NULL
      );
      if ( INVALID_HANDLE_VALUE != s_hTraceFile)
        SetFilePointer( s_hTraceFile, 0, NULL, FILE_END);
      }

    if ( INVALID_HANDLE_VALUE != s_hTraceFile)
      {
      if ( szBuf[ dwLen - 1] == '\n')
        {
        szBuf[ dwLen - 1] = '\r';
        szBuf[ dwLen] = '\n';
        ++dwLen;
        }
      WriteFile( s_hTraceFile, szBuf, dwLen, &dwLen, NULL);
      }
    }
  }
#endif


#ifdef ALERT_FN
/*
 * Assertion failure handler
 */
static short DebugAlert( const char* psz)
  {
  const static char kszText[] =
    "This program has encountered a fatal internal error and must exit immediately.\n"
    "\n"
    "Please send the " kszProduct ".LOG file (found in the current directory),\n"
    "a brief description of the events leading up to this failure to:\n"
    "\n"
    "netcenturion@softsystem.co.uk\n"
    "\n"
    "and we will endeavour to rectify the problem.  Sorry :-(";

  _TRACE( ">>> %s\n", psz);

#ifdef DEBUG_TRACE_LEVEL
  /* Close log file */
  DebugTrace( NULL);
#endif

  if ( IsDebuggerPresent())
    return ALERT_RETRY; /* Asserts break to the debugger without a messagebox */

  (void)WOWSysErrorBox( kszProduct, kszText, kBtnOk, 0, 0);
  return ALERT_ABORT;
  }
#endif

/* End of file */
