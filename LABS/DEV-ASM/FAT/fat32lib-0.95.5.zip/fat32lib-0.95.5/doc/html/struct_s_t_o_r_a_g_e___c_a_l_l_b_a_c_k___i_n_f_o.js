var struct_s_t_o_r_a_g_e___c_a_l_l_b_a_c_k___i_n_f_o =
[
    [ "Callback", "struct_s_t_o_r_a_g_e___c_a_l_l_b_a_c_k___i_n_f_o.html#a97fddaa8cdca96ac63afdd56f05d0787", null ],
    [ "Context", "struct_s_t_o_r_a_g_e___c_a_l_l_b_a_c_k___i_n_f_o.html#ad9e8f0bfab04a84bf3f5c7bcb1612122", null ]
];