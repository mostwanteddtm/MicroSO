var struct_s_d___c_a_l_l_b_a_c_k___i_n_f_o___e_x =
[
    [ "callback", "struct_s_d___c_a_l_l_b_a_c_k___i_n_f_o___e_x.html#abed4b64239df1fdfaaf28a1345fa7ced", null ],
    [ "context", "struct_s_d___c_a_l_l_b_a_c_k___i_n_f_o___e_x.html#a5e2bc4648c616f2f5e18efc956042be0", null ]
];