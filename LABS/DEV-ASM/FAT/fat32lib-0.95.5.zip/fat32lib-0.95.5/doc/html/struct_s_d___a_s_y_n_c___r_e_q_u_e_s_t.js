var struct_s_d___a_s_y_n_c___r_e_q_u_e_s_t =
[
    [ "address", "struct_s_d___a_s_y_n_c___r_e_q_u_e_s_t.html#a36ebc0a68531c3c15d306bcecc846e0b", null ],
    [ "async_state", "struct_s_d___a_s_y_n_c___r_e_q_u_e_s_t.html#a9dca43a7e154b872303bed59b8decf34", null ],
    [ "buffer", "struct_s_d___a_s_y_n_c___r_e_q_u_e_s_t.html#a92de8c6cb8b62eeeb5e13d3b8392115d", null ],
    [ "callback_info", "struct_s_d___a_s_y_n_c___r_e_q_u_e_s_t.html#a58c2ec4e3da14e5a20a7b8076760e4a0", null ],
    [ "callback_info_ex", "struct_s_d___a_s_y_n_c___r_e_q_u_e_s_t.html#a85a2b62f228b3dcb5598a42e8067bb44", null ],
    [ "mode", "struct_s_d___a_s_y_n_c___r_e_q_u_e_s_t.html#a2d0ef0c94b9a16959175ca4e96588160", null ],
    [ "needs_data", "struct_s_d___a_s_y_n_c___r_e_q_u_e_s_t.html#accdb6700bc795ff6f22990617b7826d7", null ],
    [ "next", "struct_s_d___a_s_y_n_c___r_e_q_u_e_s_t.html#aa22e58ed37fd985d90fe15b868bde6bb", null ]
];