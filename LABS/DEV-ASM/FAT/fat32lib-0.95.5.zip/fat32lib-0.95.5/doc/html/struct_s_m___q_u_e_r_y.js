var struct_s_m___q_u_e_r_y =
[
    [ "query_handle", "struct_s_m___q_u_e_r_y.html#a4a97224d0900c21cbefa83cc2682a5da", null ],
    [ "volume", "struct_s_m___q_u_e_r_y.html#a7619a521b64dddc7732b29e251f38684", null ]
];