var searchData=
[
  ['raw',['raw',['../struct_f_a_t___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#a608a35428c3c650dc24b3c1136d8df93',1,'FAT_DIRECTORY_ENTRY']]],
  ['read_5fsector',['read_sector',['../struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#aa21cf36104d62af5cd7521c66230e09d',1,'STORAGE_DEVICE']]],
  ['read_5fsector_5fasync',['read_sector_async',['../struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#a19211baa9e90d5d96ffbb88494e1783f',1,'STORAGE_DEVICE']]],
  ['register_5fmedia_5fchanged_5fcallback',['register_media_changed_callback',['../struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#a4811e9869fe2b92c669ec55a8a805a25',1,'STORAGE_DEVICE']]]
];
