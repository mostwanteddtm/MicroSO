var searchData=
[
  ['name',['name',['../struct_f_a_t___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#ac2842750bc760b5291e4009eeed57ed7',1,'FAT_DIRECTORY_ENTRY::name()'],['../struct_s_m___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#a201f16ecc991fd5d79b6d3efb65ea829',1,'SM_DIRECTORY_ENTRY::name()']]]
];
