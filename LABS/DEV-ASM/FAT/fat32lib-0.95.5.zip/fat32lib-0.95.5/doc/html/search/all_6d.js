var searchData=
[
  ['modify_5ftime',['modify_time',['../struct_f_a_t___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#a3498295ba295779e74ff1d20f724aac1',1,'FAT_DIRECTORY_ENTRY::modify_time()'],['../struct_s_m___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#a283ee97a6a4ef7983e95215ba9567399',1,'SM_DIRECTORY_ENTRY::modify_time()']]]
];
