var searchData=
[
  ['get_5fdevice_5fid',['get_device_id',['../struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#a967ef76a2314a56c00ae7e8c548b5089',1,'STORAGE_DEVICE']]],
  ['get_5fpage_5fsize',['get_page_size',['../struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#abc7d53ac89abb8ee92f01485f7a501fc',1,'STORAGE_DEVICE']]],
  ['get_5fsector_5fsize',['get_sector_size',['../struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#a6d3284e14c422473bab42aad314c916c',1,'STORAGE_DEVICE']]],
  ['get_5ftotal_5fsectors',['get_total_sectors',['../struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#a4c7eb29df27cb1e7c012d2ffcc318959',1,'STORAGE_DEVICE']]]
];
