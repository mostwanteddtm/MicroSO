var searchData=
[
  ['write_5fmultiple_5fsectors',['write_multiple_sectors',['../struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#af6404abe27af2258ec1a47892752f8c4',1,'STORAGE_DEVICE']]],
  ['write_5fsector',['write_sector',['../struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#ac5047feeff21f823fd578bf0f4ab81e5',1,'STORAGE_DEVICE']]],
  ['write_5fsector_5fasync',['write_sector_async',['../struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#a8e85c3b8bc9d3cd76546f93f9f4ccf57',1,'STORAGE_DEVICE']]]
];
