var searchData=
[
  ['erase_5fsectors',['erase_sectors',['../struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#afcf9038bac9b987005badd3c0ae50843',1,'STORAGE_DEVICE']]]
];
