var searchData=
[
  ['sector_5faddr',['sector_addr',['../struct_f_a_t___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#a221135da1ee1a12c4a1112ffd636550a',1,'FAT_DIRECTORY_ENTRY']]],
  ['sector_5foffset',['sector_offset',['../struct_f_a_t___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#ad756694bfe026279262fb77eb5148cd0',1,'FAT_DIRECTORY_ENTRY']]],
  ['size',['size',['../struct_f_a_t___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#afad000dca462c9f075683b297b956b50',1,'FAT_DIRECTORY_ENTRY::size()'],['../struct_s_m___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#ad0e3aad512c47a3d6fe159070cabc86a',1,'SM_DIRECTORY_ENTRY::size()']]]
];
