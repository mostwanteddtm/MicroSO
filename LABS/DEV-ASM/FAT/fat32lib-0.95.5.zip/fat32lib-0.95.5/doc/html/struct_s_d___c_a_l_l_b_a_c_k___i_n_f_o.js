var struct_s_d___c_a_l_l_b_a_c_k___i_n_f_o =
[
    [ "callback", "struct_s_d___c_a_l_l_b_a_c_k___i_n_f_o.html#a9ab846e67d50ffbefd7eb2c0b9082eb8", null ],
    [ "context", "struct_s_d___c_a_l_l_b_a_c_k___i_n_f_o.html#a3fbcef0e779ed9b03159c281b100d8a5", null ]
];