var struct_s_d___d_r_i_v_e_r =
[
    [ "card_info", "struct_s_d___d_r_i_v_e_r.html#a5cf2072253a745568439e856e36e6db8", null ],
    [ "context", "struct_s_d___d_r_i_v_e_r.html#a38705524956fe0a590a7f2ff8deb4bb8", null ]
];