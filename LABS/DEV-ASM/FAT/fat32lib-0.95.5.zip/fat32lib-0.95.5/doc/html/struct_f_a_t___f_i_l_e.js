var struct_f_a_t___f_i_l_e =
[
    [ "access_flags", "struct_f_a_t___f_i_l_e.html#a082dc4213953dc5456eca9abecb4d8da", null ],
    [ "buffer", "struct_f_a_t___f_i_l_e.html#a8eb89897f60885c592002dbf6f92219f", null ],
    [ "buffer_dirty", "struct_f_a_t___f_i_l_e.html#a02ba3079fec7de4f9e9f84da02b4b253", null ],
    [ "buffer_head", "struct_f_a_t___f_i_l_e.html#af1b6645c5b37eafdae018f317d044712", null ],
    [ "busy", "struct_f_a_t___f_i_l_e.html#ae5a0a546179a43c1a949e9fa93413419", null ],
    [ "current_clus_addr", "struct_f_a_t___f_i_l_e.html#aa40d3540a6bc01c0db0d5652eb54c9da", null ],
    [ "current_clus_idx", "struct_f_a_t___f_i_l_e.html#a7f6cee3460fa0695257b3c1423f78dd2", null ],
    [ "current_sector_idx", "struct_f_a_t___f_i_l_e.html#a253e49b3ed2a66e7e954fd24a98c23d0", null ],
    [ "current_size", "struct_f_a_t___f_i_l_e.html#ab4e668c5972a21211c5f440f3d25b289", null ],
    [ "directory_entry", "struct_f_a_t___f_i_l_e.html#aa67dd2410d012e56dd2ad82ddcf4c415", null ],
    [ "magic", "struct_f_a_t___f_i_l_e.html#ab5d470cc959a2a367f045baedd54e0fb", null ],
    [ "no_of_clusters_after_pos", "struct_f_a_t___f_i_l_e.html#a2a11d1d27c638cb1a6450794588ce202", null ],
    [ "no_of_sequential_clusters", "struct_f_a_t___f_i_l_e.html#a5329960566d00c1f3fb24de222ee3246", null ],
    [ "op_state", "struct_f_a_t___f_i_l_e.html#a421f2c4ec089792a4d4ce30e396ea89d", null ],
    [ "volume", "struct_f_a_t___f_i_l_e.html#a83eac8bd6f2e96d7a868bdd545a6e36a", null ]
];