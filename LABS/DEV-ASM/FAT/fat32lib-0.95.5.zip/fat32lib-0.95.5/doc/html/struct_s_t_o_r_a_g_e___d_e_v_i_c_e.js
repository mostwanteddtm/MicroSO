var struct_s_t_o_r_a_g_e___d_e_v_i_c_e =
[
    [ "driver", "struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#a228fb7912c7796975ff0769b9e3fda37", null ],
    [ "erase_sectors", "struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#afcf9038bac9b987005badd3c0ae50843", null ],
    [ "get_device_id", "struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#a967ef76a2314a56c00ae7e8c548b5089", null ],
    [ "get_page_size", "struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#abc7d53ac89abb8ee92f01485f7a501fc", null ],
    [ "get_sector_size", "struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#a6d3284e14c422473bab42aad314c916c", null ],
    [ "get_total_sectors", "struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#a4c7eb29df27cb1e7c012d2ffcc318959", null ],
    [ "read_sector", "struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#aa21cf36104d62af5cd7521c66230e09d", null ],
    [ "read_sector_async", "struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#a19211baa9e90d5d96ffbb88494e1783f", null ],
    [ "register_media_changed_callback", "struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#a4811e9869fe2b92c669ec55a8a805a25", null ],
    [ "write_multiple_sectors", "struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#af6404abe27af2258ec1a47892752f8c4", null ],
    [ "write_sector", "struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#ac5047feeff21f823fd578bf0f4ab81e5", null ],
    [ "write_sector_async", "struct_s_t_o_r_a_g_e___d_e_v_i_c_e.html#a8e85c3b8bc9d3cd76546f93f9f4ccf57", null ]
];