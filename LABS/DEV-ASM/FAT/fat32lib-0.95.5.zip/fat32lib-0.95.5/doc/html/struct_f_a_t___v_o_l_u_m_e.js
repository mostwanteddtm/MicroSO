var struct_f_a_t___v_o_l_u_m_e =
[
    [ "device", "struct_f_a_t___v_o_l_u_m_e.html#a1fc13df6eae54074dd1e1bad5975ced3", null ],
    [ "fat_size", "struct_f_a_t___v_o_l_u_m_e.html#a05c8a4e5c32db92bf7a725b760f593f9", null ],
    [ "first_data_sector", "struct_f_a_t___v_o_l_u_m_e.html#a578b25f72bc909a3d7010583a8b23770", null ],
    [ "fs_type", "struct_f_a_t___v_o_l_u_m_e.html#a00b8a600001508aa7e52dbbb9a45ff1e", null ],
    [ "fsinfo_sector", "struct_f_a_t___v_o_l_u_m_e.html#a6564aba1620c9b46243503a05d2c13ae", null ],
    [ "id", "struct_f_a_t___v_o_l_u_m_e.html#ad9fc7be7a4f330749980a32b45e25301", null ],
    [ "label", "struct_f_a_t___v_o_l_u_m_e.html#adc449213afffdc404a78f6dca95d2fee", null ],
    [ "next_free_cluster", "struct_f_a_t___v_o_l_u_m_e.html#aef912ad56515d10ca0c11f3087940ce5", null ],
    [ "no_of_bytes_per_serctor", "struct_f_a_t___v_o_l_u_m_e.html#abbad1bd4d0b02b3a30ca08854f46d814", null ],
    [ "no_of_clusters", "struct_f_a_t___v_o_l_u_m_e.html#af5df802579642fc64be1572b74ff6caa", null ],
    [ "no_of_data_sectors", "struct_f_a_t___v_o_l_u_m_e.html#ae8dbd6da19f9b5d37c34de996e1ec6ad", null ],
    [ "no_of_fat_tables", "struct_f_a_t___v_o_l_u_m_e.html#a7f5d90e3414bcb7ccc429d4c90a65b47", null ],
    [ "no_of_reserved_sectors", "struct_f_a_t___v_o_l_u_m_e.html#a74a006759eff8b5690e85aa045a737c6", null ],
    [ "no_of_sectors", "struct_f_a_t___v_o_l_u_m_e.html#a091263ffd1d98a6287ac413d4a089cff", null ],
    [ "no_of_sectors_per_cluster", "struct_f_a_t___v_o_l_u_m_e.html#a3627e8ad70deeea9470fc2509cb30c28", null ],
    [ "root_cluster", "struct_f_a_t___v_o_l_u_m_e.html#a89b21b1e7239ad2d744f4720d2ec7582", null ],
    [ "root_directory_sectors", "struct_f_a_t___v_o_l_u_m_e.html#a4d83cd7a801cf85ef23b234b32a7899f", null ],
    [ "total_free_clusters", "struct_f_a_t___v_o_l_u_m_e.html#a62b0980e5698b226b1c6dd87535db85c", null ],
    [ "use_long_filenames", "struct_f_a_t___v_o_l_u_m_e.html#a4b6812e914f8c187a74fcf43c3884b63", null ]
];