var struct_s_d___c_a_r_d =
[
    [ "au_size", "struct_s_d___c_a_r_d.html#ac01dfcf2884cb8dd6d0117190e9e17d8", null ],
    [ "block_length", "struct_s_d___c_a_r_d.html#a98d2919a1948ba43e5f85e221062bfa3", null ],
    [ "capacity", "struct_s_d___c_a_r_d.html#ad749ea74f3cc6b0ac87706936f97183a", null ],
    [ "high_capacity", "struct_s_d___c_a_r_d.html#a6fa4c7f50c009f98281feeb53e53b043", null ],
    [ "nsac", "struct_s_d___c_a_r_d.html#adf6aa76b26a1bce13b004e8e46e01386", null ],
    [ "r2w_factor", "struct_s_d___c_a_r_d.html#a4306ab67cfb5496625bffff9b81f34e5", null ],
    [ "ru_size", "struct_s_d___c_a_r_d.html#a4158592532352914b524343bc26980af", null ],
    [ "taac", "struct_s_d___c_a_r_d.html#a2226898160142a9d2b6baec78d1fcfde", null ],
    [ "version", "struct_s_d___c_a_r_d.html#adc4d85cfd99e36f9dc52f47ed94f10b3", null ]
];