var struct_f_a_t___d_i_r_e_c_t_o_r_y___e_n_t_r_y =
[
    [ "access_time", "struct_f_a_t___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#a156d9e92fdcb395338c433dcf32e4e19", null ],
    [ "attributes", "struct_f_a_t___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#a2440761584d6362f7b1a57e5844c8b2e", null ],
    [ "create_time", "struct_f_a_t___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#aad4b4bd5118b2cfb35ec802726475d1f", null ],
    [ "modify_time", "struct_f_a_t___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#a3498295ba295779e74ff1d20f724aac1", null ],
    [ "name", "struct_f_a_t___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#ac2842750bc760b5291e4009eeed57ed7", null ],
    [ "raw", "struct_f_a_t___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#a608a35428c3c650dc24b3c1136d8df93", null ],
    [ "sector_addr", "struct_f_a_t___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#a221135da1ee1a12c4a1112ffd636550a", null ],
    [ "sector_offset", "struct_f_a_t___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#ad756694bfe026279262fb77eb5148cd0", null ],
    [ "size", "struct_f_a_t___d_i_r_e_c_t_o_r_y___e_n_t_r_y.html#afad000dca462c9f075683b297b956b50", null ]
];