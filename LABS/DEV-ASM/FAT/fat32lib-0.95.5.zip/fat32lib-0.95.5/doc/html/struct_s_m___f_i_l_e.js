var struct_s_m___f_i_l_e =
[
    [ "filesystem", "struct_s_m___f_i_l_e.html#a6a46adc5088d43fcc8e2cf969c87eed4", null ],
    [ "filesystem_file_handle", "struct_s_m___f_i_l_e.html#a05f9f25da7ef855f2d8179ad3198e703", null ],
    [ "magic", "struct_s_m___f_i_l_e.html#aadfd02381bdf6fdfcdad8c1b7adc38d4", null ],
    [ "managed_buffer", "struct_s_m___f_i_l_e.html#a1cc54df4209e5a935eb8a889fc827017", null ]
];