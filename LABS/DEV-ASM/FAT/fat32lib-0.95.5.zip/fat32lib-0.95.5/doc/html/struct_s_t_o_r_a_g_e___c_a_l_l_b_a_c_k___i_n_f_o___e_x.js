var struct_s_t_o_r_a_g_e___c_a_l_l_b_a_c_k___i_n_f_o___e_x =
[
    [ "Callback", "struct_s_t_o_r_a_g_e___c_a_l_l_b_a_c_k___i_n_f_o___e_x.html#a00c3aa361e2f2822dae7c4bca555e93a", null ],
    [ "Context", "struct_s_t_o_r_a_g_e___c_a_l_l_b_a_c_k___i_n_f_o___e_x.html#a57500455085d52fbc17139d096a40b8a", null ]
];