
[Little disclaimer reminder]
I remind you that this code might cause unforeseen problems, although it was 
made with the intention to function right. 
If you use this code, you use this code at your own risk!



[INTRO]
I made this program only for educational use. This becource there is
lots of info to find on the internet but there is no 'real' example program 
for less advanced asm-programmers. (or i couldn't find it :S)

In the most programs i found was explained how to use the int 33h function, but since
this is created by a driver I couldn't use it for my own purpose. (building an OS)

By the way: If you have problems with understanding the code see the mouseprog i made for COM-mouse



[Contents]
In the included .ASM file I show how to use the PS/2-mouse with an Standard PS/2-protocol.
Since there are too many protocols available this program wont cover all. I only choose 
the Standard PS/2-protocol becouse most of my mice would run on this.

The .ASM file is an uncompiled .COM file for only use in MS-DOS. Since I had problems 
getting it running under XP.  This .ASM file can be compiled using NASM

________________________________
>if you are running under Win9X<
Restart in dos mode.
_____________________________
>if you are running under XP<
Download a dos bootdisk, internet search, and put this file on that disk and try booting
from the floppydisk.



[PS/2-Port Control]
For more info on controlling the PS/2-Port, I recommend u to download the 
"Ralf Brown Interrupt List". (most internet search engines will find this)

In this list are also ports included. This list covers many if not all of the 
interrupts and ports, this was very usefull to me for building my OS. 
(Yust a recommendation, nothing more)



[Stream Mode of PS/2 mice]
In stream mode, the mouse sends movement data when it detects movement or a change in state
of one or more mouse buttons. The maximum rate at which this data reporting may occur is known 
as the sample rate. This parameter ranges from 10 samples/sec to 200 samples/sec. Its default value 
is 100 samples/sec and the host may change that value by using the "Set Sample Rate" (0xF3) command.  
Stream mode is the default mode of operation of an standard PS/2-Mouse. 



[Contact]
For any improovements or bugfixes or ideas u can always contact me.
I made such a document also for a COM-Mouse sow keep an eye out for it.

U can contact me by using the programmers heaven mailsystem.

Greetingz MI-7

