
[Little disclaimer reminder]
I remind you that this code might cause unforeseen problems, although it was 
made with the intention to function right. 
If you use this code, you use this code at your own risk!


[INTRO]
I made this program only for educational use. This becource there is
lots of info to find on the internet but there is no 'real' example program 
for less advanced asm-programmers. (or i couldn't find it :S)

In the most programs i found, was explained how to use the int 33h function, but since
this is created by a driver I couldn't use it for my own purpose. (building an OS)


[Contents]
In the included .ASM file I show how to use the COM-mouse with an MS-protocol.
Since there are too many protocols available this program wont cover all. I only choose 
the MS-protocol becouse most of my mice would run on this.

The .ASM file is an uncompiled .COM file for only use in MS-DOS. (U can compile it with NASM)
Since I had problems getting it running under XP.

________________________________
>if you are running under Win9X<
Restart in dos mode and run program.
_____________________________
>if you are running under XP<
Download a dos bootdisk, internet search, and put this file on that disk and try booting
from the floppydisk.


[COM-Port Control]
For more info on controlling the COM-Port I recommend u to download the 
"Ralf Brown Interrupt List". (most internet search engines will find this)

In this list are also ports included. This list covers many if not all of the 
interrupts and ports, this was very usefull to me for building my OS. 
(Yust a recommendation nothing more)

[Contact]
For any improovements or bugfixes or ideas u can always contact me.
I made such a document also for a PS/2 Mouse sow keep an eye out for it.

U can contact me by using the programmers heaven mailsystem.

Greetingz MI_7

